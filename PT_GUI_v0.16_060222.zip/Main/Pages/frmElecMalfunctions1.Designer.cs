﻿
namespace PtGui
{
	partial class frmElecMalfunctions1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmElecMalfunctions1));
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlTopInner = new System.Windows.Forms.Panel();
			this.lblPageName2 = new System.Windows.Forms.Label();
			this.lblPageName = new System.Windows.Forms.Label();
			this.PageFwd = new System.Windows.Forms.PictureBox();
			this.PageBack = new System.Windows.Forms.PictureBox();
			this.pnlPanelTest = new System.Windows.Forms.Panel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.pnlAft = new System.Windows.Forms.Panel();
			this.pnlAft4 = new System.Windows.Forms.Panel();
			this.lblAft4 = new System.Windows.Forms.Label();
			this.pnlAft3 = new System.Windows.Forms.Panel();
			this.lblAft3 = new System.Windows.Forms.Label();
			this.pnlAft2 = new System.Windows.Forms.Panel();
			this.lblAft2 = new System.Windows.Forms.Label();
			this.lblAft = new System.Windows.Forms.Label();
			this.pnlAft1 = new System.Windows.Forms.Panel();
			this.lblAft1 = new System.Windows.Forms.Label();
			this.pnlFwd = new System.Windows.Forms.Panel();
			this.pnlFwd4 = new System.Windows.Forms.Panel();
			this.lblFwd4 = new System.Windows.Forms.Label();
			this.pnlFwd3 = new System.Windows.Forms.Panel();
			this.lblFwd3 = new System.Windows.Forms.Label();
			this.pnlFwd2 = new System.Windows.Forms.Panel();
			this.lblFwd2 = new System.Windows.Forms.Label();
			this.lblFwd = new System.Windows.Forms.Label();
			this.pnlFwd1 = new System.Windows.Forms.Panel();
			this.lblFwd1 = new System.Windows.Forms.Label();
			this.pnlTop.SuspendLayout();
			this.pnlTopInner.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
			this.pnlPanelTest.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel2.SuspendLayout();
			this.pnlAft.SuspendLayout();
			this.pnlAft4.SuspendLayout();
			this.pnlAft3.SuspendLayout();
			this.pnlAft2.SuspendLayout();
			this.pnlAft1.SuspendLayout();
			this.pnlFwd.SuspendLayout();
			this.pnlFwd4.SuspendLayout();
			this.pnlFwd3.SuspendLayout();
			this.pnlFwd2.SuspendLayout();
			this.pnlFwd1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.White;
			this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlTop.Controls.Add(this.pnlTopInner);
			this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.pnlTop.Location = new System.Drawing.Point(25, 5);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1229, 96);
			this.pnlTop.TabIndex = 1;
			// 
			// pnlTopInner
			// 
			this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
			this.pnlTopInner.Controls.Add(this.lblPageName2);
			this.pnlTopInner.Controls.Add(this.lblPageName);
			this.pnlTopInner.Controls.Add(this.PageFwd);
			this.pnlTopInner.Controls.Add(this.PageBack);
			this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
			this.pnlTopInner.Name = "pnlTopInner";
			this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
			this.pnlTopInner.TabIndex = 0;
			// 
			// lblPageName2
			// 
			this.lblPageName2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName2.ForeColor = System.Drawing.Color.White;
			this.lblPageName2.Location = new System.Drawing.Point(175, 42);
			this.lblPageName2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName2.Name = "lblPageName2";
			this.lblPageName2.Size = new System.Drawing.Size(868, 49);
			this.lblPageName2.TabIndex = 3;
			this.lblPageName2.Text = "Page 1 of 2";
			this.lblPageName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPageName
			// 
			this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName.ForeColor = System.Drawing.Color.White;
			this.lblPageName.Location = new System.Drawing.Point(175, 4);
			this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName.Name = "lblPageName";
			this.lblPageName.Size = new System.Drawing.Size(868, 49);
			this.lblPageName.TabIndex = 2;
			this.lblPageName.Text = "Elec/MEPS Malfunctions";
			this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PageFwd
			// 
			this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
			this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageFwd.Location = new System.Drawing.Point(1103, 0);
			this.PageFwd.Name = "PageFwd";
			this.PageFwd.Size = new System.Drawing.Size(116, 87);
			this.PageFwd.TabIndex = 0;
			this.PageFwd.TabStop = false;
			this.PageFwd.Click += new System.EventHandler(this.PageFwd_Click);
			// 
			// PageBack
			// 
			this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
			this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageBack.Location = new System.Drawing.Point(0, 0);
			this.PageBack.Name = "PageBack";
			this.PageBack.Size = new System.Drawing.Size(116, 87);
			this.PageBack.TabIndex = 1;
			this.PageBack.TabStop = false;
			this.PageBack.Click += new System.EventHandler(this.PageBack_Click);
			// 
			// pnlPanelTest
			// 
			this.pnlPanelTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.pnlPanelTest.Controls.Add(this.panel1);
			this.pnlPanelTest.Controls.Add(this.pnlAft);
			this.pnlPanelTest.Controls.Add(this.pnlFwd);
			this.pnlPanelTest.Controls.Add(this.pnlTop);
			this.pnlPanelTest.Cursor = System.Windows.Forms.Cursors.Default;
			this.pnlPanelTest.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.pnlPanelTest.Location = new System.Drawing.Point(0, 0);
			this.pnlPanelTest.Name = "pnlPanelTest";
			this.pnlPanelTest.Size = new System.Drawing.Size(1280, 791);
			this.pnlPanelTest.TabIndex = 0;
			// 
			// panel1
			// 
			this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
			this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Location = new System.Drawing.Point(373, 541);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(560, 238);
			this.panel1.TabIndex = 28;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Silver;
			this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
			this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel3.Controls.Add(this.label3);
			this.panel3.Location = new System.Drawing.Point(281, 83);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(252, 131);
			this.panel3.TabIndex = 25;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label3.Location = new System.Drawing.Point(21, 30);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(209, 72);
			this.label3.TabIndex = 0;
			this.label3.Text = "H2 ALT 440V ACB FAILS (OPENS)";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(204, 17);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(140, 31);
			this.label1.TabIndex = 4;
			this.label1.Text = "440V ACB";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Silver;
			this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
			this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.label2);
			this.panel2.Location = new System.Drawing.Point(23, 83);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(252, 131);
			this.panel2.TabIndex = 24;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label2.Location = new System.Drawing.Point(39, 30);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(177, 72);
			this.label2.TabIndex = 0;
			this.label2.Text = "F1 ALT 440V ACB FAILS (OPENS)";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlAft
			// 
			this.pnlAft.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlAft.BackgroundImage")));
			this.pnlAft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlAft.Controls.Add(this.pnlAft4);
			this.pnlAft.Controls.Add(this.pnlAft3);
			this.pnlAft.Controls.Add(this.pnlAft2);
			this.pnlAft.Controls.Add(this.lblAft);
			this.pnlAft.Controls.Add(this.pnlAft1);
			this.pnlAft.Location = new System.Drawing.Point(694, 122);
			this.pnlAft.Name = "pnlAft";
			this.pnlAft.Size = new System.Drawing.Size(560, 393);
			this.pnlAft.TabIndex = 27;
			// 
			// pnlAft4
			// 
			this.pnlAft4.BackColor = System.Drawing.Color.Silver;
			this.pnlAft4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlAft4.BackgroundImage")));
			this.pnlAft4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlAft4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlAft4.Controls.Add(this.lblAft4);
			this.pnlAft4.Location = new System.Drawing.Point(281, 230);
			this.pnlAft4.Name = "pnlAft4";
			this.pnlAft4.Size = new System.Drawing.Size(252, 131);
			this.pnlAft4.TabIndex = 26;
			// 
			// lblAft4
			// 
			this.lblAft4.BackColor = System.Drawing.Color.Transparent;
			this.lblAft4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAft4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblAft4.Location = new System.Drawing.Point(37, 30);
			this.lblAft4.Name = "lblAft4";
			this.lblAft4.Size = new System.Drawing.Size(176, 72);
			this.lblAft4.TabIndex = 0;
			this.lblAft4.Text = "FWD 600V INTERCONNECTOR ACB FAIL (OPENS)";
			this.lblAft4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlAft3
			// 
			this.pnlAft3.BackColor = System.Drawing.Color.Silver;
			this.pnlAft3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlAft3.BackgroundImage")));
			this.pnlAft3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlAft3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlAft3.Controls.Add(this.lblAft3);
			this.pnlAft3.Location = new System.Drawing.Point(23, 230);
			this.pnlAft3.Name = "pnlAft3";
			this.pnlAft3.Size = new System.Drawing.Size(252, 131);
			this.pnlAft3.TabIndex = 25;
			// 
			// lblAft3
			// 
			this.lblAft3.BackColor = System.Drawing.Color.Transparent;
			this.lblAft3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAft3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblAft3.Location = new System.Drawing.Point(23, 30);
			this.lblAft3.Name = "lblAft3";
			this.lblAft3.Size = new System.Drawing.Size(208, 72);
			this.lblAft3.TabIndex = 0;
			this.lblAft3.Text = "AFT M/G (UAMR) FAIL-AVR FAULT";
			this.lblAft3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlAft2
			// 
			this.pnlAft2.BackColor = System.Drawing.Color.Silver;
			this.pnlAft2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlAft2.BackgroundImage")));
			this.pnlAft2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlAft2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlAft2.Controls.Add(this.lblAft2);
			this.pnlAft2.Location = new System.Drawing.Point(281, 90);
			this.pnlAft2.Name = "pnlAft2";
			this.pnlAft2.Size = new System.Drawing.Size(252, 131);
			this.pnlAft2.TabIndex = 25;
			// 
			// lblAft2
			// 
			this.lblAft2.BackColor = System.Drawing.Color.Transparent;
			this.lblAft2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAft2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblAft2.Location = new System.Drawing.Point(47, 30);
			this.lblAft2.Name = "lblAft2";
			this.lblAft2.Size = new System.Drawing.Size(158, 72);
			this.lblAft2.TabIndex = 0;
			this.lblAft2.Text = "AFT M/G 660V ACB FAIL (OPENS)";
			this.lblAft2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblAft
			// 
			this.lblAft.AutoSize = true;
			this.lblAft.BackColor = System.Drawing.Color.Transparent;
			this.lblAft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblAft.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAft.ForeColor = System.Drawing.Color.White;
			this.lblAft.Location = new System.Drawing.Point(248, 15);
			this.lblAft.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblAft.Name = "lblAft";
			this.lblAft.Size = new System.Drawing.Size(48, 31);
			this.lblAft.TabIndex = 4;
			this.lblAft.Text = "Aft";
			this.lblAft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlAft1
			// 
			this.pnlAft1.BackColor = System.Drawing.Color.Silver;
			this.pnlAft1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlAft1.BackgroundImage")));
			this.pnlAft1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlAft1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlAft1.Controls.Add(this.lblAft1);
			this.pnlAft1.Location = new System.Drawing.Point(23, 90);
			this.pnlAft1.Name = "pnlAft1";
			this.pnlAft1.Size = new System.Drawing.Size(252, 131);
			this.pnlAft1.TabIndex = 24;
			// 
			// lblAft1
			// 
			this.lblAft1.BackColor = System.Drawing.Color.Transparent;
			this.lblAft1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAft1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblAft1.Location = new System.Drawing.Point(57, 30);
			this.lblAft1.Name = "lblAft1";
			this.lblAft1.Size = new System.Drawing.Size(138, 72);
			this.lblAft1.TabIndex = 0;
			this.lblAft1.Text = "AFT M/G (UAMR) FAIL-LOSS OF SW COOLING";
			this.lblAft1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlFwd
			// 
			this.pnlFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlFwd.BackgroundImage")));
			this.pnlFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlFwd.Controls.Add(this.pnlFwd4);
			this.pnlFwd.Controls.Add(this.pnlFwd3);
			this.pnlFwd.Controls.Add(this.pnlFwd2);
			this.pnlFwd.Controls.Add(this.lblFwd);
			this.pnlFwd.Controls.Add(this.pnlFwd1);
			this.pnlFwd.Location = new System.Drawing.Point(31, 122);
			this.pnlFwd.Name = "pnlFwd";
			this.pnlFwd.Size = new System.Drawing.Size(560, 393);
			this.pnlFwd.TabIndex = 25;
			// 
			// pnlFwd4
			// 
			this.pnlFwd4.BackColor = System.Drawing.Color.Silver;
			this.pnlFwd4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlFwd4.BackgroundImage")));
			this.pnlFwd4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlFwd4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlFwd4.Controls.Add(this.lblFwd4);
			this.pnlFwd4.Location = new System.Drawing.Point(281, 230);
			this.pnlFwd4.Name = "pnlFwd4";
			this.pnlFwd4.Size = new System.Drawing.Size(252, 131);
			this.pnlFwd4.TabIndex = 26;
			// 
			// lblFwd4
			// 
			this.lblFwd4.BackColor = System.Drawing.Color.Transparent;
			this.lblFwd4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFwd4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblFwd4.Location = new System.Drawing.Point(37, 30);
			this.lblFwd4.Name = "lblFwd4";
			this.lblFwd4.Size = new System.Drawing.Size(176, 72);
			this.lblFwd4.TabIndex = 0;
			this.lblFwd4.Text = "FWD 600V INTERCONNECTOR ACB FAIL (OPENS)";
			this.lblFwd4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlFwd3
			// 
			this.pnlFwd3.BackColor = System.Drawing.Color.Silver;
			this.pnlFwd3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlFwd3.BackgroundImage")));
			this.pnlFwd3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlFwd3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlFwd3.Controls.Add(this.lblFwd3);
			this.pnlFwd3.Location = new System.Drawing.Point(23, 230);
			this.pnlFwd3.Name = "pnlFwd3";
			this.pnlFwd3.Size = new System.Drawing.Size(252, 131);
			this.pnlFwd3.TabIndex = 25;
			// 
			// lblFwd3
			// 
			this.lblFwd3.BackColor = System.Drawing.Color.Transparent;
			this.lblFwd3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFwd3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblFwd3.Location = new System.Drawing.Point(23, 30);
			this.lblFwd3.Name = "lblFwd3";
			this.lblFwd3.Size = new System.Drawing.Size(208, 72);
			this.lblFwd3.TabIndex = 0;
			this.lblFwd3.Text = "FWD M/G (FAMR) FAIL-AVR FAULT";
			this.lblFwd3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlFwd2
			// 
			this.pnlFwd2.BackColor = System.Drawing.Color.Silver;
			this.pnlFwd2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlFwd2.BackgroundImage")));
			this.pnlFwd2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlFwd2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlFwd2.Controls.Add(this.lblFwd2);
			this.pnlFwd2.Location = new System.Drawing.Point(281, 90);
			this.pnlFwd2.Name = "pnlFwd2";
			this.pnlFwd2.Size = new System.Drawing.Size(252, 131);
			this.pnlFwd2.TabIndex = 25;
			// 
			// lblFwd2
			// 
			this.lblFwd2.BackColor = System.Drawing.Color.Transparent;
			this.lblFwd2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFwd2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblFwd2.Location = new System.Drawing.Point(46, 30);
			this.lblFwd2.Name = "lblFwd2";
			this.lblFwd2.Size = new System.Drawing.Size(158, 72);
			this.lblFwd2.TabIndex = 0;
			this.lblFwd2.Text = "FWD M/G 660V ACB FAIL (OPENS)";
			this.lblFwd2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblFwd
			// 
			this.lblFwd.AutoSize = true;
			this.lblFwd.BackColor = System.Drawing.Color.Transparent;
			this.lblFwd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblFwd.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFwd.ForeColor = System.Drawing.Color.White;
			this.lblFwd.Location = new System.Drawing.Point(248, 15);
			this.lblFwd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblFwd.Name = "lblFwd";
			this.lblFwd.Size = new System.Drawing.Size(66, 31);
			this.lblFwd.TabIndex = 4;
			this.lblFwd.Text = "Fwd";
			this.lblFwd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlFwd1
			// 
			this.pnlFwd1.BackColor = System.Drawing.Color.Silver;
			this.pnlFwd1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlFwd1.BackgroundImage")));
			this.pnlFwd1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlFwd1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlFwd1.Controls.Add(this.lblFwd1);
			this.pnlFwd1.Location = new System.Drawing.Point(23, 90);
			this.pnlFwd1.Name = "pnlFwd1";
			this.pnlFwd1.Size = new System.Drawing.Size(252, 131);
			this.pnlFwd1.TabIndex = 24;
			// 
			// lblFwd1
			// 
			this.lblFwd1.BackColor = System.Drawing.Color.Transparent;
			this.lblFwd1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblFwd1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblFwd1.Location = new System.Drawing.Point(53, 30);
			this.lblFwd1.Name = "lblFwd1";
			this.lblFwd1.Size = new System.Drawing.Size(139, 72);
			this.lblFwd1.TabIndex = 0;
			this.lblFwd1.Text = "FWD M/G (FAMR) FAIL-LOSS OF SW COOLING";
			this.lblFwd1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmElecMalfunctions1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1280, 791);
			this.ControlBox = false;
			this.Controls.Add(this.pnlPanelTest);
			this.Cursor = System.Windows.Forms.Cursors.Cross;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmElecMalfunctions1";
			this.Text = "Elec Malfunctions 1";
			this.pnlTop.ResumeLayout(false);
			this.pnlTopInner.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
			this.pnlPanelTest.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.pnlAft.ResumeLayout(false);
			this.pnlAft.PerformLayout();
			this.pnlAft4.ResumeLayout(false);
			this.pnlAft3.ResumeLayout(false);
			this.pnlAft2.ResumeLayout(false);
			this.pnlAft1.ResumeLayout(false);
			this.pnlFwd.ResumeLayout(false);
			this.pnlFwd.PerformLayout();
			this.pnlFwd4.ResumeLayout(false);
			this.pnlFwd3.ResumeLayout(false);
			this.pnlFwd2.ResumeLayout(false);
			this.pnlFwd1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.PictureBox PageFwd;
		private System.Windows.Forms.PictureBox PageBack;
		private System.Windows.Forms.Panel pnlPanelTest;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.Panel pnlFwd1;
		private System.Windows.Forms.Label lblFwd1;
		private System.Windows.Forms.Label lblPageName2;
		private System.Windows.Forms.Panel pnlFwd;
		private System.Windows.Forms.Panel pnlFwd2;
		private System.Windows.Forms.Label lblFwd2;
		private System.Windows.Forms.Label lblFwd;
		private System.Windows.Forms.Panel pnlFwd4;
		private System.Windows.Forms.Label lblFwd4;
		private System.Windows.Forms.Panel pnlFwd3;
		private System.Windows.Forms.Label lblFwd3;
		private System.Windows.Forms.Panel pnlAft;
		private System.Windows.Forms.Panel pnlAft4;
		private System.Windows.Forms.Label lblAft4;
		private System.Windows.Forms.Panel pnlAft3;
		private System.Windows.Forms.Label lblAft3;
		private System.Windows.Forms.Panel pnlAft2;
		private System.Windows.Forms.Label lblAft2;
		private System.Windows.Forms.Label lblAft;
		private System.Windows.Forms.Panel pnlAft1;
		private System.Windows.Forms.Label lblAft1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label2;
	}
}