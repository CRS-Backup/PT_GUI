﻿
namespace PtGui
{
	partial class frmGBMalfunctions1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGBMalfunctions1));
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlTopInner = new System.Windows.Forms.Panel();
			this.lblPageName2 = new System.Windows.Forms.Label();
			this.lblPageName = new System.Windows.Forms.Label();
			this.PageFwd = new System.Windows.Forms.PictureBox();
			this.PageBack = new System.Windows.Forms.PictureBox();
			this.pnlPanelTest = new System.Windows.Forms.Panel();
			this.pnl6 = new System.Windows.Forms.Panel();
			this.lbl6 = new System.Windows.Forms.Label();
			this.pnl3 = new System.Windows.Forms.Panel();
			this.lbl3 = new System.Windows.Forms.Label();
			this.pnl5 = new System.Windows.Forms.Panel();
			this.lbl5 = new System.Windows.Forms.Label();
			this.pnl2 = new System.Windows.Forms.Panel();
			this.lbl2 = new System.Windows.Forms.Label();
			this.pnl4 = new System.Windows.Forms.Panel();
			this.lbl4 = new System.Windows.Forms.Label();
			this.pnlStbd = new System.Windows.Forms.Panel();
			this.pnlstbd2 = new System.Windows.Forms.Panel();
			this.lblStbd2 = new System.Windows.Forms.Label();
			this.pnlstbd1 = new System.Windows.Forms.Panel();
			this.lblStbd1 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.pnlPort = new System.Windows.Forms.Panel();
			this.pnlport2 = new System.Windows.Forms.Panel();
			this.lblPort2 = new System.Windows.Forms.Label();
			this.pnlport1 = new System.Windows.Forms.Panel();
			this.lblPort1 = new System.Windows.Forms.Label();
			this.lblPort = new System.Windows.Forms.Label();
			this.pnl1 = new System.Windows.Forms.Panel();
			this.lbl1 = new System.Windows.Forms.Label();
			this.pnlTop.SuspendLayout();
			this.pnlTopInner.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
			this.pnlPanelTest.SuspendLayout();
			this.pnl6.SuspendLayout();
			this.pnl3.SuspendLayout();
			this.pnl5.SuspendLayout();
			this.pnl2.SuspendLayout();
			this.pnl4.SuspendLayout();
			this.pnlStbd.SuspendLayout();
			this.pnlstbd2.SuspendLayout();
			this.pnlstbd1.SuspendLayout();
			this.pnlPort.SuspendLayout();
			this.pnlport2.SuspendLayout();
			this.pnlport1.SuspendLayout();
			this.pnl1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.White;
			this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlTop.Controls.Add(this.pnlTopInner);
			this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.pnlTop.Location = new System.Drawing.Point(25, 5);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1229, 96);
			this.pnlTop.TabIndex = 1;
			// 
			// pnlTopInner
			// 
			this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
			this.pnlTopInner.Controls.Add(this.lblPageName2);
			this.pnlTopInner.Controls.Add(this.lblPageName);
			this.pnlTopInner.Controls.Add(this.PageFwd);
			this.pnlTopInner.Controls.Add(this.PageBack);
			this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
			this.pnlTopInner.Name = "pnlTopInner";
			this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
			this.pnlTopInner.TabIndex = 0;
			// 
			// lblPageName2
			// 
			this.lblPageName2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName2.ForeColor = System.Drawing.Color.White;
			this.lblPageName2.Location = new System.Drawing.Point(175, 42);
			this.lblPageName2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName2.Name = "lblPageName2";
			this.lblPageName2.Size = new System.Drawing.Size(868, 49);
			this.lblPageName2.TabIndex = 3;
			this.lblPageName2.Text = "Page 1 of 2";
			this.lblPageName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPageName
			// 
			this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName.ForeColor = System.Drawing.Color.White;
			this.lblPageName.Location = new System.Drawing.Point(175, 4);
			this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName.Name = "lblPageName";
			this.lblPageName.Size = new System.Drawing.Size(868, 49);
			this.lblPageName.TabIndex = 2;
			this.lblPageName.Text = "Gearbox Malfunctions";
			this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PageFwd
			// 
			this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
			this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageFwd.Location = new System.Drawing.Point(1103, 0);
			this.PageFwd.Name = "PageFwd";
			this.PageFwd.Size = new System.Drawing.Size(116, 87);
			this.PageFwd.TabIndex = 0;
			this.PageFwd.TabStop = false;
			this.PageFwd.Click += new System.EventHandler(this.PageFwd_Click);
			// 
			// PageBack
			// 
			this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
			this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageBack.Location = new System.Drawing.Point(0, 0);
			this.PageBack.Name = "PageBack";
			this.PageBack.Size = new System.Drawing.Size(116, 87);
			this.PageBack.TabIndex = 1;
			this.PageBack.TabStop = false;
			this.PageBack.Click += new System.EventHandler(this.PageBack_Click);
			// 
			// pnlPanelTest
			// 
			this.pnlPanelTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.pnlPanelTest.Controls.Add(this.pnl6);
			this.pnlPanelTest.Controls.Add(this.pnl3);
			this.pnlPanelTest.Controls.Add(this.pnl5);
			this.pnlPanelTest.Controls.Add(this.pnl2);
			this.pnlPanelTest.Controls.Add(this.pnl4);
			this.pnlPanelTest.Controls.Add(this.pnlStbd);
			this.pnlPanelTest.Controls.Add(this.pnlPort);
			this.pnlPanelTest.Controls.Add(this.pnl1);
			this.pnlPanelTest.Controls.Add(this.pnlTop);
			this.pnlPanelTest.Cursor = System.Windows.Forms.Cursors.Default;
			this.pnlPanelTest.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.pnlPanelTest.Location = new System.Drawing.Point(0, 0);
			this.pnlPanelTest.Name = "pnlPanelTest";
			this.pnlPanelTest.Size = new System.Drawing.Size(1280, 791);
			this.pnlPanelTest.TabIndex = 0;
			// 
			// pnl6
			// 
			this.pnl6.BackColor = System.Drawing.Color.Silver;
			this.pnl6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl6.BackgroundImage")));
			this.pnl6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnl6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl6.Controls.Add(this.lbl6);
			this.pnl6.Location = new System.Drawing.Point(1002, 315);
			this.pnl6.Name = "pnl6";
			this.pnl6.Size = new System.Drawing.Size(252, 131);
			this.pnl6.TabIndex = 32;
			// 
			// lbl6
			// 
			this.lbl6.BackColor = System.Drawing.Color.Transparent;
			this.lbl6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl6.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lbl6.Location = new System.Drawing.Point(21, 30);
			this.lbl6.Name = "lbl6";
			this.lbl6.Size = new System.Drawing.Size(212, 72);
			this.lbl6.TabIndex = 0;
			this.lbl6.Text = "MAIN LO PRESSURE LOW MAJOR LEAK";
			this.lbl6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnl3
			// 
			this.pnl3.BackColor = System.Drawing.Color.Silver;
			this.pnl3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl3.BackgroundImage")));
			this.pnl3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnl3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl3.Controls.Add(this.lbl3);
			this.pnl3.Location = new System.Drawing.Point(1002, 138);
			this.pnl3.Name = "pnl3";
			this.pnl3.Size = new System.Drawing.Size(252, 131);
			this.pnl3.TabIndex = 31;
			// 
			// lbl3
			// 
			this.lbl3.BackColor = System.Drawing.Color.Transparent;
			this.lbl3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lbl3.Location = new System.Drawing.Point(39, 30);
			this.lbl3.Name = "lbl3";
			this.lbl3.Size = new System.Drawing.Size(176, 72);
			this.lbl3.TabIndex = 0;
			this.lbl3.Text = "ADLO PUMP  FAIL TO CUT-IN";
			this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnl5
			// 
			this.pnl5.BackColor = System.Drawing.Color.Silver;
			this.pnl5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl5.BackgroundImage")));
			this.pnl5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnl5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl5.Controls.Add(this.lbl5);
			this.pnl5.Location = new System.Drawing.Point(522, 315);
			this.pnl5.Name = "pnl5";
			this.pnl5.Size = new System.Drawing.Size(252, 131);
			this.pnl5.TabIndex = 30;
			// 
			// lbl5
			// 
			this.lbl5.BackColor = System.Drawing.Color.Transparent;
			this.lbl5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl5.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lbl5.Location = new System.Drawing.Point(37, 30);
			this.lbl5.Name = "lbl5";
			this.lbl5.Size = new System.Drawing.Size(176, 72);
			this.lbl5.TabIndex = 0;
			this.lbl5.Text = "MDFL PUMP No2 FAIL TO CUT-IN";
			this.lbl5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnl2
			// 
			this.pnl2.BackColor = System.Drawing.Color.Silver;
			this.pnl2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl2.BackgroundImage")));
			this.pnl2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnl2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl2.Controls.Add(this.lbl2);
			this.pnl2.Location = new System.Drawing.Point(522, 138);
			this.pnl2.Name = "pnl2";
			this.pnl2.Size = new System.Drawing.Size(252, 131);
			this.pnl2.TabIndex = 29;
			// 
			// lbl2
			// 
			this.lbl2.BackColor = System.Drawing.Color.Transparent;
			this.lbl2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lbl2.Location = new System.Drawing.Point(43, 30);
			this.lbl2.Name = "lbl2";
			this.lbl2.Size = new System.Drawing.Size(167, 72);
			this.lbl2.TabIndex = 0;
			this.lbl2.Text = "MDFL PUMP No1 FAIL TO CUT-IN";
			this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnl4
			// 
			this.pnl4.BackColor = System.Drawing.Color.Silver;
			this.pnl4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl4.BackgroundImage")));
			this.pnl4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnl4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl4.Controls.Add(this.lbl4);
			this.pnl4.Location = new System.Drawing.Point(42, 315);
			this.pnl4.Name = "pnl4";
			this.pnl4.Size = new System.Drawing.Size(252, 131);
			this.pnl4.TabIndex = 25;
			// 
			// lbl4
			// 
			this.lbl4.BackColor = System.Drawing.Color.Transparent;
			this.lbl4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lbl4.Location = new System.Drawing.Point(23, 30);
			this.lbl4.Name = "lbl4";
			this.lbl4.Size = new System.Drawing.Size(208, 72);
			this.lbl4.TabIndex = 0;
			this.lbl4.Text = "MDFL PUMP No2 FAIL";
			this.lbl4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlStbd
			// 
			this.pnlStbd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlStbd.BackgroundImage")));
			this.pnlStbd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlStbd.Controls.Add(this.pnlstbd2);
			this.pnlStbd.Controls.Add(this.pnlstbd1);
			this.pnlStbd.Controls.Add(this.label16);
			this.pnlStbd.Location = new System.Drawing.Point(694, 541);
			this.pnlStbd.Name = "pnlStbd";
			this.pnlStbd.Size = new System.Drawing.Size(560, 238);
			this.pnlStbd.TabIndex = 28;
			// 
			// pnlstbd2
			// 
			this.pnlstbd2.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd2.BackgroundImage")));
			this.pnlstbd2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd2.Controls.Add(this.lblStbd2);
			this.pnlstbd2.Location = new System.Drawing.Point(286, 86);
			this.pnlstbd2.Name = "pnlstbd2";
			this.pnlstbd2.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd2.TabIndex = 27;
			// 
			// lblStbd2
			// 
			this.lblStbd2.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd2.Location = new System.Drawing.Point(20, 30);
			this.lblStbd2.Name = "lblStbd2";
			this.lblStbd2.Size = new System.Drawing.Size(210, 72);
			this.lblStbd2.TabIndex = 0;
			this.lblStbd2.Text = "GEARBOX BELT DRIVEN PUMP FAIL STARBOARD";
			this.lblStbd2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlstbd1
			// 
			this.pnlstbd1.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd1.BackgroundImage")));
			this.pnlstbd1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd1.Controls.Add(this.lblStbd1);
			this.pnlstbd1.Location = new System.Drawing.Point(20, 86);
			this.pnlstbd1.Name = "pnlstbd1";
			this.pnlstbd1.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd1.TabIndex = 25;
			// 
			// lblStbd1
			// 
			this.lblStbd1.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd1.Location = new System.Drawing.Point(39, 30);
			this.lblStbd1.Name = "lblStbd1";
			this.lblStbd1.Size = new System.Drawing.Size(176, 72);
			this.lblStbd1.TabIndex = 0;
			this.lblStbd1.Text = "LO CONTROL POINT TEMPERATURE HIGH STARBOARD";
			this.lblStbd1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.BackColor = System.Drawing.Color.Transparent;
			this.label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.Color.White;
			this.label16.Location = new System.Drawing.Point(248, 20);
			this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(70, 31);
			this.label16.TabIndex = 4;
			this.label16.Text = "Stbd";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPort
			// 
			this.pnlPort.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPort.BackgroundImage")));
			this.pnlPort.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlPort.Controls.Add(this.pnlport2);
			this.pnlPort.Controls.Add(this.pnlport1);
			this.pnlPort.Controls.Add(this.lblPort);
			this.pnlPort.Location = new System.Drawing.Point(31, 541);
			this.pnlPort.Name = "pnlPort";
			this.pnlPort.Size = new System.Drawing.Size(560, 238);
			this.pnlPort.TabIndex = 25;
			// 
			// pnlport2
			// 
			this.pnlport2.BackColor = System.Drawing.Color.Silver;
			this.pnlport2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport2.BackgroundImage")));
			this.pnlport2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport2.Controls.Add(this.lblPort2);
			this.pnlport2.Location = new System.Drawing.Point(286, 86);
			this.pnlport2.Name = "pnlport2";
			this.pnlport2.Size = new System.Drawing.Size(252, 131);
			this.pnlport2.TabIndex = 27;
			// 
			// lblPort2
			// 
			this.lblPort2.BackColor = System.Drawing.Color.Transparent;
			this.lblPort2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort2.Location = new System.Drawing.Point(37, 30);
			this.lblPort2.Name = "lblPort2";
			this.lblPort2.Size = new System.Drawing.Size(176, 72);
			this.lblPort2.TabIndex = 0;
			this.lblPort2.Text = "GEARBOX BELT DRIVEN PUMP FAIL PORT";
			this.lblPort2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlport1
			// 
			this.pnlport1.BackColor = System.Drawing.Color.Silver;
			this.pnlport1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport1.BackgroundImage")));
			this.pnlport1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport1.Controls.Add(this.lblPort1);
			this.pnlport1.Location = new System.Drawing.Point(20, 86);
			this.pnlport1.Name = "pnlport1";
			this.pnlport1.Size = new System.Drawing.Size(252, 131);
			this.pnlport1.TabIndex = 25;
			// 
			// lblPort1
			// 
			this.lblPort1.BackColor = System.Drawing.Color.Transparent;
			this.lblPort1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort1.Location = new System.Drawing.Point(39, 30);
			this.lblPort1.Name = "lblPort1";
			this.lblPort1.Size = new System.Drawing.Size(176, 72);
			this.lblPort1.TabIndex = 0;
			this.lblPort1.Text = "LO CONTROL POINT TEMPERATURE HIGH PORT";
			this.lblPort1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPort
			// 
			this.lblPort.AutoSize = true;
			this.lblPort.BackColor = System.Drawing.Color.Transparent;
			this.lblPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort.ForeColor = System.Drawing.Color.White;
			this.lblPort.Location = new System.Drawing.Point(248, 9);
			this.lblPort.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPort.Name = "lblPort";
			this.lblPort.Size = new System.Drawing.Size(64, 31);
			this.lblPort.TabIndex = 4;
			this.lblPort.Text = "Port";
			this.lblPort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnl1
			// 
			this.pnl1.BackColor = System.Drawing.Color.Silver;
			this.pnl1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl1.BackgroundImage")));
			this.pnl1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnl1.Controls.Add(this.lbl1);
			this.pnl1.Location = new System.Drawing.Point(42, 138);
			this.pnl1.Name = "pnl1";
			this.pnl1.Size = new System.Drawing.Size(252, 131);
			this.pnl1.TabIndex = 24;
			// 
			// lbl1
			// 
			this.lbl1.BackColor = System.Drawing.Color.Transparent;
			this.lbl1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lbl1.Location = new System.Drawing.Point(39, 30);
			this.lbl1.Name = "lbl1";
			this.lbl1.Size = new System.Drawing.Size(176, 72);
			this.lbl1.TabIndex = 0;
			this.lbl1.Text = "MDFL PUMP No1 FAIL";
			this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmGBMalfunctions1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1280, 791);
			this.ControlBox = false;
			this.Controls.Add(this.pnlPanelTest);
			this.Cursor = System.Windows.Forms.Cursors.Cross;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmGBMalfunctions1";
			this.Text = "GB Malfunctions 1";
			this.pnlTop.ResumeLayout(false);
			this.pnlTopInner.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
			this.pnlPanelTest.ResumeLayout(false);
			this.pnl6.ResumeLayout(false);
			this.pnl3.ResumeLayout(false);
			this.pnl5.ResumeLayout(false);
			this.pnl2.ResumeLayout(false);
			this.pnl4.ResumeLayout(false);
			this.pnlStbd.ResumeLayout(false);
			this.pnlStbd.PerformLayout();
			this.pnlstbd2.ResumeLayout(false);
			this.pnlstbd1.ResumeLayout(false);
			this.pnlPort.ResumeLayout(false);
			this.pnlPort.PerformLayout();
			this.pnlport2.ResumeLayout(false);
			this.pnlport1.ResumeLayout(false);
			this.pnl1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.PictureBox PageFwd;
		private System.Windows.Forms.PictureBox PageBack;
		private System.Windows.Forms.Panel pnlPanelTest;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.Label lblPageName2;
		private System.Windows.Forms.Panel pnlPort;
		private System.Windows.Forms.Panel pnl4;
		private System.Windows.Forms.Label lbl4;
		private System.Windows.Forms.Label lblPort;
		private System.Windows.Forms.Panel pnlStbd;
		private System.Windows.Forms.Panel pnlstbd2;
		private System.Windows.Forms.Label lblStbd2;
		private System.Windows.Forms.Panel pnlstbd1;
		private System.Windows.Forms.Label lblStbd1;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Panel pnlport2;
		private System.Windows.Forms.Label lblPort2;
		private System.Windows.Forms.Panel pnlport1;
		private System.Windows.Forms.Label lblPort1;
		private System.Windows.Forms.Panel pnl5;
		private System.Windows.Forms.Label lbl5;
		private System.Windows.Forms.Panel pnl2;
		private System.Windows.Forms.Label lbl2;
		private System.Windows.Forms.Panel pnl1;
		private System.Windows.Forms.Label lbl1;
		private System.Windows.Forms.Panel pnl6;
		private System.Windows.Forms.Label lbl6;
		private System.Windows.Forms.Panel pnl3;
		private System.Windows.Forms.Label lbl3;
	}
}