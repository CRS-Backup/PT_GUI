﻿
namespace PtGui
{
	partial class frmDiscrepancies
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDiscrepancies));
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlTopInner = new System.Windows.Forms.Panel();
			this.lblPageName = new System.Windows.Forms.Label();
			this.pnlPanelTest = new System.Windows.Forms.Panel();
			this.pnlBackground = new System.Windows.Forms.Panel();
			this.label28 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.label25 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label19 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label18 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.lblDiscrepExist = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.label31 = new System.Windows.Forms.Label();
			this.label32 = new System.Windows.Forms.Label();
			this.label33 = new System.Windows.Forms.Label();
			this.label34 = new System.Windows.Forms.Label();
			this.label35 = new System.Windows.Forms.Label();
			this.label36 = new System.Windows.Forms.Label();
			this.label37 = new System.Windows.Forms.Label();
			this.label38 = new System.Windows.Forms.Label();
			this.label39 = new System.Windows.Forms.Label();
			this.label40 = new System.Windows.Forms.Label();
			this.label41 = new System.Windows.Forms.Label();
			this.label42 = new System.Windows.Forms.Label();
			this.label43 = new System.Windows.Forms.Label();
			this.label44 = new System.Windows.Forms.Label();
			this.label45 = new System.Windows.Forms.Label();
			this.label46 = new System.Windows.Forms.Label();
			this.label47 = new System.Windows.Forms.Label();
			this.label48 = new System.Windows.Forms.Label();
			this.label49 = new System.Windows.Forms.Label();
			this.label50 = new System.Windows.Forms.Label();
			this.label51 = new System.Windows.Forms.Label();
			this.label52 = new System.Windows.Forms.Label();
			this.label53 = new System.Windows.Forms.Label();
			this.label54 = new System.Windows.Forms.Label();
			this.label55 = new System.Windows.Forms.Label();
			this.label56 = new System.Windows.Forms.Label();
			this.label57 = new System.Windows.Forms.Label();
			this.label58 = new System.Windows.Forms.Label();
			this.label59 = new System.Windows.Forms.Label();
			this.label60 = new System.Windows.Forms.Label();
			this.label61 = new System.Windows.Forms.Label();
			this.label62 = new System.Windows.Forms.Label();
			this.label63 = new System.Windows.Forms.Label();
			this.label64 = new System.Windows.Forms.Label();
			this.label65 = new System.Windows.Forms.Label();
			this.label66 = new System.Windows.Forms.Label();
			this.label67 = new System.Windows.Forms.Label();
			this.label68 = new System.Windows.Forms.Label();
			this.label69 = new System.Windows.Forms.Label();
			this.label70 = new System.Windows.Forms.Label();
			this.label71 = new System.Windows.Forms.Label();
			this.label72 = new System.Windows.Forms.Label();
			this.label73 = new System.Windows.Forms.Label();
			this.label74 = new System.Windows.Forms.Label();
			this.label75 = new System.Windows.Forms.Label();
			this.pnlTop.SuspendLayout();
			this.pnlTopInner.SuspendLayout();
			this.pnlPanelTest.SuspendLayout();
			this.pnlBackground.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.White;
			this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlTop.Controls.Add(this.pnlTopInner);
			this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.pnlTop.Location = new System.Drawing.Point(25, 5);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1229, 96);
			this.pnlTop.TabIndex = 1;
			// 
			// pnlTopInner
			// 
			this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
			this.pnlTopInner.Controls.Add(this.lblPageName);
			this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
			this.pnlTopInner.Name = "pnlTopInner";
			this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
			this.pnlTopInner.TabIndex = 0;
			// 
			// lblPageName
			// 
			this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName.ForeColor = System.Drawing.Color.White;
			this.lblPageName.Location = new System.Drawing.Point(175, 19);
			this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName.Name = "lblPageName";
			this.lblPageName.Size = new System.Drawing.Size(868, 49);
			this.lblPageName.TabIndex = 2;
			this.lblPageName.Text = "Discrepancy Report";
			this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPanelTest
			// 
			this.pnlPanelTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.pnlPanelTest.Controls.Add(this.pnlBackground);
			this.pnlPanelTest.Controls.Add(this.pnlTop);
			this.pnlPanelTest.Cursor = System.Windows.Forms.Cursors.Default;
			this.pnlPanelTest.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.pnlPanelTest.Location = new System.Drawing.Point(0, 0);
			this.pnlPanelTest.Name = "pnlPanelTest";
			this.pnlPanelTest.Size = new System.Drawing.Size(1280, 791);
			this.pnlPanelTest.TabIndex = 0;
			// 
			// pnlBackground
			// 
			this.pnlBackground.BackColor = System.Drawing.Color.LightGray;
			this.pnlBackground.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlBackground.BackgroundImage")));
			this.pnlBackground.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlBackground.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlBackground.Controls.Add(this.label75);
			this.pnlBackground.Controls.Add(this.label74);
			this.pnlBackground.Controls.Add(this.label73);
			this.pnlBackground.Controls.Add(this.label72);
			this.pnlBackground.Controls.Add(this.label71);
			this.pnlBackground.Controls.Add(this.label70);
			this.pnlBackground.Controls.Add(this.label69);
			this.pnlBackground.Controls.Add(this.label68);
			this.pnlBackground.Controls.Add(this.label67);
			this.pnlBackground.Controls.Add(this.label66);
			this.pnlBackground.Controls.Add(this.label65);
			this.pnlBackground.Controls.Add(this.label64);
			this.pnlBackground.Controls.Add(this.label63);
			this.pnlBackground.Controls.Add(this.label62);
			this.pnlBackground.Controls.Add(this.label61);
			this.pnlBackground.Controls.Add(this.label60);
			this.pnlBackground.Controls.Add(this.label59);
			this.pnlBackground.Controls.Add(this.label58);
			this.pnlBackground.Controls.Add(this.label57);
			this.pnlBackground.Controls.Add(this.label56);
			this.pnlBackground.Controls.Add(this.label55);
			this.pnlBackground.Controls.Add(this.label54);
			this.pnlBackground.Controls.Add(this.label53);
			this.pnlBackground.Controls.Add(this.label52);
			this.pnlBackground.Controls.Add(this.label51);
			this.pnlBackground.Controls.Add(this.label50);
			this.pnlBackground.Controls.Add(this.label49);
			this.pnlBackground.Controls.Add(this.label48);
			this.pnlBackground.Controls.Add(this.label47);
			this.pnlBackground.Controls.Add(this.label46);
			this.pnlBackground.Controls.Add(this.label45);
			this.pnlBackground.Controls.Add(this.label44);
			this.pnlBackground.Controls.Add(this.label43);
			this.pnlBackground.Controls.Add(this.label42);
			this.pnlBackground.Controls.Add(this.label41);
			this.pnlBackground.Controls.Add(this.label40);
			this.pnlBackground.Controls.Add(this.label39);
			this.pnlBackground.Controls.Add(this.label38);
			this.pnlBackground.Controls.Add(this.label37);
			this.pnlBackground.Controls.Add(this.label36);
			this.pnlBackground.Controls.Add(this.label35);
			this.pnlBackground.Controls.Add(this.label34);
			this.pnlBackground.Controls.Add(this.label33);
			this.pnlBackground.Controls.Add(this.label32);
			this.pnlBackground.Controls.Add(this.label31);
			this.pnlBackground.Controls.Add(this.label30);
			this.pnlBackground.Controls.Add(this.label29);
			this.pnlBackground.Controls.Add(this.label28);
			this.pnlBackground.Controls.Add(this.label27);
			this.pnlBackground.Controls.Add(this.label26);
			this.pnlBackground.Controls.Add(this.label25);
			this.pnlBackground.Controls.Add(this.label23);
			this.pnlBackground.Controls.Add(this.label24);
			this.pnlBackground.Controls.Add(this.label21);
			this.pnlBackground.Controls.Add(this.label22);
			this.pnlBackground.Controls.Add(this.label19);
			this.pnlBackground.Controls.Add(this.label20);
			this.pnlBackground.Controls.Add(this.label17);
			this.pnlBackground.Controls.Add(this.label18);
			this.pnlBackground.Controls.Add(this.label15);
			this.pnlBackground.Controls.Add(this.label16);
			this.pnlBackground.Controls.Add(this.label13);
			this.pnlBackground.Controls.Add(this.label14);
			this.pnlBackground.Controls.Add(this.label11);
			this.pnlBackground.Controls.Add(this.label12);
			this.pnlBackground.Controls.Add(this.label9);
			this.pnlBackground.Controls.Add(this.label10);
			this.pnlBackground.Controls.Add(this.label7);
			this.pnlBackground.Controls.Add(this.label8);
			this.pnlBackground.Controls.Add(this.label5);
			this.pnlBackground.Controls.Add(this.label6);
			this.pnlBackground.Controls.Add(this.label3);
			this.pnlBackground.Controls.Add(this.label4);
			this.pnlBackground.Controls.Add(this.label2);
			this.pnlBackground.Controls.Add(this.label1);
			this.pnlBackground.Controls.Add(this.lblDiscrepExist);
			this.pnlBackground.Location = new System.Drawing.Point(25, 116);
			this.pnlBackground.Name = "pnlBackground";
			this.pnlBackground.Size = new System.Drawing.Size(1225, 640);
			this.pnlBackground.TabIndex = 5;
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.BackColor = System.Drawing.Color.Transparent;
			this.label28.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label28.Location = new System.Drawing.Point(428, 91);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(189, 22);
			this.label28.TabIndex = 33;
			this.label28.Text = "MASKER AIR FLOW";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.BackColor = System.Drawing.Color.Transparent;
			this.label27.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label27.Location = new System.Drawing.Point(428, 68);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(181, 22);
			this.label27.TabIndex = 31;
			this.label27.Text = "PRAIRIE AIR FLOW";
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.BackColor = System.Drawing.Color.Transparent;
			this.label26.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label26.Location = new System.Drawing.Point(428, 45);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(229, 22);
			this.label26.TabIndex = 30;
			this.label26.Text = "PRAIRIE AIR PRESSURE";
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.BackColor = System.Drawing.Color.Transparent;
			this.label25.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label25.Location = new System.Drawing.Point(27, 597);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(270, 22);
			this.label25.TabIndex = 29;
			this.label25.Text = "PORT SHAFT BRAKE SW (A)";
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.BackColor = System.Drawing.Color.Transparent;
			this.label23.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label23.Location = new System.Drawing.Point(27, 551);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(235, 22);
			this.label23.TabIndex = 28;
			this.label23.Text = "DG LOAD SELECT 110%";
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.BackColor = System.Drawing.Color.Transparent;
			this.label24.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label24.Location = new System.Drawing.Point(27, 574);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(270, 22);
			this.label24.TabIndex = 27;
			this.label24.Text = "STBD SHAFT BRAKE SW (A)";
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.BackColor = System.Drawing.Color.Transparent;
			this.label21.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label21.Location = new System.Drawing.Point(27, 505);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(225, 22);
			this.label21.TabIndex = 26;
			this.label21.Text = "DG LOAD SELECT 85%";
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.BackColor = System.Drawing.Color.Transparent;
			this.label22.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label22.Location = new System.Drawing.Point(27, 528);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(236, 22);
			this.label22.TabIndex = 25;
			this.label22.Text = "DG LOAD SELECT 100%";
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.BackColor = System.Drawing.Color.Transparent;
			this.label19.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label19.Location = new System.Drawing.Point(27, 459);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(288, 22);
			this.label19.TabIndex = 24;
			this.label19.Text = "MASKER COMP1 ROCOS-OFF";
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.BackColor = System.Drawing.Color.Transparent;
			this.label20.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label20.Location = new System.Drawing.Point(27, 482);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(288, 22);
			this.label20.TabIndex = 23;
			this.label20.Text = "MASKER COMP2 ROCOS-OFF";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.BackColor = System.Drawing.Color.Transparent;
			this.label17.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label17.Location = new System.Drawing.Point(27, 413);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(232, 22);
			this.label17.TabIndex = 22;
			this.label17.Text = "AC COMP2 ROCOS-OFF";
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.BackColor = System.Drawing.Color.Transparent;
			this.label18.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label18.Location = new System.Drawing.Point(27, 436);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(232, 22);
			this.label18.TabIndex = 21;
			this.label18.Text = "AC COMP3 ROCOS-OFF";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.BackColor = System.Drawing.Color.Transparent;
			this.label15.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label15.Location = new System.Drawing.Point(27, 367);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(220, 22);
			this.label15.TabIndex = 20;
			this.label15.Text = "EDC7 K-R ROCOS-OFF";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.BackColor = System.Drawing.Color.Transparent;
			this.label16.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label16.Location = new System.Drawing.Point(27, 390);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(232, 22);
			this.label16.TabIndex = 19;
			this.label16.Text = "AC COMP1 ROCOS-OFF";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.BackColor = System.Drawing.Color.Transparent;
			this.label13.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label13.Location = new System.Drawing.Point(27, 321);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(230, 22);
			this.label13.TabIndex = 18;
			this.label13.Text = "EDC5 H-R2 ROCOS-OFF";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.BackColor = System.Drawing.Color.Transparent;
			this.label14.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label14.Location = new System.Drawing.Point(27, 344);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(217, 22);
			this.label14.TabIndex = 17;
			this.label14.Text = "EDC6 J-R ROCOS-OFF";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.BackColor = System.Drawing.Color.Transparent;
			this.label11.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label11.Location = new System.Drawing.Point(27, 275);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(221, 22);
			this.label11.TabIndex = 16;
			this.label11.Text = "EDC4 G-R ROCOS-OFF";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.BackColor = System.Drawing.Color.Transparent;
			this.label12.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label12.Location = new System.Drawing.Point(27, 298);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(230, 22);
			this.label12.TabIndex = 15;
			this.label12.Text = "EDC5 H-R1 ROCOS-OFF";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.BackColor = System.Drawing.Color.Transparent;
			this.label9.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label9.Location = new System.Drawing.Point(27, 229);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(229, 22);
			this.label9.TabIndex = 14;
			this.label9.Text = "EDC2 F-R2 ROCOS-OFF";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.BackColor = System.Drawing.Color.Transparent;
			this.label10.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label10.Location = new System.Drawing.Point(27, 252);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(218, 22);
			this.label10.TabIndex = 13;
			this.label10.Text = "EDC3 F-R ROCOS-OFF";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label7.Location = new System.Drawing.Point(27, 183);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(220, 22);
			this.label7.TabIndex = 12;
			this.label7.Text = "EDC1 C-R ROCOS-OFF";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.BackColor = System.Drawing.Color.Transparent;
			this.label8.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label8.Location = new System.Drawing.Point(27, 206);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(230, 22);
			this.label8.TabIndex = 11;
			this.label8.Text = "EDC2 E-R1 ROCOS-OFF";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label5.Location = new System.Drawing.Point(27, 137);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(162, 22);
			this.label5.TabIndex = 10;
			this.label5.Text = "ZONE 4 AFU ATU";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label6.Location = new System.Drawing.Point(27, 160);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(118, 22);
			this.label6.TabIndex = 9;
			this.label6.Text = "SPARE OFF";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label3.Location = new System.Drawing.Point(27, 91);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(162, 22);
			this.label3.TabIndex = 8;
			this.label3.Text = "ZONE 2 AFU ATU";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label4.Location = new System.Drawing.Point(27, 114);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(162, 22);
			this.label4.TabIndex = 7;
			this.label4.Text = "ZONE 3 AFU ATU";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label2.Location = new System.Drawing.Point(27, 68);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(220, 22);
			this.label2.TabIndex = 6;
			this.label2.Text = "ZONE 1B AFU ATU ACU";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label1.Location = new System.Drawing.Point(27, 45);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(174, 22);
			this.label1.TabIndex = 5;
			this.label1.Text = "ZONE 1A AFU ATU";
			// 
			// lblDiscrepExist
			// 
			this.lblDiscrepExist.AutoSize = true;
			this.lblDiscrepExist.BackColor = System.Drawing.Color.Transparent;
			this.lblDiscrepExist.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblDiscrepExist.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.lblDiscrepExist.Location = new System.Drawing.Point(27, 9);
			this.lblDiscrepExist.Name = "lblDiscrepExist";
			this.lblDiscrepExist.Size = new System.Drawing.Size(194, 22);
			this.lblDiscrepExist.TabIndex = 1;
			this.lblDiscrepExist.Text = "Discrepancies Exist";
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.BackColor = System.Drawing.Color.Transparent;
			this.label29.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label29.Location = new System.Drawing.Point(428, 114);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(237, 22);
			this.label29.TabIndex = 80;
			this.label29.Text = "MASKER AIR PRESSURE";
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.BackColor = System.Drawing.Color.Transparent;
			this.label30.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label30.Location = new System.Drawing.Point(428, 137);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(330, 22);
			this.label30.TabIndex = 81;
			this.label30.Text = "AIR DRIVEN PUMP AUTO/STOP SW";
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.BackColor = System.Drawing.Color.Transparent;
			this.label31.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label31.Location = new System.Drawing.Point(428, 160);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(284, 22);
			this.label31.TabIndex = 82;
			this.label31.Text = "DRAIN TANK HEATER ON/OFF";
			// 
			// label32
			// 
			this.label32.AutoSize = true;
			this.label32.BackColor = System.Drawing.Color.Transparent;
			this.label32.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label32.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label32.Location = new System.Drawing.Point(428, 183);
			this.label32.Name = "label32";
			this.label32.Size = new System.Drawing.Size(223, 22);
			this.label32.TabIndex = 83;
			this.label32.Text = "ZONE 1 A/2 VENT FANS";
			// 
			// label33
			// 
			this.label33.AutoSize = true;
			this.label33.BackColor = System.Drawing.Color.Transparent;
			this.label33.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label33.Location = new System.Drawing.Point(428, 206);
			this.label33.Name = "label33";
			this.label33.Size = new System.Drawing.Size(206, 22);
			this.label33.TabIndex = 84;
			this.label33.Text = "ZONE 3/4 VENT FANS";
			// 
			// label34
			// 
			this.label34.AutoSize = true;
			this.label34.BackColor = System.Drawing.Color.Transparent;
			this.label34.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label34.Location = new System.Drawing.Point(428, 229);
			this.label34.Name = "label34";
			this.label34.Size = new System.Drawing.Size(243, 22);
			this.label34.TabIndex = 85;
			this.label34.Text = "ZONE 2/3 MCY SPC FANS";
			// 
			// label35
			// 
			this.label35.AutoSize = true;
			this.label35.BackColor = System.Drawing.Color.Transparent;
			this.label35.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label35.Location = new System.Drawing.Point(428, 252);
			this.label35.Name = "label35";
			this.label35.Size = new System.Drawing.Size(215, 22);
			this.label35.TabIndex = 86;
			this.label35.Text = "STBD GT TRIP LEVER";
			// 
			// label36
			// 
			this.label36.AutoSize = true;
			this.label36.BackColor = System.Drawing.Color.Transparent;
			this.label36.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label36.Location = new System.Drawing.Point(428, 275);
			this.label36.Name = "label36";
			this.label36.Size = new System.Drawing.Size(215, 22);
			this.label36.TabIndex = 87;
			this.label36.Text = "PORT GT TRIP LEVER";
			// 
			// label37
			// 
			this.label37.AutoSize = true;
			this.label37.BackColor = System.Drawing.Color.Transparent;
			this.label37.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label37.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label37.Location = new System.Drawing.Point(428, 298);
			this.label37.Name = "label37";
			this.label37.Size = new System.Drawing.Size(287, 22);
			this.label37.TabIndex = 88;
			this.label37.Text = "STBD CLUTCH LOCKOUT O/R";
			// 
			// label38
			// 
			this.label38.AutoSize = true;
			this.label38.BackColor = System.Drawing.Color.Transparent;
			this.label38.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label38.Location = new System.Drawing.Point(428, 321);
			this.label38.Name = "label38";
			this.label38.Size = new System.Drawing.Size(287, 22);
			this.label38.TabIndex = 89;
			this.label38.Text = "PORT CLUTCH LOCKOUT O/R";
			// 
			// label39
			// 
			this.label39.AutoSize = true;
			this.label39.BackColor = System.Drawing.Color.Transparent;
			this.label39.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label39.Location = new System.Drawing.Point(428, 344);
			this.label39.Name = "label39";
			this.label39.Size = new System.Drawing.Size(361, 22);
			this.label39.TabIndex = 90;
			this.label39.Text = "STBD TRANS BRAKE INTERLOCK O/R";
			// 
			// label40
			// 
			this.label40.AutoSize = true;
			this.label40.BackColor = System.Drawing.Color.Transparent;
			this.label40.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label40.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label40.Location = new System.Drawing.Point(428, 367);
			this.label40.Name = "label40";
			this.label40.Size = new System.Drawing.Size(361, 22);
			this.label40.TabIndex = 91;
			this.label40.Text = "PORT TRANS BRAKE INTERLOCK O/R";
			// 
			// label41
			// 
			this.label41.AutoSize = true;
			this.label41.BackColor = System.Drawing.Color.Transparent;
			this.label41.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label41.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label41.Location = new System.Drawing.Point(428, 390);
			this.label41.Name = "label41";
			this.label41.Size = new System.Drawing.Size(289, 22);
			this.label41.TabIndex = 92;
			this.label41.Text = "SELECT GT PRESSURE STBD";
			// 
			// label42
			// 
			this.label42.AutoSize = true;
			this.label42.BackColor = System.Drawing.Color.Transparent;
			this.label42.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label42.Location = new System.Drawing.Point(428, 413);
			this.label42.Name = "label42";
			this.label42.Size = new System.Drawing.Size(289, 22);
			this.label42.TabIndex = 93;
			this.label42.Text = "SELECT GT PRESSURE PORT";
			// 
			// label43
			// 
			this.label43.AutoSize = true;
			this.label43.BackColor = System.Drawing.Color.Transparent;
			this.label43.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label43.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label43.Location = new System.Drawing.Point(428, 436);
			this.label43.Name = "label43";
			this.label43.Size = new System.Drawing.Size(177, 22);
			this.label43.TabIndex = 94;
			this.label43.Text = "DGF1-TRIP SW (A)";
			// 
			// label44
			// 
			this.label44.AutoSize = true;
			this.label44.BackColor = System.Drawing.Color.Transparent;
			this.label44.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label44.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label44.Location = new System.Drawing.Point(428, 459);
			this.label44.Name = "label44";
			this.label44.Size = new System.Drawing.Size(177, 22);
			this.label44.TabIndex = 95;
			this.label44.Text = "DGF2-TRIP SW (A)";
			// 
			// label45
			// 
			this.label45.AutoSize = true;
			this.label45.BackColor = System.Drawing.Color.Transparent;
			this.label45.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label45.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label45.Location = new System.Drawing.Point(428, 482);
			this.label45.Name = "label45";
			this.label45.Size = new System.Drawing.Size(188, 22);
			this.label45.TabIndex = 96;
			this.label45.Text = "DGH1-STOP SW (A)";
			// 
			// label46
			// 
			this.label46.AutoSize = true;
			this.label46.BackColor = System.Drawing.Color.Transparent;
			this.label46.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label46.Location = new System.Drawing.Point(428, 505);
			this.label46.Name = "label46";
			this.label46.Size = new System.Drawing.Size(188, 22);
			this.label46.TabIndex = 97;
			this.label46.Text = "DGH2-STOP SW (A)";
			// 
			// label47
			// 
			this.label47.AutoSize = true;
			this.label47.BackColor = System.Drawing.Color.Transparent;
			this.label47.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label47.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label47.Location = new System.Drawing.Point(428, 528);
			this.label47.Name = "label47";
			this.label47.Size = new System.Drawing.Size(290, 22);
			this.label47.TabIndex = 98;
			this.label47.Text = "(FWD) INCOMING SUPPLY ASU";
			// 
			// label48
			// 
			this.label48.AutoSize = true;
			this.label48.BackColor = System.Drawing.Color.Transparent;
			this.label48.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label48.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label48.Location = new System.Drawing.Point(428, 551);
			this.label48.Name = "label48";
			this.label48.Size = new System.Drawing.Size(305, 22);
			this.label48.TabIndex = 99;
			this.label48.Text = "(FWD) INCOMING SUPPLY F1 (A)";
			// 
			// label49
			// 
			this.label49.AutoSize = true;
			this.label49.BackColor = System.Drawing.Color.Transparent;
			this.label49.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label49.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label49.Location = new System.Drawing.Point(428, 574);
			this.label49.Name = "label49";
			this.label49.Size = new System.Drawing.Size(343, 22);
			this.label49.TabIndex = 100;
			this.label49.Text = "(FWD) INCOMING SUPPLY 600V BUS";
			// 
			// label50
			// 
			this.label50.AutoSize = true;
			this.label50.BackColor = System.Drawing.Color.Transparent;
			this.label50.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label50.Location = new System.Drawing.Point(428, 597);
			this.label50.Name = "label50";
			this.label50.Size = new System.Drawing.Size(275, 22);
			this.label50.TabIndex = 102;
			this.label50.Text = "(FWD) INCOMING SUPPLY F2";
			// 
			// label51
			// 
			this.label51.AutoSize = true;
			this.label51.BackColor = System.Drawing.Color.Transparent;
			this.label51.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label51.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label51.Location = new System.Drawing.Point(850, 45);
			this.label51.Name = "label51";
			this.label51.Size = new System.Drawing.Size(292, 22);
			this.label51.TabIndex = 103;
			this.label51.Text = "(FWD) INCOMING SUPPLY DG1";
			// 
			// label52
			// 
			this.label52.AutoSize = true;
			this.label52.BackColor = System.Drawing.Color.Transparent;
			this.label52.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label52.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label52.Location = new System.Drawing.Point(850, 68);
			this.label52.Name = "label52";
			this.label52.Size = new System.Drawing.Size(183, 22);
			this.label52.TabIndex = 104;
			this.label52.Text = "(FWD) RUNNING F2";
			// 
			// label53
			// 
			this.label53.AutoSize = true;
			this.label53.BackColor = System.Drawing.Color.Transparent;
			this.label53.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label53.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label53.Location = new System.Drawing.Point(850, 91);
			this.label53.Name = "label53";
			this.label53.Size = new System.Drawing.Size(183, 22);
			this.label53.TabIndex = 105;
			this.label53.Text = "(FWD) RUNNING F1";
			// 
			// label54
			// 
			this.label54.AutoSize = true;
			this.label54.BackColor = System.Drawing.Color.Transparent;
			this.label54.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label54.Location = new System.Drawing.Point(850, 114);
			this.label54.Name = "label54";
			this.label54.Size = new System.Drawing.Size(235, 22);
			this.label54.TabIndex = 106;
			this.label54.Text = "(FWD) RUNNING 600V I/C";
			// 
			// label55
			// 
			this.label55.AutoSize = true;
			this.label55.BackColor = System.Drawing.Color.Transparent;
			this.label55.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label55.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label55.Location = new System.Drawing.Point(850, 137);
			this.label55.Name = "label55";
			this.label55.Size = new System.Drawing.Size(307, 22);
			this.label55.TabIndex = 107;
			this.label55.Text = "(FWD) RUNNING SHORE SUPPLY";
			// 
			// label56
			// 
			this.label56.AutoSize = true;
			this.label56.BackColor = System.Drawing.Color.Transparent;
			this.label56.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label56.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label56.Location = new System.Drawing.Point(850, 160);
			this.label56.Name = "label56";
			this.label56.Size = new System.Drawing.Size(235, 22);
			this.label56.TabIndex = 108;
			this.label56.Text = "(FWD) RUNNING 400V I/C";
			// 
			// label57
			// 
			this.label57.AutoSize = true;
			this.label57.BackColor = System.Drawing.Color.Transparent;
			this.label57.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label57.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label57.Location = new System.Drawing.Point(850, 183);
			this.label57.Name = "label57";
			this.label57.Size = new System.Drawing.Size(179, 22);
			this.label57.TabIndex = 109;
			this.label57.Text = "(AFT) RUNNING H1";
			// 
			// label58
			// 
			this.label58.AutoSize = true;
			this.label58.BackColor = System.Drawing.Color.Transparent;
			this.label58.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label58.Location = new System.Drawing.Point(850, 206);
			this.label58.Name = "label58";
			this.label58.Size = new System.Drawing.Size(282, 22);
			this.label58.TabIndex = 110;
			this.label58.Text = "(AFT) INCOMNG SUPPLY ASO";
			// 
			// label59
			// 
			this.label59.AutoSize = true;
			this.label59.BackColor = System.Drawing.Color.Transparent;
			this.label59.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label59.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label59.Location = new System.Drawing.Point(850, 229);
			this.label59.Name = "label59";
			this.label59.Size = new System.Drawing.Size(295, 22);
			this.label59.TabIndex = 111;
			this.label59.Text = "(AFT) INCOMNG SUPPLY DG1A";
			// 
			// label60
			// 
			this.label60.AutoSize = true;
			this.label60.BackColor = System.Drawing.Color.Transparent;
			this.label60.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label60.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label60.Location = new System.Drawing.Point(850, 252);
			this.label60.Name = "label60";
			this.label60.Size = new System.Drawing.Size(333, 22);
			this.label60.TabIndex = 112;
			this.label60.Text = "(AFT) INCOMNG SUPPLY 600V BUS";
			// 
			// label61
			// 
			this.label61.AutoSize = true;
			this.label61.BackColor = System.Drawing.Color.Transparent;
			this.label61.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label61.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label61.Location = new System.Drawing.Point(850, 275);
			this.label61.Name = "label61";
			this.label61.Size = new System.Drawing.Size(266, 22);
			this.label61.TabIndex = 113;
			this.label61.Text = "(AFT) INCOMNG SUPPLY H2";
			// 
			// label62
			// 
			this.label62.AutoSize = true;
			this.label62.BackColor = System.Drawing.Color.Transparent;
			this.label62.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label62.Location = new System.Drawing.Point(850, 298);
			this.label62.Name = "label62";
			this.label62.Size = new System.Drawing.Size(179, 22);
			this.label62.TabIndex = 114;
			this.label62.Text = "(AFT) RUNNING H2";
			// 
			// label63
			// 
			this.label63.AutoSize = true;
			this.label63.BackColor = System.Drawing.Color.Transparent;
			this.label63.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label63.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label63.Location = new System.Drawing.Point(850, 321);
			this.label63.Name = "label63";
			this.label63.Size = new System.Drawing.Size(179, 22);
			this.label63.TabIndex = 115;
			this.label63.Text = "(AFT) RUNNING H1";
			// 
			// label64
			// 
			this.label64.AutoSize = true;
			this.label64.BackColor = System.Drawing.Color.Transparent;
			this.label64.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label64.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label64.Location = new System.Drawing.Point(850, 344);
			this.label64.Name = "label64";
			this.label64.Size = new System.Drawing.Size(230, 22);
			this.label64.TabIndex = 116;
			this.label64.Text = "(AFT) RUNNING 600V I/C";
			// 
			// label65
			// 
			this.label65.AutoSize = true;
			this.label65.BackColor = System.Drawing.Color.Transparent;
			this.label65.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label65.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label65.Location = new System.Drawing.Point(850, 367);
			this.label65.Name = "label65";
			this.label65.Size = new System.Drawing.Size(302, 22);
			this.label65.TabIndex = 117;
			this.label65.Text = "(AFT) RUNNING SHORE SUPPLY";
			// 
			// label66
			// 
			this.label66.AutoSize = true;
			this.label66.BackColor = System.Drawing.Color.Transparent;
			this.label66.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label66.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label66.Location = new System.Drawing.Point(850, 390);
			this.label66.Name = "label66";
			this.label66.Size = new System.Drawing.Size(230, 22);
			this.label66.TabIndex = 118;
			this.label66.Text = "(AFT) RUNNING 400V I/C";
			// 
			// label67
			// 
			this.label67.AutoSize = true;
			this.label67.BackColor = System.Drawing.Color.Transparent;
			this.label67.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label67.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label67.Location = new System.Drawing.Point(850, 413);
			this.label67.Name = "label67";
			this.label67.Size = new System.Drawing.Size(346, 22);
			this.label67.TabIndex = 119;
			this.label67.Text = "(FWD) SYNCHROSCOPE SWITCH-ON";
			// 
			// label68
			// 
			this.label68.AutoSize = true;
			this.label68.BackColor = System.Drawing.Color.Transparent;
			this.label68.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label68.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label68.Location = new System.Drawing.Point(850, 436);
			this.label68.Name = "label68";
			this.label68.Size = new System.Drawing.Size(341, 22);
			this.label68.TabIndex = 120;
			this.label68.Text = "(AFT) SYNCHROSCOPE SWITCH-ON";
			// 
			// label69
			// 
			this.label69.AutoSize = true;
			this.label69.BackColor = System.Drawing.Color.Transparent;
			this.label69.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label69.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label69.Location = new System.Drawing.Point(850, 459);
			this.label69.Name = "label69";
			this.label69.Size = new System.Drawing.Size(360, 22);
			this.label69.TabIndex = 121;
			this.label69.Text = "(AFT) OVERFLOW DISCHARGE VALVE";
			// 
			// label70
			// 
			this.label70.AutoSize = true;
			this.label70.BackColor = System.Drawing.Color.Transparent;
			this.label70.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label70.Location = new System.Drawing.Point(850, 482);
			this.label70.Name = "label70";
			this.label70.Size = new System.Drawing.Size(167, 22);
			this.label70.TabIndex = 122;
			this.label70.Text = "FILLING VALVE 1";
			// 
			// label71
			// 
			this.label71.AutoSize = true;
			this.label71.BackColor = System.Drawing.Color.Transparent;
			this.label71.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label71.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label71.Location = new System.Drawing.Point(850, 505);
			this.label71.Name = "label71";
			this.label71.Size = new System.Drawing.Size(167, 22);
			this.label71.TabIndex = 123;
			this.label71.Text = "FILLING VALVE 2";
			// 
			// label72
			// 
			this.label72.AutoSize = true;
			this.label72.BackColor = System.Drawing.Color.Transparent;
			this.label72.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label72.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label72.Location = new System.Drawing.Point(850, 528);
			this.label72.Name = "label72";
			this.label72.Size = new System.Drawing.Size(167, 22);
			this.label72.TabIndex = 124;
			this.label72.Text = "FILLING VALVE 3";
			// 
			// label73
			// 
			this.label73.AutoSize = true;
			this.label73.BackColor = System.Drawing.Color.Transparent;
			this.label73.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label73.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label73.Location = new System.Drawing.Point(850, 551);
			this.label73.Name = "label73";
			this.label73.Size = new System.Drawing.Size(206, 22);
			this.label73.TabIndex = 125;
			this.label73.Text = "CROSS FLOW VALVE";
			// 
			// label74
			// 
			this.label74.AutoSize = true;
			this.label74.BackColor = System.Drawing.Color.Transparent;
			this.label74.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label74.Location = new System.Drawing.Point(850, 574);
			this.label74.Name = "label74";
			this.label74.Size = new System.Drawing.Size(219, 22);
			this.label74.TabIndex = 126;
			this.label74.Text = "STBD GT TRIP INHIBIT";
			// 
			// label75
			// 
			this.label75.AutoSize = true;
			this.label75.BackColor = System.Drawing.Color.Transparent;
			this.label75.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label75.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.label75.Location = new System.Drawing.Point(850, 597);
			this.label75.Name = "label75";
			this.label75.Size = new System.Drawing.Size(219, 22);
			this.label75.TabIndex = 127;
			this.label75.Text = "PORT GT TRIP INHIBIT";
			// 
			// frmDiscrepancies
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1280, 791);
			this.ControlBox = false;
			this.Controls.Add(this.pnlPanelTest);
			this.Cursor = System.Windows.Forms.Cursors.Cross;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmDiscrepancies";
			this.Text = "Discrepancy Report";
			this.pnlTop.ResumeLayout(false);
			this.pnlTopInner.ResumeLayout(false);
			this.pnlPanelTest.ResumeLayout(false);
			this.pnlBackground.ResumeLayout(false);
			this.pnlBackground.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.Panel pnlPanelTest;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.Panel pnlBackground;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblDiscrepExist;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label49;
		private System.Windows.Forms.Label label48;
		private System.Windows.Forms.Label label47;
		private System.Windows.Forms.Label label46;
		private System.Windows.Forms.Label label45;
		private System.Windows.Forms.Label label44;
		private System.Windows.Forms.Label label43;
		private System.Windows.Forms.Label label42;
		private System.Windows.Forms.Label label41;
		private System.Windows.Forms.Label label40;
		private System.Windows.Forms.Label label39;
		private System.Windows.Forms.Label label38;
		private System.Windows.Forms.Label label37;
		private System.Windows.Forms.Label label36;
		private System.Windows.Forms.Label label35;
		private System.Windows.Forms.Label label34;
		private System.Windows.Forms.Label label33;
		private System.Windows.Forms.Label label32;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.Label label29;
		private System.Windows.Forms.Label label50;
		private System.Windows.Forms.Label label61;
		private System.Windows.Forms.Label label60;
		private System.Windows.Forms.Label label59;
		private System.Windows.Forms.Label label58;
		private System.Windows.Forms.Label label57;
		private System.Windows.Forms.Label label56;
		private System.Windows.Forms.Label label55;
		private System.Windows.Forms.Label label54;
		private System.Windows.Forms.Label label53;
		private System.Windows.Forms.Label label52;
		private System.Windows.Forms.Label label51;
		private System.Windows.Forms.Label label73;
		private System.Windows.Forms.Label label72;
		private System.Windows.Forms.Label label71;
		private System.Windows.Forms.Label label70;
		private System.Windows.Forms.Label label69;
		private System.Windows.Forms.Label label68;
		private System.Windows.Forms.Label label67;
		private System.Windows.Forms.Label label66;
		private System.Windows.Forms.Label label65;
		private System.Windows.Forms.Label label64;
		private System.Windows.Forms.Label label63;
		private System.Windows.Forms.Label label62;
		private System.Windows.Forms.Label label75;
		private System.Windows.Forms.Label label74;
	}
}