﻿namespace PtGui
{
	internal class pnlLocalControlGreen
	{
	}
}