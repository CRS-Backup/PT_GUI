﻿
namespace PtGui
{
	partial class frmResets
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmResets));
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pnlTopInner = new System.Windows.Forms.Panel();
            this.lblPageName = new System.Windows.Forms.Label();
            this.PageBack = new System.Windows.Forms.PictureBox();
            this.PageFwd = new System.Windows.Forms.PictureBox();
            this.pnlPanelTest = new System.Windows.Forms.Panel();
            this.pnlResetFuel = new System.Windows.Forms.Panel();
            this.lblResetFuel = new System.Windows.Forms.Label();
            this.pnlGeneral = new System.Windows.Forms.Panel();
            this.lblGeneral = new System.Windows.Forms.Label();
            this.pnlChangeServiceTank = new System.Windows.Forms.Panel();
            this.lblChangeServiceTank = new System.Windows.Forms.Label();
            this.pnlChangeFuelTank = new System.Windows.Forms.Panel();
            this.lblChangeFuelTank = new System.Windows.Forms.Label();
            this.pnlCWTanks = new System.Windows.Forms.Panel();
            this.lblCWTanks = new System.Windows.Forms.Label();
            this.pnlLPAir = new System.Windows.Forms.Panel();
            this.lblLPAir = new System.Windows.Forms.Label();
            this.pnlHPAir = new System.Windows.Forms.Panel();
            this.lblHPAir = new System.Windows.Forms.Label();
            this.pnlRechargeBatteries = new System.Windows.Forms.Panel();
            this.lblRechargeBatteries = new System.Windows.Forms.Label();
            this.pnlHalonDrench = new System.Windows.Forms.Panel();
            this.lblHalonDrench = new System.Windows.Forms.Label();
            this.lblCrsFuelTankValue = new CRSControlsLib.CrsLabel();
            this.lblResetService = new System.Windows.Forms.Label();
            this.pnlResetService = new System.Windows.Forms.Panel();
            this.lblCrsResetServiceValue = new CRSControlsLib.CrsLabel();
            this.pnlTop.SuspendLayout();
            this.pnlTopInner.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
            this.pnlPanelTest.SuspendLayout();
            this.pnlResetFuel.SuspendLayout();
            this.pnlGeneral.SuspendLayout();
            this.pnlChangeServiceTank.SuspendLayout();
            this.pnlChangeFuelTank.SuspendLayout();
            this.pnlCWTanks.SuspendLayout();
            this.pnlLPAir.SuspendLayout();
            this.pnlHPAir.SuspendLayout();
            this.pnlRechargeBatteries.SuspendLayout();
            this.pnlHalonDrench.SuspendLayout();
            this.pnlResetService.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.pnlTopInner);
            this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlTop.Location = new System.Drawing.Point(25, 5);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1229, 96);
            this.pnlTop.TabIndex = 1;
            // 
            // pnlTopInner
            // 
            this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            this.pnlTopInner.Controls.Add(this.lblPageName);
            this.pnlTopInner.Controls.Add(this.PageBack);
            this.pnlTopInner.Controls.Add(this.PageFwd);
            this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
            this.pnlTopInner.Name = "pnlTopInner";
            this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
            this.pnlTopInner.TabIndex = 0;
            // 
            // lblPageName
            // 
            this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.ForeColor = System.Drawing.Color.White;
            this.lblPageName.Location = new System.Drawing.Point(175, 19);
            this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(868, 49);
            this.lblPageName.TabIndex = 2;
            this.lblPageName.Text = "Resets";
            this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PageBack
            // 
            this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
            this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PageBack.Location = new System.Drawing.Point(1103, 0);
            this.PageBack.Name = "PageBack";
            this.PageBack.Size = new System.Drawing.Size(116, 87);
            this.PageBack.TabIndex = 0;
            this.PageBack.TabStop = false;
            this.PageBack.Click += new System.EventHandler(this.PageBack_Click);
            // 
            // PageFwd
            // 
            this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
            this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PageFwd.Location = new System.Drawing.Point(0, 0);
            this.PageFwd.Name = "PageFwd";
            this.PageFwd.Size = new System.Drawing.Size(116, 87);
            this.PageFwd.TabIndex = 1;
            this.PageFwd.TabStop = false;
            this.PageFwd.Click += new System.EventHandler(this.PageFwd_Click);
            // 
            // pnlPanelTest
            // 
            this.pnlPanelTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.pnlPanelTest.Controls.Add(this.pnlResetService);
            this.pnlPanelTest.Controls.Add(this.pnlResetFuel);
            this.pnlPanelTest.Controls.Add(this.pnlGeneral);
            this.pnlPanelTest.Controls.Add(this.pnlChangeServiceTank);
            this.pnlPanelTest.Controls.Add(this.pnlChangeFuelTank);
            this.pnlPanelTest.Controls.Add(this.pnlCWTanks);
            this.pnlPanelTest.Controls.Add(this.pnlLPAir);
            this.pnlPanelTest.Controls.Add(this.pnlHPAir);
            this.pnlPanelTest.Controls.Add(this.pnlRechargeBatteries);
            this.pnlPanelTest.Controls.Add(this.pnlHalonDrench);
            this.pnlPanelTest.Controls.Add(this.pnlTop);
            this.pnlPanelTest.Cursor = System.Windows.Forms.Cursors.Default;
            this.pnlPanelTest.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pnlPanelTest.Location = new System.Drawing.Point(0, 0);
            this.pnlPanelTest.Name = "pnlPanelTest";
            this.pnlPanelTest.Size = new System.Drawing.Size(1280, 791);
            this.pnlPanelTest.TabIndex = 0;
            // 
            // pnlResetFuel
            // 
            this.pnlResetFuel.BackColor = System.Drawing.Color.Silver;
            this.pnlResetFuel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlResetFuel.BackgroundImage")));
            this.pnlResetFuel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlResetFuel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResetFuel.Controls.Add(this.lblCrsFuelTankValue);
            this.pnlResetFuel.Controls.Add(this.lblResetFuel);
            this.pnlResetFuel.Location = new System.Drawing.Point(347, 504);
            this.pnlResetFuel.Name = "pnlResetFuel";
            this.pnlResetFuel.Size = new System.Drawing.Size(257, 167);
            this.pnlResetFuel.TabIndex = 22;
            // 
            // lblResetFuel
            // 
            this.lblResetFuel.BackColor = System.Drawing.Color.Transparent;
            this.lblResetFuel.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResetFuel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblResetFuel.Location = new System.Drawing.Point(6, -1);
            this.lblResetFuel.Name = "lblResetFuel";
            this.lblResetFuel.Size = new System.Drawing.Size(239, 93);
            this.lblResetFuel.TabIndex = 0;
            this.lblResetFuel.Text = "RESET FUEL STORAGE TANK LEVELS TO";
            this.lblResetFuel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlGeneral
            // 
            this.pnlGeneral.BackColor = System.Drawing.Color.Silver;
            this.pnlGeneral.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlGeneral.BackgroundImage")));
            this.pnlGeneral.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlGeneral.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlGeneral.Controls.Add(this.lblGeneral);
            this.pnlGeneral.Location = new System.Drawing.Point(993, 323);
            this.pnlGeneral.Name = "pnlGeneral";
            this.pnlGeneral.Size = new System.Drawing.Size(257, 143);
            this.pnlGeneral.TabIndex = 23;
            // 
            // lblGeneral
            // 
            this.lblGeneral.BackColor = System.Drawing.Color.Transparent;
            this.lblGeneral.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGeneral.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblGeneral.Location = new System.Drawing.Point(48, 22);
            this.lblGeneral.Name = "lblGeneral";
            this.lblGeneral.Size = new System.Drawing.Size(164, 93);
            this.lblGeneral.TabIndex = 0;
            this.lblGeneral.Text = "GENERAL RESETS";
            this.lblGeneral.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlChangeServiceTank
            // 
            this.pnlChangeServiceTank.BackColor = System.Drawing.Color.Silver;
            this.pnlChangeServiceTank.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlChangeServiceTank.BackgroundImage")));
            this.pnlChangeServiceTank.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlChangeServiceTank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlChangeServiceTank.Controls.Add(this.lblChangeServiceTank);
            this.pnlChangeServiceTank.Location = new System.Drawing.Point(669, 323);
            this.pnlChangeServiceTank.Name = "pnlChangeServiceTank";
            this.pnlChangeServiceTank.Size = new System.Drawing.Size(257, 143);
            this.pnlChangeServiceTank.TabIndex = 22;
            this.pnlChangeServiceTank.Click += new System.EventHandler(this.pnlChangeServiceTank_Click);
            this.pnlChangeServiceTank.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlChangeServiceTank_MouseDown);
            this.pnlChangeServiceTank.MouseLeave += new System.EventHandler(this.pnlChangeServiceTank_MouseLeave);
            // 
            // lblChangeServiceTank
            // 
            this.lblChangeServiceTank.BackColor = System.Drawing.Color.Transparent;
            this.lblChangeServiceTank.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeServiceTank.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblChangeServiceTank.Location = new System.Drawing.Point(27, 22);
            this.lblChangeServiceTank.Name = "lblChangeServiceTank";
            this.lblChangeServiceTank.Size = new System.Drawing.Size(206, 93);
            this.lblChangeServiceTank.TabIndex = 0;
            this.lblChangeServiceTank.Text = "CHANGE SERVICE AND RU TANK LEVELS";
            this.lblChangeServiceTank.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblChangeServiceTank.Click += new System.EventHandler(this.pnlChangeServiceTank_Click);
            this.lblChangeServiceTank.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlChangeServiceTank_MouseDown);
            this.lblChangeServiceTank.MouseLeave += new System.EventHandler(this.pnlChangeServiceTank_MouseLeave);
            // 
            // pnlChangeFuelTank
            // 
            this.pnlChangeFuelTank.BackColor = System.Drawing.Color.Silver;
            this.pnlChangeFuelTank.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlChangeFuelTank.BackgroundImage")));
            this.pnlChangeFuelTank.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlChangeFuelTank.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlChangeFuelTank.Controls.Add(this.lblChangeFuelTank);
            this.pnlChangeFuelTank.Location = new System.Drawing.Point(347, 323);
            this.pnlChangeFuelTank.Name = "pnlChangeFuelTank";
            this.pnlChangeFuelTank.Size = new System.Drawing.Size(257, 143);
            this.pnlChangeFuelTank.TabIndex = 21;
            this.pnlChangeFuelTank.Click += new System.EventHandler(this.pnlChangeFuelTank_Click);
            this.pnlChangeFuelTank.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlChangeFuelTank_MouseDown);
            this.pnlChangeFuelTank.MouseLeave += new System.EventHandler(this.pnlChangeFuelTank_MouseLeave);
            // 
            // lblChangeFuelTank
            // 
            this.lblChangeFuelTank.BackColor = System.Drawing.Color.Transparent;
            this.lblChangeFuelTank.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangeFuelTank.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblChangeFuelTank.Location = new System.Drawing.Point(17, 22);
            this.lblChangeFuelTank.Name = "lblChangeFuelTank";
            this.lblChangeFuelTank.Size = new System.Drawing.Size(219, 93);
            this.lblChangeFuelTank.TabIndex = 0;
            this.lblChangeFuelTank.Text = "CHANGE FUEL STORAGE TANK LEVELS";
            this.lblChangeFuelTank.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblChangeFuelTank.Click += new System.EventHandler(this.pnlChangeFuelTank_Click);
            this.lblChangeFuelTank.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlChangeFuelTank_MouseDown);
            this.lblChangeFuelTank.MouseLeave += new System.EventHandler(this.pnlChangeFuelTank_MouseLeave);
            // 
            // pnlCWTanks
            // 
            this.pnlCWTanks.BackColor = System.Drawing.Color.Silver;
            this.pnlCWTanks.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlCWTanks.BackgroundImage")));
            this.pnlCWTanks.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlCWTanks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlCWTanks.Controls.Add(this.lblCWTanks);
            this.pnlCWTanks.Location = new System.Drawing.Point(991, 141);
            this.pnlCWTanks.Name = "pnlCWTanks";
            this.pnlCWTanks.Size = new System.Drawing.Size(257, 143);
            this.pnlCWTanks.TabIndex = 24;
            // 
            // lblCWTanks
            // 
            this.lblCWTanks.BackColor = System.Drawing.Color.Transparent;
            this.lblCWTanks.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCWTanks.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCWTanks.Location = new System.Drawing.Point(19, 22);
            this.lblCWTanks.Name = "lblCWTanks";
            this.lblCWTanks.Size = new System.Drawing.Size(219, 93);
            this.lblCWTanks.TabIndex = 0;
            this.lblCWTanks.Text = "RESET CW EXPANSION TANKS";
            this.lblCWTanks.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlLPAir
            // 
            this.pnlLPAir.BackColor = System.Drawing.Color.Silver;
            this.pnlLPAir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlLPAir.BackgroundImage")));
            this.pnlLPAir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlLPAir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlLPAir.Controls.Add(this.lblLPAir);
            this.pnlLPAir.Location = new System.Drawing.Point(669, 141);
            this.pnlLPAir.Name = "pnlLPAir";
            this.pnlLPAir.Size = new System.Drawing.Size(257, 143);
            this.pnlLPAir.TabIndex = 23;
            // 
            // lblLPAir
            // 
            this.lblLPAir.BackColor = System.Drawing.Color.Transparent;
            this.lblLPAir.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLPAir.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblLPAir.Location = new System.Drawing.Point(19, 22);
            this.lblLPAir.Name = "lblLPAir";
            this.lblLPAir.Size = new System.Drawing.Size(219, 93);
            this.lblLPAir.TabIndex = 0;
            this.lblLPAir.Text = "RESET LP AIR";
            this.lblLPAir.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlHPAir
            // 
            this.pnlHPAir.BackColor = System.Drawing.Color.Silver;
            this.pnlHPAir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlHPAir.BackgroundImage")));
            this.pnlHPAir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlHPAir.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlHPAir.Controls.Add(this.lblHPAir);
            this.pnlHPAir.Location = new System.Drawing.Point(347, 141);
            this.pnlHPAir.Name = "pnlHPAir";
            this.pnlHPAir.Size = new System.Drawing.Size(257, 143);
            this.pnlHPAir.TabIndex = 22;
            // 
            // lblHPAir
            // 
            this.lblHPAir.BackColor = System.Drawing.Color.Transparent;
            this.lblHPAir.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHPAir.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblHPAir.Location = new System.Drawing.Point(18, 22);
            this.lblHPAir.Name = "lblHPAir";
            this.lblHPAir.Size = new System.Drawing.Size(219, 93);
            this.lblHPAir.TabIndex = 0;
            this.lblHPAir.Text = "RESET HP AIR";
            this.lblHPAir.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlRechargeBatteries
            // 
            this.pnlRechargeBatteries.BackColor = System.Drawing.Color.Silver;
            this.pnlRechargeBatteries.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlRechargeBatteries.BackgroundImage")));
            this.pnlRechargeBatteries.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlRechargeBatteries.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlRechargeBatteries.Controls.Add(this.lblRechargeBatteries);
            this.pnlRechargeBatteries.Location = new System.Drawing.Point(25, 323);
            this.pnlRechargeBatteries.Name = "pnlRechargeBatteries";
            this.pnlRechargeBatteries.Size = new System.Drawing.Size(257, 143);
            this.pnlRechargeBatteries.TabIndex = 20;
            // 
            // lblRechargeBatteries
            // 
            this.lblRechargeBatteries.BackColor = System.Drawing.Color.Transparent;
            this.lblRechargeBatteries.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRechargeBatteries.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblRechargeBatteries.Location = new System.Drawing.Point(36, 22);
            this.lblRechargeBatteries.Name = "lblRechargeBatteries";
            this.lblRechargeBatteries.Size = new System.Drawing.Size(178, 93);
            this.lblRechargeBatteries.TabIndex = 0;
            this.lblRechargeBatteries.Text = "RECHARGE BATTERIES";
            this.lblRechargeBatteries.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlHalonDrench
            // 
            this.pnlHalonDrench.BackColor = System.Drawing.Color.Silver;
            this.pnlHalonDrench.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlHalonDrench.BackgroundImage")));
            this.pnlHalonDrench.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlHalonDrench.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlHalonDrench.Controls.Add(this.lblHalonDrench);
            this.pnlHalonDrench.Location = new System.Drawing.Point(25, 141);
            this.pnlHalonDrench.Name = "pnlHalonDrench";
            this.pnlHalonDrench.Size = new System.Drawing.Size(257, 143);
            this.pnlHalonDrench.TabIndex = 19;
            // 
            // lblHalonDrench
            // 
            this.lblHalonDrench.BackColor = System.Drawing.Color.Transparent;
            this.lblHalonDrench.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHalonDrench.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblHalonDrench.Location = new System.Drawing.Point(37, 22);
            this.lblHalonDrench.Name = "lblHalonDrench";
            this.lblHalonDrench.Size = new System.Drawing.Size(178, 93);
            this.lblHalonDrench.TabIndex = 0;
            this.lblHalonDrench.Text = "RESET MODULES HALON DRENCH";
            this.lblHalonDrench.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCrsFuelTankValue
            // 
            this.lblCrsFuelTankValue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            this.lblCrsFuelTankValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCrsFuelTankValue.CrsChanNumOrAlias = "o_storageTankLevel";
            this.lblCrsFuelTankValue.CrsChanValue = "\"<none>\"";
            this.lblCrsFuelTankValue.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCrsFuelTankValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCrsFuelTankValue.Location = new System.Drawing.Point(21, 94);
            this.lblCrsFuelTankValue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCrsFuelTankValue.Name = "lblCrsFuelTankValue";
            this.lblCrsFuelTankValue.Size = new System.Drawing.Size(215, 44);
            this.lblCrsFuelTankValue.TabIndex = 48;
            this.lblCrsFuelTankValue.Text = "100.0";
            this.lblCrsFuelTankValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblResetService
            // 
            this.lblResetService.BackColor = System.Drawing.Color.Transparent;
            this.lblResetService.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResetService.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblResetService.Location = new System.Drawing.Point(10, -1);
            this.lblResetService.Name = "lblResetService";
            this.lblResetService.Size = new System.Drawing.Size(232, 93);
            this.lblResetService.TabIndex = 0;
            this.lblResetService.Text = "RESET SERVICE AND RU TANK LEVELS TO";
            this.lblResetService.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlResetService
            // 
            this.pnlResetService.BackColor = System.Drawing.Color.Silver;
            this.pnlResetService.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlResetService.BackgroundImage")));
            this.pnlResetService.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pnlResetService.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlResetService.Controls.Add(this.lblCrsResetServiceValue);
            this.pnlResetService.Controls.Add(this.lblResetService);
            this.pnlResetService.Location = new System.Drawing.Point(669, 504);
            this.pnlResetService.Name = "pnlResetService";
            this.pnlResetService.Size = new System.Drawing.Size(257, 167);
            this.pnlResetService.TabIndex = 43;
            // 
            // lblCrsResetServiceValue
            // 
            this.lblCrsResetServiceValue.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            this.lblCrsResetServiceValue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCrsResetServiceValue.CrsChanNumOrAlias = "o_serviceTankLevel";
            this.lblCrsResetServiceValue.CrsChanValue = "\"<none>\"";
            this.lblCrsResetServiceValue.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCrsResetServiceValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCrsResetServiceValue.Location = new System.Drawing.Point(20, 94);
            this.lblCrsResetServiceValue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCrsResetServiceValue.Name = "lblCrsResetServiceValue";
            this.lblCrsResetServiceValue.Size = new System.Drawing.Size(215, 44);
            this.lblCrsResetServiceValue.TabIndex = 49;
            this.lblCrsResetServiceValue.Text = "100.0";
            this.lblCrsResetServiceValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frmResets
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 791);
            this.ControlBox = false;
            this.Controls.Add(this.pnlPanelTest);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmResets";
            this.Text = "Resets";
            this.pnlTop.ResumeLayout(false);
            this.pnlTopInner.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
            this.pnlPanelTest.ResumeLayout(false);
            this.pnlResetFuel.ResumeLayout(false);
            this.pnlGeneral.ResumeLayout(false);
            this.pnlChangeServiceTank.ResumeLayout(false);
            this.pnlChangeFuelTank.ResumeLayout(false);
            this.pnlCWTanks.ResumeLayout(false);
            this.pnlLPAir.ResumeLayout(false);
            this.pnlHPAir.ResumeLayout(false);
            this.pnlRechargeBatteries.ResumeLayout(false);
            this.pnlHalonDrench.ResumeLayout(false);
            this.pnlResetService.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.PictureBox PageBack;
		private System.Windows.Forms.PictureBox PageFwd;
		private System.Windows.Forms.Panel pnlPanelTest;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.Panel pnlHalonDrench;
		private System.Windows.Forms.Label lblHalonDrench;
		private System.Windows.Forms.Panel pnlChangeFuelTank;
		private System.Windows.Forms.Label lblChangeFuelTank;
		private System.Windows.Forms.Panel pnlCWTanks;
		private System.Windows.Forms.Label lblCWTanks;
		private System.Windows.Forms.Panel pnlLPAir;
		private System.Windows.Forms.Label lblLPAir;
		private System.Windows.Forms.Panel pnlHPAir;
		private System.Windows.Forms.Label lblHPAir;
		private System.Windows.Forms.Panel pnlRechargeBatteries;
		private System.Windows.Forms.Label lblRechargeBatteries;
		private System.Windows.Forms.Panel pnlResetFuel;
		private System.Windows.Forms.Label lblResetFuel;
		private System.Windows.Forms.Panel pnlGeneral;
		private System.Windows.Forms.Label lblGeneral;
		private System.Windows.Forms.Panel pnlChangeServiceTank;
		private System.Windows.Forms.Label lblChangeServiceTank;
        private System.Windows.Forms.Panel pnlResetService;
        private CRSControlsLib.CrsLabel lblCrsResetServiceValue;
        private System.Windows.Forms.Label lblResetService;
        private CRSControlsLib.CrsLabel lblCrsFuelTankValue;
    }
}