﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace PtGui
{
	public partial class frmLoadChanges : Form
	{
		public frmLoadChanges()
		{
			InitializeComponent();
			this.StartPosition = FormStartPosition.Manual;
			this.Location = new Point(0, 792);
		}
		private void pnlCANCEL_Click(object sender, EventArgs e)
		{
			//The user has cancelled the update. Restore the original value
			double elec_block_value = GuiCore.get_chan_val_double("o_elec_load_change");
			//Reset the working copy
			GuiCore.set_channel_value("t_elec_load_change", elec_block_value);

			this.Hide();
		}

        private void lbl800kWa_Click(object sender, EventArgs e)
        {
			GuiCore.set_channel_value("t_elec_load_change", 800);
        }


        private void lbl1000kW_Click(object sender, EventArgs e)
        {
			GuiCore.set_channel_value("t_elec_load_change", 1000);
		}

        private void lbl1200kW_Click(object sender, EventArgs e)
        {
			GuiCore.set_channel_value("t_elec_load_change", 1200);
		}

		private void lbl1400kW_Click(object sender, EventArgs e)
        {
			GuiCore.set_channel_value("t_elec_load_change", 1400);
		}

        private void lbl800kW_Click(object sender, EventArgs e)
        {
			GuiCore.set_channel_value("t_elec_load_change", 800);
		}

        private void pnlCANCEL_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlACCEPT_Click(object sender, EventArgs e)
        {
			//The user has accepted the update

			//Get the new, intermediate value
			double elec_block_value = GuiCore.get_chan_val_double("t_elec_load_change");
			//Set the output value
			GuiCore.set_channel_value("o_elec_load_change", elec_block_value);
			this.Hide();
		}
	}
}
