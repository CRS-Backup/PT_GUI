﻿
namespace PtGui
{
	partial class frmLPSW1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLPSW1));
			this.staticText1 = new System.Windows.Forms.Label();
			this.pnl3WAY1 = new System.Windows.Forms.Panel();
			this.staticText2 = new System.Windows.Forms.Label();
			this.staticText3 = new System.Windows.Forms.Label();
			this.staticText4 = new System.Windows.Forms.Label();
			this.staticText5 = new System.Windows.Forms.Label();
			this.staticText6 = new System.Windows.Forms.Label();
			this.staticText7 = new System.Windows.Forms.Label();
			this.staticText8 = new System.Windows.Forms.Label();
			this.staticText9 = new System.Windows.Forms.Label();
			this.pnlPump1 = new System.Windows.Forms.Panel();
			this.pnlPump2 = new System.Windows.Forms.Panel();
			this.pnlPump3 = new System.Windows.Forms.Panel();
			this.staticText10 = new System.Windows.Forms.Label();
			this.staticText11 = new System.Windows.Forms.Label();
			this.staticText12 = new System.Windows.Forms.Label();
			this.staticText13 = new System.Windows.Forms.Label();
			this.staticText14 = new System.Windows.Forms.Label();
			this.staticText15 = new System.Windows.Forms.Label();
			this.staticText16 = new System.Windows.Forms.Label();
			this.staticText17 = new System.Windows.Forms.Label();
			this.staticText20 = new System.Windows.Forms.Label();
			this.staticText19 = new System.Windows.Forms.Label();
			this.staticText18 = new System.Windows.Forms.Label();
			this.pnlVLV1 = new System.Windows.Forms.Panel();
			this.pnlVLV2 = new System.Windows.Forms.Panel();
			this.pnlVLV3 = new System.Windows.Forms.Panel();
			this.pnlVLV4 = new System.Windows.Forms.Panel();
			this.pnlVLV5 = new System.Windows.Forms.Panel();
			this.staticText21 = new System.Windows.Forms.Label();
			this.staticText22 = new System.Windows.Forms.Label();
			this.staticText23 = new System.Windows.Forms.Label();
			this.pnlVLV6 = new System.Windows.Forms.Panel();
			this.staticText24 = new System.Windows.Forms.Label();
			this.staticText25 = new System.Windows.Forms.Label();
			this.staticText26 = new System.Windows.Forms.Label();
			this.staticText27 = new System.Windows.Forms.Label();
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlTopInner = new System.Windows.Forms.Panel();
			this.lblPageName = new System.Windows.Forms.Label();
			this.PageBack = new System.Windows.Forms.PictureBox();
			this.PageFwd = new System.Windows.Forms.PictureBox();
			this.pnlTop.SuspendLayout();
			this.pnlTopInner.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
			this.SuspendLayout();
			// 
			// staticText1
			// 
			this.staticText1.BackColor = System.Drawing.Color.Transparent;
			this.staticText1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText1.ForeColor = System.Drawing.Color.White;
			this.staticText1.Location = new System.Drawing.Point(432, 190);
			this.staticText1.Name = "staticText1";
			this.staticText1.Size = new System.Drawing.Size(50, 32);
			this.staticText1.TabIndex = 17;
			this.staticText1.Text = "CW PLANT";
			this.staticText1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnl3WAY1
			// 
			this.pnl3WAY1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl3WAY1.BackgroundImage")));
			this.pnl3WAY1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnl3WAY1.Location = new System.Drawing.Point(338, 132);
			this.pnl3WAY1.Name = "pnl3WAY1";
			this.pnl3WAY1.Size = new System.Drawing.Size(44, 62);
			this.pnl3WAY1.TabIndex = 66;
			// 
			// staticText2
			// 
			this.staticText2.BackColor = System.Drawing.Color.Transparent;
			this.staticText2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText2.ForeColor = System.Drawing.Color.White;
			this.staticText2.Location = new System.Drawing.Point(914, 191);
			this.staticText2.Name = "staticText2";
			this.staticText2.Size = new System.Drawing.Size(40, 32);
			this.staticText2.TabIndex = 67;
			this.staticText2.Text = "STAB";
			this.staticText2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText3
			// 
			this.staticText3.BackColor = System.Drawing.Color.Transparent;
			this.staticText3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText3.ForeColor = System.Drawing.Color.White;
			this.staticText3.Location = new System.Drawing.Point(1071, 147);
			this.staticText3.Name = "staticText3";
			this.staticText3.Size = new System.Drawing.Size(50, 32);
			this.staticText3.TabIndex = 68;
			this.staticText3.Text = "HPAC";
			this.staticText3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText4
			// 
			this.staticText4.BackColor = System.Drawing.Color.Transparent;
			this.staticText4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText4.ForeColor = System.Drawing.Color.White;
			this.staticText4.Location = new System.Drawing.Point(74, 249);
			this.staticText4.Name = "staticText4";
			this.staticText4.Size = new System.Drawing.Size(50, 32);
			this.staticText4.TabIndex = 70;
			this.staticText4.Text = "CONVR CABIN";
			this.staticText4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText5
			// 
			this.staticText5.BackColor = System.Drawing.Color.Transparent;
			this.staticText5.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText5.ForeColor = System.Drawing.Color.White;
			this.staticText5.Location = new System.Drawing.Point(123, 249);
			this.staticText5.Name = "staticText5";
			this.staticText5.Size = new System.Drawing.Size(50, 32);
			this.staticText5.TabIndex = 71;
			this.staticText5.Text = "PLUMR BLOCK";
			this.staticText5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText6
			// 
			this.staticText6.BackColor = System.Drawing.Color.Transparent;
			this.staticText6.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText6.ForeColor = System.Drawing.Color.White;
			this.staticText6.Location = new System.Drawing.Point(173, 243);
			this.staticText6.Name = "staticText6";
			this.staticText6.Size = new System.Drawing.Size(50, 44);
			this.staticText6.TabIndex = 72;
			this.staticText6.Text = "PROPN MOTOR COOLR";
			this.staticText6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText7
			// 
			this.staticText7.AutoSize = true;
			this.staticText7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText7.ForeColor = System.Drawing.Color.Yellow;
			this.staticText7.Location = new System.Drawing.Point(318, 287);
			this.staticText7.Name = "staticText7";
			this.staticText7.Size = new System.Drawing.Size(46, 19);
			this.staticText7.TabIndex = 73;
			this.staticText7.Text = "MGR";
			this.staticText7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText8
			// 
			this.staticText8.BackColor = System.Drawing.Color.Transparent;
			this.staticText8.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText8.ForeColor = System.Drawing.Color.White;
			this.staticText8.Location = new System.Drawing.Point(681, 352);
			this.staticText8.Name = "staticText8";
			this.staticText8.Size = new System.Drawing.Size(75, 32);
			this.staticText8.TabIndex = 74;
			this.staticText8.Text = "PORT MAIN LO COOLER";
			this.staticText8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText9
			// 
			this.staticText9.BackColor = System.Drawing.Color.Transparent;
			this.staticText9.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText9.ForeColor = System.Drawing.Color.White;
			this.staticText9.Location = new System.Drawing.Point(1012, 354);
			this.staticText9.Name = "staticText9";
			this.staticText9.Size = new System.Drawing.Size(73, 32);
			this.staticText9.TabIndex = 75;
			this.staticText9.Text = "  PORT GT   LO COOLER";
			this.staticText9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPump1
			// 
			this.pnlPump1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPump1.BackgroundImage")));
			this.pnlPump1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlPump1.Location = new System.Drawing.Point(240, 142);
			this.pnlPump1.Name = "pnlPump1";
			this.pnlPump1.Size = new System.Drawing.Size(39, 39);
			this.pnlPump1.TabIndex = 67;
			// 
			// pnlPump2
			// 
			this.pnlPump2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPump2.BackgroundImage")));
			this.pnlPump2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlPump2.Location = new System.Drawing.Point(240, 395);
			this.pnlPump2.Name = "pnlPump2";
			this.pnlPump2.Size = new System.Drawing.Size(39, 39);
			this.pnlPump2.TabIndex = 68;
			// 
			// pnlPump3
			// 
			this.pnlPump3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPump3.BackgroundImage")));
			this.pnlPump3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlPump3.Location = new System.Drawing.Point(240, 476);
			this.pnlPump3.Name = "pnlPump3";
			this.pnlPump3.Size = new System.Drawing.Size(39, 39);
			this.pnlPump3.TabIndex = 69;
			// 
			// staticText10
			// 
			this.staticText10.BackColor = System.Drawing.Color.Transparent;
			this.staticText10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText10.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText10.Location = new System.Drawing.Point(228, 361);
			this.staticText10.Name = "staticText10";
			this.staticText10.Size = new System.Drawing.Size(62, 37);
			this.staticText10.TabIndex = 76;
			this.staticText10.Text = "LPSW Pp";
			this.staticText10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText11
			// 
			this.staticText11.BackColor = System.Drawing.Color.Transparent;
			this.staticText11.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText11.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText11.Location = new System.Drawing.Point(228, 439);
			this.staticText11.Name = "staticText11";
			this.staticText11.Size = new System.Drawing.Size(62, 37);
			this.staticText11.TabIndex = 77;
			this.staticText11.Text = "LPSW Pp";
			this.staticText11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText12
			// 
			this.staticText12.BackColor = System.Drawing.Color.Transparent;
			this.staticText12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText12.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText12.Location = new System.Drawing.Point(443, 365);
			this.staticText12.Name = "staticText12";
			this.staticText12.Size = new System.Drawing.Size(62, 37);
			this.staticText12.TabIndex = 78;
			this.staticText12.Text = "FROM HPSW";
			this.staticText12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText13
			// 
			this.staticText13.BackColor = System.Drawing.Color.Transparent;
			this.staticText13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText13.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText13.Location = new System.Drawing.Point(443, 509);
			this.staticText13.Name = "staticText13";
			this.staticText13.Size = new System.Drawing.Size(62, 37);
			this.staticText13.TabIndex = 79;
			this.staticText13.Text = "FROM HPSW";
			this.staticText13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText14
			// 
			this.staticText14.BackColor = System.Drawing.Color.Transparent;
			this.staticText14.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText14.ForeColor = System.Drawing.Color.White;
			this.staticText14.Location = new System.Drawing.Point(697, 409);
			this.staticText14.Name = "staticText14";
			this.staticText14.Size = new System.Drawing.Size(45, 32);
			this.staticText14.TabIndex = 80;
			this.staticText14.Text = "PORT FL Pp";
			this.staticText14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText15
			// 
			this.staticText15.BackColor = System.Drawing.Color.Transparent;
			this.staticText15.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText15.ForeColor = System.Drawing.Color.White;
			this.staticText15.Location = new System.Drawing.Point(697, 475);
			this.staticText15.Name = "staticText15";
			this.staticText15.Size = new System.Drawing.Size(45, 32);
			this.staticText15.TabIndex = 81;
			this.staticText15.Text = "STBD FL Pp";
			this.staticText15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText16
			// 
			this.staticText16.BackColor = System.Drawing.Color.Transparent;
			this.staticText16.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText16.ForeColor = System.Drawing.Color.White;
			this.staticText16.Location = new System.Drawing.Point(681, 531);
			this.staticText16.Name = "staticText16";
			this.staticText16.Size = new System.Drawing.Size(75, 32);
			this.staticText16.TabIndex = 82;
			this.staticText16.Text = "STBD MAIN LO COOLER";
			this.staticText16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText17
			// 
			this.staticText17.BackColor = System.Drawing.Color.Transparent;
			this.staticText17.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText17.ForeColor = System.Drawing.Color.White;
			this.staticText17.Location = new System.Drawing.Point(1012, 499);
			this.staticText17.Name = "staticText17";
			this.staticText17.Size = new System.Drawing.Size(75, 32);
			this.staticText17.TabIndex = 83;
			this.staticText17.Text = "  STBD GT   LO COOLER";
			this.staticText17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText20
			// 
			this.staticText20.BackColor = System.Drawing.Color.Transparent;
			this.staticText20.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText20.ForeColor = System.Drawing.Color.White;
			this.staticText20.Location = new System.Drawing.Point(173, 586);
			this.staticText20.Name = "staticText20";
			this.staticText20.Size = new System.Drawing.Size(50, 44);
			this.staticText20.TabIndex = 86;
			this.staticText20.Text = "PROPN MOTOR COOLR";
			this.staticText20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText19
			// 
			this.staticText19.BackColor = System.Drawing.Color.Transparent;
			this.staticText19.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText19.ForeColor = System.Drawing.Color.White;
			this.staticText19.Location = new System.Drawing.Point(123, 592);
			this.staticText19.Name = "staticText19";
			this.staticText19.Size = new System.Drawing.Size(50, 32);
			this.staticText19.TabIndex = 85;
			this.staticText19.Text = "PLUMR BLOCK";
			this.staticText19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText18
			// 
			this.staticText18.BackColor = System.Drawing.Color.Transparent;
			this.staticText18.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText18.ForeColor = System.Drawing.Color.White;
			this.staticText18.Location = new System.Drawing.Point(74, 592);
			this.staticText18.Name = "staticText18";
			this.staticText18.Size = new System.Drawing.Size(50, 32);
			this.staticText18.TabIndex = 84;
			this.staticText18.Text = "CONVR CABIN";
			this.staticText18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlVLV1
			// 
			this.pnlVLV1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV1.BackgroundImage")));
			this.pnlVLV1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV1.Location = new System.Drawing.Point(133, 539);
			this.pnlVLV1.Name = "pnlVLV1";
			this.pnlVLV1.Size = new System.Drawing.Size(33, 33);
			this.pnlVLV1.TabIndex = 87;
			// 
			// pnlVLV2
			// 
			this.pnlVLV2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV2.BackgroundImage")));
			this.pnlVLV2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV2.Location = new System.Drawing.Point(682, 304);
			this.pnlVLV2.Name = "pnlVLV2";
			this.pnlVLV2.Size = new System.Drawing.Size(58, 33);
			this.pnlVLV2.TabIndex = 88;
			// 
			// pnlVLV3
			// 
			this.pnlVLV3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV3.BackgroundImage")));
			this.pnlVLV3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV3.Location = new System.Drawing.Point(682, 581);
			this.pnlVLV3.Name = "pnlVLV3";
			this.pnlVLV3.Size = new System.Drawing.Size(58, 33);
			this.pnlVLV3.TabIndex = 89;
			// 
			// pnlVLV4
			// 
			this.pnlVLV4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV4.BackgroundImage")));
			this.pnlVLV4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV4.Location = new System.Drawing.Point(989, 287);
			this.pnlVLV4.Name = "pnlVLV4";
			this.pnlVLV4.Size = new System.Drawing.Size(33, 33);
			this.pnlVLV4.TabIndex = 88;
			// 
			// pnlVLV5
			// 
			this.pnlVLV5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV5.BackgroundImage")));
			this.pnlVLV5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV5.Location = new System.Drawing.Point(1013, 559);
			this.pnlVLV5.Name = "pnlVLV5";
			this.pnlVLV5.Size = new System.Drawing.Size(33, 33);
			this.pnlVLV5.TabIndex = 89;
			// 
			// staticText21
			// 
			this.staticText21.BackColor = System.Drawing.Color.Transparent;
			this.staticText21.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText21.ForeColor = System.Drawing.Color.White;
			this.staticText21.Location = new System.Drawing.Point(938, 686);
			this.staticText21.Name = "staticText21";
			this.staticText21.Size = new System.Drawing.Size(50, 32);
			this.staticText21.TabIndex = 90;
			this.staticText21.Text = "STAB";
			this.staticText21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText22
			// 
			this.staticText22.AutoSize = true;
			this.staticText22.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText22.ForeColor = System.Drawing.Color.Yellow;
			this.staticText22.Location = new System.Drawing.Point(897, 271);
			this.staticText22.Name = "staticText22";
			this.staticText22.Size = new System.Drawing.Size(43, 19);
			this.staticText22.TabIndex = 91;
			this.staticText22.Text = "GTR";
			this.staticText22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText23
			// 
			this.staticText23.BackColor = System.Drawing.Color.Transparent;
			this.staticText23.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText23.ForeColor = System.Drawing.Color.White;
			this.staticText23.Location = new System.Drawing.Point(1179, 388);
			this.staticText23.Name = "staticText23";
			this.staticText23.Size = new System.Drawing.Size(50, 32);
			this.staticText23.TabIndex = 92;
			this.staticText23.Text = "M/G";
			this.staticText23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlVLV6
			// 
			this.pnlVLV6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV6.BackgroundImage")));
			this.pnlVLV6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV6.Location = new System.Drawing.Point(1190, 559);
			this.pnlVLV6.Name = "pnlVLV6";
			this.pnlVLV6.Size = new System.Drawing.Size(58, 33);
			this.pnlVLV6.TabIndex = 90;
			// 
			// staticText24
			// 
			this.staticText24.AutoSize = true;
			this.staticText24.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText24.ForeColor = System.Drawing.Color.Yellow;
			this.staticText24.Location = new System.Drawing.Point(1179, 271);
			this.staticText24.Name = "staticText24";
			this.staticText24.Size = new System.Drawing.Size(54, 19);
			this.staticText24.TabIndex = 93;
			this.staticText24.Text = "FAMR";
			this.staticText24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText25
			// 
			this.staticText25.AutoSize = true;
			this.staticText25.BackColor = System.Drawing.Color.Transparent;
			this.staticText25.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText25.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText25.Location = new System.Drawing.Point(1086, 766);
			this.staticText25.Name = "staticText25";
			this.staticText25.Size = new System.Drawing.Size(42, 16);
			this.staticText25.TabIndex = 94;
			this.staticText25.Text = "O\'B\'D";
			this.staticText25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText26
			// 
			this.staticText26.AutoSize = true;
			this.staticText26.BackColor = System.Drawing.Color.Transparent;
			this.staticText26.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText26.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText26.Location = new System.Drawing.Point(744, 766);
			this.staticText26.Name = "staticText26";
			this.staticText26.Size = new System.Drawing.Size(42, 16);
			this.staticText26.TabIndex = 95;
			this.staticText26.Text = "O\'B\'D";
			this.staticText26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText27
			// 
			this.staticText27.AutoSize = true;
			this.staticText27.BackColor = System.Drawing.Color.Transparent;
			this.staticText27.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText27.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText27.Location = new System.Drawing.Point(168, 766);
			this.staticText27.Name = "staticText27";
			this.staticText27.Size = new System.Drawing.Size(42, 16);
			this.staticText27.TabIndex = 96;
			this.staticText27.Text = "O\'B\'D";
			this.staticText27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.White;
			this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlTop.Controls.Add(this.pnlTopInner);
			this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.pnlTop.Location = new System.Drawing.Point(25, 5);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1229, 96);
			this.pnlTop.TabIndex = 97;
			// 
			// pnlTopInner
			// 
			this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
			this.pnlTopInner.Controls.Add(this.lblPageName);
			this.pnlTopInner.Controls.Add(this.PageBack);
			this.pnlTopInner.Controls.Add(this.PageFwd);
			this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
			this.pnlTopInner.Name = "pnlTopInner";
			this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
			this.pnlTopInner.TabIndex = 0;
			// 
			// lblPageName
			// 
			this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName.ForeColor = System.Drawing.Color.White;
			this.lblPageName.Location = new System.Drawing.Point(335, 5);
			this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName.Name = "lblPageName";
			this.lblPageName.Size = new System.Drawing.Size(521, 73);
			this.lblPageName.TabIndex = 2;
			this.lblPageName.Text = "                    LPSW1 System                   (Forward Auxiliary Machinery R" +
    "oom Only)";
			this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PageBack
			// 
			this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
			this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageBack.Location = new System.Drawing.Point(1103, 0);
			this.PageBack.Name = "PageBack";
			this.PageBack.Size = new System.Drawing.Size(116, 87);
			this.PageBack.TabIndex = 0;
			this.PageBack.TabStop = false;
			this.PageBack.Click += new System.EventHandler(this.PageFwd_Click);
			// 
			// PageFwd
			// 
			this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
			this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageFwd.Location = new System.Drawing.Point(0, 0);
			this.PageFwd.Name = "PageFwd";
			this.PageFwd.Size = new System.Drawing.Size(116, 87);
			this.PageFwd.TabIndex = 1;
			this.PageFwd.TabStop = false;
			this.PageFwd.Click += new System.EventHandler(this.PageBack_Click);
			// 
			// frmLPSW1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.ClientSize = new System.Drawing.Size(1280, 791);
			this.Controls.Add(this.pnlTop);
			this.Controls.Add(this.staticText27);
			this.Controls.Add(this.staticText26);
			this.Controls.Add(this.staticText25);
			this.Controls.Add(this.staticText24);
			this.Controls.Add(this.pnlVLV6);
			this.Controls.Add(this.staticText23);
			this.Controls.Add(this.staticText22);
			this.Controls.Add(this.staticText21);
			this.Controls.Add(this.pnlVLV5);
			this.Controls.Add(this.pnlVLV4);
			this.Controls.Add(this.pnlVLV3);
			this.Controls.Add(this.pnlVLV2);
			this.Controls.Add(this.pnlVLV1);
			this.Controls.Add(this.staticText20);
			this.Controls.Add(this.staticText19);
			this.Controls.Add(this.staticText18);
			this.Controls.Add(this.staticText17);
			this.Controls.Add(this.staticText16);
			this.Controls.Add(this.staticText15);
			this.Controls.Add(this.staticText14);
			this.Controls.Add(this.staticText13);
			this.Controls.Add(this.staticText12);
			this.Controls.Add(this.staticText11);
			this.Controls.Add(this.pnlPump2);
			this.Controls.Add(this.staticText10);
			this.Controls.Add(this.pnlPump3);
			this.Controls.Add(this.pnlPump1);
			this.Controls.Add(this.staticText9);
			this.Controls.Add(this.staticText8);
			this.Controls.Add(this.staticText7);
			this.Controls.Add(this.staticText6);
			this.Controls.Add(this.staticText5);
			this.Controls.Add(this.staticText4);
			this.Controls.Add(this.staticText3);
			this.Controls.Add(this.staticText2);
			this.Controls.Add(this.pnl3WAY1);
			this.Controls.Add(this.staticText1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmLPSW1";
			this.Text = "LPSW 1";
			this.pnlTop.ResumeLayout(false);
			this.pnlTopInner.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label staticText1;
		private System.Windows.Forms.Panel pnl3WAY1;
		private System.Windows.Forms.Label staticText2;
		private System.Windows.Forms.Label staticText3;
		private System.Windows.Forms.Label staticText4;
		private System.Windows.Forms.Label staticText5;
		private System.Windows.Forms.Label staticText6;
		private System.Windows.Forms.Label staticText7;
		private System.Windows.Forms.Label staticText8;
		private System.Windows.Forms.Label staticText9;
		private System.Windows.Forms.Panel pnlPump1;
		private System.Windows.Forms.Panel pnlPump2;
		private System.Windows.Forms.Panel pnlPump3;
		private System.Windows.Forms.Label staticText10;
		private System.Windows.Forms.Label staticText11;
		private System.Windows.Forms.Label staticText12;
		private System.Windows.Forms.Label staticText13;
		private System.Windows.Forms.Label staticText14;
		private System.Windows.Forms.Label staticText15;
		private System.Windows.Forms.Label staticText16;
		private System.Windows.Forms.Label staticText17;
		private System.Windows.Forms.Label staticText20;
		private System.Windows.Forms.Label staticText19;
		private System.Windows.Forms.Label staticText18;
		private System.Windows.Forms.Panel pnlVLV1;
		private System.Windows.Forms.Panel pnlVLV2;
		private System.Windows.Forms.Panel pnlVLV3;
		private System.Windows.Forms.Panel pnlVLV4;
		private System.Windows.Forms.Panel pnlVLV5;
		private System.Windows.Forms.Label staticText21;
		private System.Windows.Forms.Label staticText22;
		private System.Windows.Forms.Label staticText23;
		private System.Windows.Forms.Panel pnlVLV6;
		private System.Windows.Forms.Label staticText24;
		private System.Windows.Forms.Label staticText25;
		private System.Windows.Forms.Label staticText26;
		private System.Windows.Forms.Label staticText27;
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.PictureBox PageBack;
		private System.Windows.Forms.PictureBox PageFwd;
	}
}