﻿
namespace PtGui
{
	partial class frmMainLubOil
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainLubOil));
			this.pnlMainLubOil = new System.Windows.Forms.Panel();
			this.pnlVlvADLO = new System.Windows.Forms.Panel();
			this.lblMGR = new System.Windows.Forms.Label();
			this.lblGTR = new System.Windows.Forms.Label();
			this.staticText16 = new System.Windows.Forms.Label();
			this.staticText15 = new System.Windows.Forms.Label();
			this.staticText14 = new System.Windows.Forms.Label();
			this.staticText13 = new System.Windows.Forms.Label();
			this.staticText12 = new System.Windows.Forms.Label();
			this.pnlADLOPump = new System.Windows.Forms.Panel();
			this.lblADLOPump = new System.Windows.Forms.Label();
			this.pnlPump4Green = new System.Windows.Forms.Panel();
			this.staticText11 = new System.Windows.Forms.Label();
			this.staticText10 = new System.Windows.Forms.Label();
			this.staticText9 = new System.Windows.Forms.Label();
			this.staticText8 = new System.Windows.Forms.Label();
			this.staticText7 = new System.Windows.Forms.Label();
			this.staticText6 = new System.Windows.Forms.Label();
			this.pnlVlv1Opn = new System.Windows.Forms.Panel();
			this.pnlVlv2Clsd = new System.Windows.Forms.Panel();
			this.pnlPump2Green = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.pnlPump1Green = new System.Windows.Forms.Panel();
			this.pnlPump3Red = new System.Windows.Forms.Panel();
			this.staticText5 = new System.Windows.Forms.Label();
			this.staticText4 = new System.Windows.Forms.Label();
			this.staticText3 = new System.Windows.Forms.Label();
			this.staticText2 = new System.Windows.Forms.Label();
			this.staticText1 = new System.Windows.Forms.Label();
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlTopInner = new System.Windows.Forms.Panel();
			this.lblPageName = new System.Windows.Forms.Label();
			this.PageBack = new System.Windows.Forms.PictureBox();
			this.PageFwd = new System.Windows.Forms.PictureBox();
			this.pnlMainLubOil.SuspendLayout();
			this.pnlADLOPump.SuspendLayout();
			this.pnlTop.SuspendLayout();
			this.pnlTopInner.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
			this.SuspendLayout();
			// 
			// pnlMainLubOil
			// 
			this.pnlMainLubOil.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlMainLubOil.BackgroundImage")));
			this.pnlMainLubOil.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlMainLubOil.Controls.Add(this.pnlVlvADLO);
			this.pnlMainLubOil.Controls.Add(this.lblMGR);
			this.pnlMainLubOil.Controls.Add(this.lblGTR);
			this.pnlMainLubOil.Controls.Add(this.staticText16);
			this.pnlMainLubOil.Controls.Add(this.staticText15);
			this.pnlMainLubOil.Controls.Add(this.staticText14);
			this.pnlMainLubOil.Controls.Add(this.staticText13);
			this.pnlMainLubOil.Controls.Add(this.staticText12);
			this.pnlMainLubOil.Controls.Add(this.pnlADLOPump);
			this.pnlMainLubOil.Controls.Add(this.pnlPump4Green);
			this.pnlMainLubOil.Controls.Add(this.staticText11);
			this.pnlMainLubOil.Controls.Add(this.staticText10);
			this.pnlMainLubOil.Controls.Add(this.staticText9);
			this.pnlMainLubOil.Controls.Add(this.staticText8);
			this.pnlMainLubOil.Controls.Add(this.staticText7);
			this.pnlMainLubOil.Controls.Add(this.staticText6);
			this.pnlMainLubOil.Controls.Add(this.pnlVlv1Opn);
			this.pnlMainLubOil.Controls.Add(this.pnlVlv2Clsd);
			this.pnlMainLubOil.Controls.Add(this.pnlPump2Green);
			this.pnlMainLubOil.Controls.Add(this.label1);
			this.pnlMainLubOil.Controls.Add(this.pnlPump1Green);
			this.pnlMainLubOil.Controls.Add(this.pnlPump3Red);
			this.pnlMainLubOil.Controls.Add(this.staticText5);
			this.pnlMainLubOil.Controls.Add(this.staticText4);
			this.pnlMainLubOil.Controls.Add(this.staticText3);
			this.pnlMainLubOil.Controls.Add(this.staticText2);
			this.pnlMainLubOil.Controls.Add(this.staticText1);
			this.pnlMainLubOil.Controls.Add(this.pnlTop);
			this.pnlMainLubOil.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlMainLubOil.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.pnlMainLubOil.Location = new System.Drawing.Point(0, 0);
			this.pnlMainLubOil.Name = "pnlMainLubOil";
			this.pnlMainLubOil.Size = new System.Drawing.Size(1280, 791);
			this.pnlMainLubOil.TabIndex = 0;
			// 
			// pnlVlvADLO
			// 
			this.pnlVlvADLO.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVlvADLO.BackgroundImage")));
			this.pnlVlvADLO.Location = new System.Drawing.Point(986, 550);
			this.pnlVlvADLO.Name = "pnlVlvADLO";
			this.pnlVlvADLO.Size = new System.Drawing.Size(45, 45);
			this.pnlVlvADLO.TabIndex = 53;
			// 
			// lblMGR
			// 
			this.lblMGR.AutoSize = true;
			this.lblMGR.BackColor = System.Drawing.Color.Transparent;
			this.lblMGR.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.lblMGR.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblMGR.ForeColor = System.Drawing.Color.Yellow;
			this.lblMGR.Location = new System.Drawing.Point(1054, 133);
			this.lblMGR.Name = "lblMGR";
			this.lblMGR.Size = new System.Drawing.Size(58, 24);
			this.lblMGR.TabIndex = 67;
			this.lblMGR.Text = "MGR";
			this.lblMGR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblGTR
			// 
			this.lblGTR.AutoSize = true;
			this.lblGTR.BackColor = System.Drawing.Color.Transparent;
			this.lblGTR.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.lblGTR.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblGTR.ForeColor = System.Drawing.Color.Yellow;
			this.lblGTR.Location = new System.Drawing.Point(1132, 133);
			this.lblGTR.Name = "lblGTR";
			this.lblGTR.Size = new System.Drawing.Size(54, 24);
			this.lblGTR.TabIndex = 66;
			this.lblGTR.Text = "GTR";
			this.lblGTR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText16
			// 
			this.staticText16.BackColor = System.Drawing.Color.Transparent;
			this.staticText16.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText16.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText16.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText16.Location = new System.Drawing.Point(1199, 625);
			this.staticText16.Name = "staticText16";
			this.staticText16.Size = new System.Drawing.Size(51, 35);
			this.staticText16.TabIndex = 65;
			this.staticText16.Text = "STBD GT";
			this.staticText16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText15
			// 
			this.staticText15.BackColor = System.Drawing.Color.Transparent;
			this.staticText15.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText15.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText15.Location = new System.Drawing.Point(1199, 226);
			this.staticText15.Name = "staticText15";
			this.staticText15.Size = new System.Drawing.Size(51, 35);
			this.staticText15.TabIndex = 64;
			this.staticText15.Text = "PORT GT";
			this.staticText15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText14
			// 
			this.staticText14.BackColor = System.Drawing.Color.Transparent;
			this.staticText14.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText14.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText14.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText14.Location = new System.Drawing.Point(1034, 553);
			this.staticText14.Name = "staticText14";
			this.staticText14.Size = new System.Drawing.Size(59, 78);
			this.staticText14.TabIndex = 63;
			this.staticText14.Text = "AIR TO ADLO Pp";
			this.staticText14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText13
			// 
			this.staticText13.BackColor = System.Drawing.Color.Transparent;
			this.staticText13.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText13.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText13.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText13.Location = new System.Drawing.Point(991, 611);
			this.staticText13.Name = "staticText13";
			this.staticText13.Size = new System.Drawing.Size(66, 57);
			this.staticText13.TabIndex = 62;
			this.staticText13.Text = "TO DRAIN TANK";
			this.staticText13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText12
			// 
			this.staticText12.BackColor = System.Drawing.Color.Transparent;
			this.staticText12.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText12.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText12.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText12.Location = new System.Drawing.Point(991, 229);
			this.staticText12.Name = "staticText12";
			this.staticText12.Size = new System.Drawing.Size(66, 57);
			this.staticText12.TabIndex = 61;
			this.staticText12.Text = "TO DRAIN TANK";
			this.staticText12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlADLOPump
			// 
			this.pnlADLOPump.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlADLOPump.BackgroundImage")));
			this.pnlADLOPump.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlADLOPump.Controls.Add(this.lblADLOPump);
			this.pnlADLOPump.Location = new System.Drawing.Point(1019, 408);
			this.pnlADLOPump.Name = "pnlADLOPump";
			this.pnlADLOPump.Size = new System.Drawing.Size(84, 84);
			this.pnlADLOPump.TabIndex = 49;
			// 
			// lblADLOPump
			// 
			this.lblADLOPump.BackColor = System.Drawing.Color.Transparent;
			this.lblADLOPump.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.lblADLOPump.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblADLOPump.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblADLOPump.Location = new System.Drawing.Point(19, 31);
			this.lblADLOPump.Name = "lblADLOPump";
			this.lblADLOPump.Size = new System.Drawing.Size(45, 35);
			this.lblADLOPump.TabIndex = 61;
			this.lblADLOPump.Text = "ADLO Pp";
			this.lblADLOPump.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPump4Green
			// 
			this.pnlPump4Green.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPump4Green.BackgroundImage")));
			this.pnlPump4Green.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlPump4Green.Location = new System.Drawing.Point(791, 426);
			this.pnlPump4Green.Name = "pnlPump4Green";
			this.pnlPump4Green.Size = new System.Drawing.Size(84, 84);
			this.pnlPump4Green.TabIndex = 60;
			// 
			// staticText11
			// 
			this.staticText11.BackColor = System.Drawing.Color.Transparent;
			this.staticText11.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText11.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText11.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText11.Location = new System.Drawing.Point(628, 540);
			this.staticText11.Name = "staticText11";
			this.staticText11.Size = new System.Drawing.Size(113, 32);
			this.staticText11.TabIndex = 59;
			this.staticText11.Text = "STBD G/BOX AND THRUST BLOCK";
			this.staticText11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText10
			// 
			this.staticText10.BackColor = System.Drawing.Color.Transparent;
			this.staticText10.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText10.Font = new System.Drawing.Font("Arial", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText10.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText10.Location = new System.Drawing.Point(628, 293);
			this.staticText10.Name = "staticText10";
			this.staticText10.Size = new System.Drawing.Size(113, 32);
			this.staticText10.TabIndex = 58;
			this.staticText10.Text = "PORT G/BOX AND THRUST BLOCK";
			this.staticText10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText9
			// 
			this.staticText9.AutoSize = true;
			this.staticText9.BackColor = System.Drawing.Color.Transparent;
			this.staticText9.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText9.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText9.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText9.Location = new System.Drawing.Point(639, 324);
			this.staticText9.Name = "staticText9";
			this.staticText9.Size = new System.Drawing.Size(113, 16);
			this.staticText9.TabIndex = 57;
			this.staticText9.Text = "TO SSS CLUTCH";
			this.staticText9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText8
			// 
			this.staticText8.AutoSize = true;
			this.staticText8.BackColor = System.Drawing.Color.Transparent;
			this.staticText8.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText8.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText8.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText8.Location = new System.Drawing.Point(578, 590);
			this.staticText8.Name = "staticText8";
			this.staticText8.Size = new System.Drawing.Size(113, 16);
			this.staticText8.TabIndex = 56;
			this.staticText8.Text = "TO SSS CLUTCH";
			this.staticText8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText7
			// 
			this.staticText7.BackColor = System.Drawing.Color.Transparent;
			this.staticText7.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText7.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText7.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText7.Location = new System.Drawing.Point(595, 486);
			this.staticText7.Name = "staticText7";
			this.staticText7.Size = new System.Drawing.Size(45, 35);
			this.staticText7.TabIndex = 55;
			this.staticText7.Text = "STBD LCP";
			this.staticText7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText6
			// 
			this.staticText6.BackColor = System.Drawing.Color.Transparent;
			this.staticText6.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText6.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText6.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText6.Location = new System.Drawing.Point(595, 331);
			this.staticText6.Name = "staticText6";
			this.staticText6.Size = new System.Drawing.Size(45, 35);
			this.staticText6.TabIndex = 54;
			this.staticText6.Text = "PORT LCP";
			this.staticText6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlVlv1Opn
			// 
			this.pnlVlv1Opn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVlv1Opn.BackgroundImage")));
			this.pnlVlv1Opn.Location = new System.Drawing.Point(216, 170);
			this.pnlVlv1Opn.Name = "pnlVlv1Opn";
			this.pnlVlv1Opn.Size = new System.Drawing.Size(33, 33);
			this.pnlVlv1Opn.TabIndex = 53;
			// 
			// pnlVlv2Clsd
			// 
			this.pnlVlv2Clsd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVlv2Clsd.BackgroundImage")));
			this.pnlVlv2Clsd.Location = new System.Drawing.Point(259, 467);
			this.pnlVlv2Clsd.Name = "pnlVlv2Clsd";
			this.pnlVlv2Clsd.Size = new System.Drawing.Size(33, 33);
			this.pnlVlv2Clsd.TabIndex = 52;
			// 
			// pnlPump2Green
			// 
			this.pnlPump2Green.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPump2Green.BackgroundImage")));
			this.pnlPump2Green.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlPump2Green.Location = new System.Drawing.Point(314, 547);
			this.pnlPump2Green.Name = "pnlPump2Green";
			this.pnlPump2Green.Size = new System.Drawing.Size(84, 84);
			this.pnlPump2Green.TabIndex = 51;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label1.Location = new System.Drawing.Point(425, 546);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(66, 86);
			this.label1.TabIndex = 50;
			this.label1.Text = "STBD BELT DRIVEN Pp";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPump1Green
			// 
			this.pnlPump1Green.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPump1Green.BackgroundImage")));
			this.pnlPump1Green.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlPump1Green.Location = new System.Drawing.Point(314, 281);
			this.pnlPump1Green.Name = "pnlPump1Green";
			this.pnlPump1Green.Size = new System.Drawing.Size(84, 84);
			this.pnlPump1Green.TabIndex = 49;
			// 
			// pnlPump3Red
			// 
			this.pnlPump3Red.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPump3Red.BackgroundImage")));
			this.pnlPump3Red.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlPump3Red.Location = new System.Drawing.Point(791, 313);
			this.pnlPump3Red.Name = "pnlPump3Red";
			this.pnlPump3Red.Size = new System.Drawing.Size(84, 84);
			this.pnlPump3Red.TabIndex = 48;
			// 
			// staticText5
			// 
			this.staticText5.BackColor = System.Drawing.Color.Transparent;
			this.staticText5.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText5.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText5.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText5.Location = new System.Drawing.Point(431, 533);
			this.staticText5.Name = "staticText5";
			this.staticText5.Size = new System.Drawing.Size(66, 86);
			this.staticText5.TabIndex = 42;
			this.staticText5.Text = "STBD BELT DRIVEN Pp";
			this.staticText5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText4
			// 
			this.staticText4.BackColor = System.Drawing.Color.Transparent;
			this.staticText4.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText4.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText4.Location = new System.Drawing.Point(425, 414);
			this.staticText4.Name = "staticText4";
			this.staticText4.Size = new System.Drawing.Size(66, 57);
			this.staticText4.TabIndex = 41;
			this.staticText4.Text = "FROM DRAIN TANK";
			this.staticText4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText3
			// 
			this.staticText3.BackColor = System.Drawing.Color.Transparent;
			this.staticText3.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText3.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText3.Location = new System.Drawing.Point(425, 280);
			this.staticText3.Name = "staticText3";
			this.staticText3.Size = new System.Drawing.Size(66, 86);
			this.staticText3.TabIndex = 40;
			this.staticText3.Text = "PORT BELT DRIVEN Pp";
			this.staticText3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText2
			// 
			this.staticText2.AutoSize = true;
			this.staticText2.BackColor = System.Drawing.Color.Transparent;
			this.staticText2.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText2.Location = new System.Drawing.Point(73, 665);
			this.staticText2.Name = "staticText2";
			this.staticText2.Size = new System.Drawing.Size(78, 19);
			this.staticText2.TabIndex = 39;
			this.staticText2.Text = "COOLER";
			this.staticText2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText1
			// 
			this.staticText1.AutoSize = true;
			this.staticText1.BackColor = System.Drawing.Color.Transparent;
			this.staticText1.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.staticText1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.staticText1.Location = new System.Drawing.Point(73, 177);
			this.staticText1.Name = "staticText1";
			this.staticText1.Size = new System.Drawing.Size(78, 19);
			this.staticText1.TabIndex = 38;
			this.staticText1.Text = "COOLER";
			this.staticText1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.White;
			this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlTop.Controls.Add(this.pnlTopInner);
			this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.pnlTop.Location = new System.Drawing.Point(25, 5);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1229, 96);
			this.pnlTop.TabIndex = 2;
			// 
			// pnlTopInner
			// 
			this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
			this.pnlTopInner.Controls.Add(this.lblPageName);
			this.pnlTopInner.Controls.Add(this.PageBack);
			this.pnlTopInner.Controls.Add(this.PageFwd);
			this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
			this.pnlTopInner.Name = "pnlTopInner";
			this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
			this.pnlTopInner.TabIndex = 0;
			// 
			// lblPageName
			// 
			this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName.ForeColor = System.Drawing.Color.White;
			this.lblPageName.Location = new System.Drawing.Point(175, 19);
			this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName.Name = "lblPageName";
			this.lblPageName.Size = new System.Drawing.Size(868, 49);
			this.lblPageName.TabIndex = 2;
			this.lblPageName.Text = "Main Lub Oil System";
			this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PageBack
			// 
			this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
			this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageBack.Location = new System.Drawing.Point(1103, 0);
			this.PageBack.Name = "PageBack";
			this.PageBack.Size = new System.Drawing.Size(116, 87);
			this.PageBack.TabIndex = 0;
			this.PageBack.TabStop = false;
			this.PageBack.Click += new System.EventHandler(this.PageBack_Click);
			// 
			// PageFwd
			// 
			this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
			this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageFwd.Location = new System.Drawing.Point(0, 0);
			this.PageFwd.Name = "PageFwd";
			this.PageFwd.Size = new System.Drawing.Size(116, 87);
			this.PageFwd.TabIndex = 1;
			this.PageFwd.TabStop = false;
			this.PageFwd.Click += new System.EventHandler(this.PageFwd_Click);
			// 
			// frmMainLubOil
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1280, 791);
			this.ControlBox = false;
			this.Controls.Add(this.pnlMainLubOil);
			this.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmMainLubOil";
			this.Text = "Main Lub Oil";
			this.pnlMainLubOil.ResumeLayout(false);
			this.pnlMainLubOil.PerformLayout();
			this.pnlADLOPump.ResumeLayout(false);
			this.pnlTop.ResumeLayout(false);
			this.pnlTopInner.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlMainLubOil;
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.PictureBox PageBack;
		private System.Windows.Forms.PictureBox PageFwd;
		private System.Windows.Forms.Label staticText5;
		private System.Windows.Forms.Label staticText4;
		private System.Windows.Forms.Label staticText3;
		private System.Windows.Forms.Label staticText2;
		private System.Windows.Forms.Label staticText1;
		private System.Windows.Forms.Panel pnlPump2Green;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel pnlPump1Green;
		private System.Windows.Forms.Panel pnlPump3Red;
		private System.Windows.Forms.Panel pnlVlv2Clsd;
		private System.Windows.Forms.Panel pnlVlv1Opn;
		private System.Windows.Forms.Label staticText14;
		private System.Windows.Forms.Label staticText13;
		private System.Windows.Forms.Label staticText12;
		private System.Windows.Forms.Panel pnlADLOPump;
		private System.Windows.Forms.Label lblADLOPump;
		private System.Windows.Forms.Panel pnlPump4Green;
		private System.Windows.Forms.Label staticText11;
		private System.Windows.Forms.Label staticText10;
		private System.Windows.Forms.Label staticText9;
		private System.Windows.Forms.Label staticText8;
		private System.Windows.Forms.Label staticText7;
		private System.Windows.Forms.Label staticText6;
		private System.Windows.Forms.Label staticText16;
		private System.Windows.Forms.Label staticText15;
		private System.Windows.Forms.Panel pnlVlvADLO;
		private System.Windows.Forms.Label lblMGR;
		private System.Windows.Forms.Label lblGTR;
	}
}