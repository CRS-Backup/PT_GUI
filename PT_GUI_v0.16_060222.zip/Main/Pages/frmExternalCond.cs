﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtGui
{
	public partial class frmExternalCond : Form

	{
		public frmExternalCond()
		{
			InitializeComponent();
			this.StartPosition = FormStartPosition.Manual;
			this.Location = new Point(0, 0);
		}

		private void pnlAirTemp_MouseDown(object sender, EventArgs e)
		{
			Bitmap bitmap = new Bitmap(Constants.BMP_LONG_BUTTON_GREEN_DOWN);
			pnlAirTemp.BackgroundImage = bitmap;
		}

		private void pnlAirTemp_MouseLeave(object sender, EventArgs e)
		{
			Bitmap bitmap = new Bitmap(Constants.BMP_LONG_BUTTON_GREEN_UP);
			pnlAirTemp.BackgroundImage = bitmap;
		}

		private void pnllAirTemp_Click(object sender, EventArgs e)
		{
			GuiCore.show_form("frmExternalCond",null);

			//TODO - get remote form reference to allow updates to values

			//Form frm = get_form("frmNumberKeypad");
			//frm.TitleLabel = "Outside Air Temperature";
			//frm.MaxValue = "30°C";
			//formList.newNumberKeypad.MinValue = "-20°C";
			//formList.newNumberKeypad.Show();

			//original code
			//formList.newNumberKeypad.TitleLabel = "Outside Air Temperature";
			//formList.newNumberKeypad.MaxValue = "30°C";
			//formList.newNumberKeypad.MinValue = "-20°C";
			//formList.newNumberKeypad.Show();
			//formList.newNumberKeypad.BringToFront();


		}

		private void pnlElecBlock_Click(object sender, EventArgs e)
		{
			//the user wants to be able to update the Electrical Block Load Changes

			//Get the current value of the output
			double elec_block_value = GuiCore.get_chan_val_double("o_elec_load_change");

			//Write into a working copy
			GuiCore.set_channel_value("t_elec_load_change", elec_block_value);

			GuiCore.show_form("frmLoadChanges", null);

		}

		private void lblCrsOutsideAirTemp_TextChanged(object sender, EventArgs e)
        {
			//Update the text value with the new CRS channel value defined on this object
			//((CRSControlsLib.CrsLabel)sender).Text = GuiCore.getCrsChanValue(sender);
		}

        private void lblCrsElecBlock_TextChanged(object sender, EventArgs e)
        {
			//Update the text value with the new CRS channel value defined on this object
			//((CRSControlsLib.CrsLabel)sender).Text = GuiCore.getCrsChanValue(sender);

		}

        private void lblCrsSeaState_TextChanged(object sender, EventArgs e)
        {
			//Update the text value with the new CRS channel value defined on this object
			//((CRSControlsLib.CrsLabel)sender).Text = GuiCore.getCrsChanValue(sender);
		}

        private void cmdLoadHome_Click(object sender, EventArgs e)
        {
			GuiCore.show_form("frmMain", this);
		}

        private void crsLabel1_TextChanged(object sender, EventArgs e)
        {
			//Update the text value with the new CRS channel value defined on this object
			//((CRSControlsLib.CrsLabel)sender).Text = GuiCore.getCrsChanValue(sender);

		}

        private void pnlPanel4_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
