﻿
namespace PtGui
{
	partial class frmMasterPanel
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMasterPanel));
			this.pnlSelectionpanel10 = new System.Windows.Forms.Panel();
			this.label10_1 = new System.Windows.Forms.Label();
			this.label10_2 = new System.Windows.Forms.Label();
			this.pictureBox10 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel9 = new System.Windows.Forms.Panel();
			this.pnlSelectionpanel8 = new System.Windows.Forms.Panel();
			this.label8_1 = new System.Windows.Forms.Label();
			this.label8_2 = new System.Windows.Forms.Label();
			this.pictureBox8 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel2 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel3 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.pnlSelectionpanel4 = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel5 = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.pictureBox5 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel6 = new System.Windows.Forms.Panel();
			this.label6 = new System.Windows.Forms.Label();
			this.pictureBox6 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel7 = new System.Windows.Forms.Panel();
			this.label7 = new System.Windows.Forms.Label();
			this.pictureBox7 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel14 = new System.Windows.Forms.Panel();
			this.label14 = new System.Windows.Forms.Label();
			this.pictureBox14 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel15 = new System.Windows.Forms.Panel();
			this.label15 = new System.Windows.Forms.Label();
			this.pictureBox15 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel11 = new System.Windows.Forms.Panel();
			this.label11 = new System.Windows.Forms.Label();
			this.pictureBox11 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel12 = new System.Windows.Forms.Panel();
			this.label12 = new System.Windows.Forms.Label();
			this.pictureBox12 = new System.Windows.Forms.PictureBox();
			this.pnlselectionpanel13 = new System.Windows.Forms.Panel();
			this.label13 = new System.Windows.Forms.Label();
			this.pictureBox13 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel16 = new System.Windows.Forms.Panel();
			this.pictureBox16 = new System.Windows.Forms.PictureBox();
			this.label16 = new System.Windows.Forms.Label();
			this.pnlSelectionpanel17 = new System.Windows.Forms.Panel();
			this.label17 = new System.Windows.Forms.Label();
			this.pictureBox17 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel18 = new System.Windows.Forms.Panel();
			this.label18 = new System.Windows.Forms.Label();
			this.pictureBox18 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel19 = new System.Windows.Forms.Panel();
			this.label19 = new System.Windows.Forms.Label();
			this.pictureBox19 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel20 = new System.Windows.Forms.Panel();
			this.label20 = new System.Windows.Forms.Label();
			this.pictureBox20 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel21 = new System.Windows.Forms.Panel();
			this.label21 = new System.Windows.Forms.Label();
			this.pictureBox21 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel22 = new System.Windows.Forms.Panel();
			this.label22 = new System.Windows.Forms.Label();
			this.pictureBox22 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel23 = new System.Windows.Forms.Panel();
			this.label23 = new System.Windows.Forms.Label();
			this.pictureBox23 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel24 = new System.Windows.Forms.Panel();
			this.label24 = new System.Windows.Forms.Label();
			this.pnlSelectionpanel25 = new System.Windows.Forms.Panel();
			this.label25 = new System.Windows.Forms.Label();
			this.pictureBox25 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel26 = new System.Windows.Forms.Panel();
			this.label26 = new System.Windows.Forms.Label();
			this.pictureBox26 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel1 = new System.Windows.Forms.Panel();
			this.label1 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pnlSelectionpanel10.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
			this.pnlSelectionpanel8.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
			this.pnlSelectionpanel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			this.pnlSelectionpanel3.SuspendLayout();
			this.pnlSelectionpanel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			this.pnlSelectionpanel5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
			this.pnlSelectionpanel6.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
			this.pnlSelectionpanel7.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
			this.pnlSelectionpanel14.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
			this.pnlSelectionpanel15.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
			this.pnlSelectionpanel11.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
			this.pnlSelectionpanel12.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
			this.pnlselectionpanel13.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
			this.pnlSelectionpanel16.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
			this.pnlSelectionpanel17.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
			this.pnlSelectionpanel18.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
			this.pnlSelectionpanel19.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
			this.pnlSelectionpanel20.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
			this.pnlSelectionpanel21.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
			this.pnlSelectionpanel22.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
			this.pnlSelectionpanel23.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
			this.pnlSelectionpanel24.SuspendLayout();
			this.pnlSelectionpanel25.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
			this.pnlSelectionpanel26.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).BeginInit();
			this.pnlSelectionpanel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// pnlSelectionpanel10
			// 
			this.pnlSelectionpanel10.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel10.BackgroundImage")));
			this.pnlSelectionpanel10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel10.Controls.Add(this.label10_1);
			this.pnlSelectionpanel10.Controls.Add(this.label10_2);
			this.pnlSelectionpanel10.Controls.Add(this.pictureBox10);
			this.pnlSelectionpanel10.Location = new System.Drawing.Point(885, 0);
			this.pnlSelectionpanel10.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel10.Name = "pnlSelectionpanel10";
			this.pnlSelectionpanel10.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel10.TabIndex = 16;
			this.pnlSelectionpanel10.Click += new System.EventHandler(this.pnlSelectionpanel10_Click);
			this.pnlSelectionpanel10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel10_MouseDown);
			this.pnlSelectionpanel10.MouseLeave += new System.EventHandler(this.pnlSelectionpanel10_MouseLeave);
			// 
			// label10_1
			// 
			this.label10_1.AutoSize = true;
			this.label10_1.BackColor = System.Drawing.Color.Transparent;
			this.label10_1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10_1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label10_1.Location = new System.Drawing.Point(7, 14);
			this.label10_1.Name = "label10_1";
			this.label10_1.Size = new System.Drawing.Size(76, 16);
			this.label10_1.TabIndex = 9;
			this.label10_1.Text = "Run    Freeze";
			this.label10_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label10_1.Click += new System.EventHandler(this.pnlSelectionpanel10_Click);
			this.label10_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel10_MouseDown);
			this.label10_1.MouseLeave += new System.EventHandler(this.pnlSelectionpanel10_MouseLeave);
			// 
			// label10_2
			// 
			this.label10_2.AutoSize = true;
			this.label10_2.BackColor = System.Drawing.Color.Transparent;
			this.label10_2.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label10_2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label10_2.Location = new System.Drawing.Point(30, 81);
			this.label10_2.Name = "label10_2";
			this.label10_2.Size = new System.Drawing.Size(30, 16);
			this.label10_2.TabIndex = 8;
			this.label10_2.Text = "Run";
			this.label10_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label10_2.Click += new System.EventHandler(this.pnlSelectionpanel10_Click);
			this.label10_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel10_MouseDown);
			this.label10_2.MouseLeave += new System.EventHandler(this.pnlSelectionpanel10_MouseLeave);
			// 
			// pictureBox10
			// 
			this.pictureBox10.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox10.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox10.BackgroundImage")));
			this.pictureBox10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox10.Location = new System.Drawing.Point(21, 37);
			this.pictureBox10.Name = "pictureBox10";
			this.pictureBox10.Size = new System.Drawing.Size(49, 42);
			this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox10.TabIndex = 8;
			this.pictureBox10.TabStop = false;
			this.pictureBox10.Click += new System.EventHandler(this.pnlSelectionpanel10_Click);
			this.pictureBox10.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel10_MouseDown);
			this.pictureBox10.MouseLeave += new System.EventHandler(this.pnlSelectionpanel10_MouseLeave);
			// 
			// pnlSelectionpanel9
			// 
			this.pnlSelectionpanel9.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel9.BackgroundImage")));
			this.pnlSelectionpanel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel9.Location = new System.Drawing.Point(787, 0);
			this.pnlSelectionpanel9.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel9.Name = "pnlSelectionpanel9";
			this.pnlSelectionpanel9.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel9.TabIndex = 15;
			// 
			// pnlSelectionpanel8
			// 
			this.pnlSelectionpanel8.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel8.BackgroundImage")));
			this.pnlSelectionpanel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel8.Controls.Add(this.label8_1);
			this.pnlSelectionpanel8.Controls.Add(this.label8_2);
			this.pnlSelectionpanel8.Controls.Add(this.pictureBox8);
			this.pnlSelectionpanel8.Location = new System.Drawing.Point(689, 0);
			this.pnlSelectionpanel8.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel8.Name = "pnlSelectionpanel8";
			this.pnlSelectionpanel8.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel8.TabIndex = 14;
			this.pnlSelectionpanel8.Click += new System.EventHandler(this.pnlSelectionpanel8_Click);
			this.pnlSelectionpanel8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel8_MouseDown);
			this.pnlSelectionpanel8.MouseLeave += new System.EventHandler(this.pnlSelectionpanel8_MouseLeave);
			// 
			// label8_1
			// 
			this.label8_1.AutoSize = true;
			this.label8_1.BackColor = System.Drawing.Color.Transparent;
			this.label8_1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8_1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label8_1.Location = new System.Drawing.Point(9, 14);
			this.label8_1.Name = "label8_1";
			this.label8_1.Size = new System.Drawing.Size(77, 16);
			this.label8_1.TabIndex = 7;
			this.label8_1.Text = "Normal  Slow";
			this.label8_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label8_1.Click += new System.EventHandler(this.pnlSelectionpanel8_Click);
			this.label8_1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel8_MouseDown);
			this.label8_1.MouseLeave += new System.EventHandler(this.pnlSelectionpanel8_MouseLeave);
			// 
			// label8_2
			// 
			this.label8_2.AutoSize = true;
			this.label8_2.BackColor = System.Drawing.Color.Transparent;
			this.label8_2.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8_2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label8_2.Location = new System.Drawing.Point(25, 81);
			this.label8_2.Name = "label8_2";
			this.label8_2.Size = new System.Drawing.Size(45, 16);
			this.label8_2.TabIndex = 6;
			this.label8_2.Text = "Normal";
			this.label8_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label8_2.Click += new System.EventHandler(this.pnlSelectionpanel8_Click);
			this.label8_2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel8_MouseDown);
			this.label8_2.MouseLeave += new System.EventHandler(this.pnlSelectionpanel8_MouseLeave);
			// 
			// pictureBox8
			// 
			this.pictureBox8.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
			this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox8.Location = new System.Drawing.Point(23, 37);
			this.pictureBox8.Name = "pictureBox8";
			this.pictureBox8.Size = new System.Drawing.Size(49, 42);
			this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox8.TabIndex = 6;
			this.pictureBox8.TabStop = false;
			this.pictureBox8.Click += new System.EventHandler(this.pnlSelectionpanel8_Click);
			this.pictureBox8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel8_MouseDown);
			this.pictureBox8.MouseLeave += new System.EventHandler(this.pnlSelectionpanel8_MouseLeave);
			// 
			// pnlSelectionpanel2
			// 
			this.pnlSelectionpanel2.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel2.BackgroundImage")));
			this.pnlSelectionpanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel2.Controls.Add(this.label2);
			this.pnlSelectionpanel2.Controls.Add(this.pictureBox2);
			this.pnlSelectionpanel2.Location = new System.Drawing.Point(101, 0);
			this.pnlSelectionpanel2.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel2.Name = "pnlSelectionpanel2";
			this.pnlSelectionpanel2.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel2.TabIndex = 12;
			this.pnlSelectionpanel2.Click += new System.EventHandler(this.pnlSelectionpanel2_Click);
			this.pnlSelectionpanel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel2_MouseDown);
			this.pnlSelectionpanel2.MouseLeave += new System.EventHandler(this.pnlSelectionpanel2_MouseLeave);
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label2.Location = new System.Drawing.Point(15, 57);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(69, 49);
			this.label2.TabIndex = 10;
			this.label2.Text = "External Conditions";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label2.Click += new System.EventHandler(this.pnlSelectionpanel2_Click);
			this.label2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel2_MouseDown);
			this.label2.MouseLeave += new System.EventHandler(this.pnlSelectionpanel2_MouseLeave);
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
			this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pictureBox2.Location = new System.Drawing.Point(21, 14);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(55, 40);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.Click += new System.EventHandler(this.pnlSelectionpanel2_Click);
			this.pictureBox2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel2_MouseDown);
			this.pictureBox2.MouseLeave += new System.EventHandler(this.pnlSelectionpanel2_MouseLeave);
			// 
			// pictureBox3
			// 
			this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
			this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox3.Location = new System.Drawing.Point(18, 13);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(60, 42);
			this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox3.TabIndex = 2;
			this.pictureBox3.TabStop = false;
			this.pictureBox3.Click += new System.EventHandler(this.pnlSelectionpanel3_Click);
			this.pictureBox3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel3_MouseDown);
			this.pictureBox3.MouseLeave += new System.EventHandler(this.pnlSelectionpanel3_MouseLeave);
			// 
			// pnlSelectionpanel3
			// 
			this.pnlSelectionpanel3.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel3.BackgroundImage")));
			this.pnlSelectionpanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel3.Controls.Add(this.label3);
			this.pnlSelectionpanel3.Controls.Add(this.pictureBox3);
			this.pnlSelectionpanel3.Location = new System.Drawing.Point(199, 0);
			this.pnlSelectionpanel3.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel3.Name = "pnlSelectionpanel3";
			this.pnlSelectionpanel3.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel3.TabIndex = 13;
			this.pnlSelectionpanel3.Click += new System.EventHandler(this.pnlSelectionpanel3_Click);
			this.pnlSelectionpanel3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel3_MouseDown);
			this.pnlSelectionpanel3.MouseLeave += new System.EventHandler(this.pnlSelectionpanel3_MouseLeave);
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label3.Location = new System.Drawing.Point(21, 55);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(55, 49);
			this.label3.TabIndex = 9;
			this.label3.Text = "Resets";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label3.Click += new System.EventHandler(this.pnlSelectionpanel3_Click);
			this.label3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel3_MouseDown);
			this.label3.MouseLeave += new System.EventHandler(this.pnlSelectionpanel3_MouseLeave);
			// 
			// pnlSelectionpanel4
			// 
			this.pnlSelectionpanel4.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel4.BackgroundImage")));
			this.pnlSelectionpanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel4.Controls.Add(this.label4);
			this.pnlSelectionpanel4.Controls.Add(this.pictureBox4);
			this.pnlSelectionpanel4.Location = new System.Drawing.Point(296, 0);
			this.pnlSelectionpanel4.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel4.Name = "pnlSelectionpanel4";
			this.pnlSelectionpanel4.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel4.TabIndex = 14;
			this.pnlSelectionpanel4.Click += new System.EventHandler(this.pnlSelectionpanel4_Click);
			this.pnlSelectionpanel4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel4_MouseDown);
			this.pnlSelectionpanel4.MouseLeave += new System.EventHandler(this.pnlSelectionpanel4_MouseLeave);
			// 
			// label4
			// 
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label4.Location = new System.Drawing.Point(30, 57);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(36, 49);
			this.label4.TabIndex = 8;
			this.label4.Text = "SnapShot";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label4.Click += new System.EventHandler(this.pnlSelectionpanel4_Click);
			this.label4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel4_MouseDown);
			this.label4.MouseLeave += new System.EventHandler(this.pnlSelectionpanel4_MouseLeave);
			// 
			// pictureBox4
			// 
			this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.BackgroundImage")));
			this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox4.Location = new System.Drawing.Point(18, 13);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(60, 42);
			this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox4.TabIndex = 2;
			this.pictureBox4.TabStop = false;
			this.pictureBox4.Click += new System.EventHandler(this.pnlSelectionpanel4_Click);
			this.pictureBox4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel4_MouseDown);
			this.pictureBox4.MouseLeave += new System.EventHandler(this.pnlSelectionpanel4_MouseLeave);
			// 
			// pnlSelectionpanel5
			// 
			this.pnlSelectionpanel5.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel5.BackgroundImage")));
			this.pnlSelectionpanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel5.Controls.Add(this.label5);
			this.pnlSelectionpanel5.Controls.Add(this.pictureBox5);
			this.pnlSelectionpanel5.Location = new System.Drawing.Point(394, 0);
			this.pnlSelectionpanel5.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel5.Name = "pnlSelectionpanel5";
			this.pnlSelectionpanel5.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel5.TabIndex = 15;
			this.pnlSelectionpanel5.Click += new System.EventHandler(this.pnlSelectionpanel5_Click);
			this.pnlSelectionpanel5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel5_MouseDown);
			this.pnlSelectionpanel5.MouseLeave += new System.EventHandler(this.pnlSelectionpanel5_MouseLeave);
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label5.Location = new System.Drawing.Point(20, 57);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(61, 49);
			this.label5.TabIndex = 7;
			this.label5.Text = "Back Track";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label5.Click += new System.EventHandler(this.pnlSelectionpanel5_Click);
			this.label5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel5_MouseDown);
			this.label5.MouseLeave += new System.EventHandler(this.pnlSelectionpanel5_MouseLeave);
			// 
			// pictureBox5
			// 
			this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
			this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox5.Location = new System.Drawing.Point(24, 13);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new System.Drawing.Size(49, 42);
			this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox5.TabIndex = 2;
			this.pictureBox5.TabStop = false;
			this.pictureBox5.Click += new System.EventHandler(this.pnlSelectionpanel5_Click);
			this.pictureBox5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel5_MouseDown);
			this.pictureBox5.MouseLeave += new System.EventHandler(this.pnlSelectionpanel5_MouseLeave);
			// 
			// pnlSelectionpanel6
			// 
			this.pnlSelectionpanel6.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel6.BackgroundImage")));
			this.pnlSelectionpanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel6.Controls.Add(this.label6);
			this.pnlSelectionpanel6.Controls.Add(this.pictureBox6);
			this.pnlSelectionpanel6.Location = new System.Drawing.Point(493, 0);
			this.pnlSelectionpanel6.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel6.Name = "pnlSelectionpanel6";
			this.pnlSelectionpanel6.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel6.TabIndex = 16;
			this.pnlSelectionpanel6.Click += new System.EventHandler(this.pnlSelectionpanel6_Click);
			this.pnlSelectionpanel6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel6_MouseDown);
			this.pnlSelectionpanel6.MouseLeave += new System.EventHandler(this.pnlSelectionpanel6_MouseLeave);
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label6.Location = new System.Drawing.Point(18, 57);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(61, 49);
			this.label6.TabIndex = 6;
			this.label6.Text = "Panel Test";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label6.Click += new System.EventHandler(this.pnlSelectionpanel6_Click);
			this.label6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel6_MouseDown);
			this.label6.MouseLeave += new System.EventHandler(this.pnlSelectionpanel6_MouseLeave);
			// 
			// pictureBox6
			// 
			this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
			this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox6.Location = new System.Drawing.Point(24, 13);
			this.pictureBox6.Name = "pictureBox6";
			this.pictureBox6.Size = new System.Drawing.Size(49, 42);
			this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox6.TabIndex = 2;
			this.pictureBox6.TabStop = false;
			this.pictureBox6.Click += new System.EventHandler(this.pnlSelectionpanel6_Click);
			this.pictureBox6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel6_MouseDown);
			this.pictureBox6.MouseLeave += new System.EventHandler(this.pnlSelectionpanel6_MouseLeave);
			// 
			// pnlSelectionpanel7
			// 
			this.pnlSelectionpanel7.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel7.BackgroundImage")));
			this.pnlSelectionpanel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel7.Controls.Add(this.label7);
			this.pnlSelectionpanel7.Controls.Add(this.pictureBox7);
			this.pnlSelectionpanel7.Location = new System.Drawing.Point(591, 0);
			this.pnlSelectionpanel7.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel7.Name = "pnlSelectionpanel7";
			this.pnlSelectionpanel7.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel7.TabIndex = 31;
			this.pnlSelectionpanel7.Click += new System.EventHandler(this.pnlSelectionpanel7_Click);
			this.pnlSelectionpanel7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel7_MouseDown);
			this.pnlSelectionpanel7.MouseLeave += new System.EventHandler(this.pnlSelectionpanel7_MouseLeave);
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label7.Location = new System.Drawing.Point(14, 63);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(71, 37);
			this.label7.TabIndex = 5;
			this.label7.Text = "Panel Override ";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label7.Click += new System.EventHandler(this.pnlSelectionpanel7_Click);
			this.label7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel7_MouseDown);
			this.label7.MouseLeave += new System.EventHandler(this.pnlSelectionpanel7_MouseLeave);
			// 
			// pictureBox7
			// 
			this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
			this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox7.Location = new System.Drawing.Point(24, 13);
			this.pictureBox7.Name = "pictureBox7";
			this.pictureBox7.Size = new System.Drawing.Size(49, 42);
			this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox7.TabIndex = 2;
			this.pictureBox7.TabStop = false;
			this.pictureBox7.Click += new System.EventHandler(this.pnlSelectionpanel7_Click);
			this.pictureBox7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel7_MouseDown);
			this.pictureBox7.MouseLeave += new System.EventHandler(this.pnlSelectionpanel7_MouseLeave);
			// 
			// pnlSelectionpanel14
			// 
			this.pnlSelectionpanel14.BackColor = System.Drawing.Color.Green;
			this.pnlSelectionpanel14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel14.BackgroundImage")));
			this.pnlSelectionpanel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel14.Controls.Add(this.label14);
			this.pnlSelectionpanel14.Controls.Add(this.pictureBox14);
			this.pnlSelectionpanel14.Location = new System.Drawing.Point(3, 115);
			this.pnlSelectionpanel14.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel14.Name = "pnlSelectionpanel14";
			this.pnlSelectionpanel14.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel14.TabIndex = 12;
			// 
			// label14
			// 
			this.label14.BackColor = System.Drawing.Color.Transparent;
			this.label14.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label14.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label14.Location = new System.Drawing.Point(8, 57);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(78, 49);
			this.label14.TabIndex = 12;
			this.label14.Text = "Clear All Malfunctions";
			this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox14
			// 
			this.pictureBox14.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox14.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox14.BackgroundImage")));
			this.pictureBox14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox14.Location = new System.Drawing.Point(8, 18);
			this.pictureBox14.Name = "pictureBox14";
			this.pictureBox14.Size = new System.Drawing.Size(78, 36);
			this.pictureBox14.TabIndex = 0;
			this.pictureBox14.TabStop = false;
			// 
			// pnlSelectionpanel15
			// 
			this.pnlSelectionpanel15.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel15.BackgroundImage")));
			this.pnlSelectionpanel15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel15.Controls.Add(this.label15);
			this.pnlSelectionpanel15.Controls.Add(this.pictureBox15);
			this.pnlSelectionpanel15.Location = new System.Drawing.Point(101, 116);
			this.pnlSelectionpanel15.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel15.Name = "pnlSelectionpanel15";
			this.pnlSelectionpanel15.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel15.TabIndex = 13;
			this.pnlSelectionpanel15.Click += new System.EventHandler(this.pnlSelectionpanel15_Click);
			this.pnlSelectionpanel15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel15_MouseDown);
			this.pnlSelectionpanel15.MouseLeave += new System.EventHandler(this.pnlSelectionpanel15_MouseLeave);
			// 
			// label15
			// 
			this.label15.BackColor = System.Drawing.Color.Transparent;
			this.label15.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label15.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label15.Location = new System.Drawing.Point(8, 57);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(78, 49);
			this.label15.TabIndex = 13;
			this.label15.Text = "Gas Turbine Malfunctions";
			this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label15.Click += new System.EventHandler(this.pnlSelectionpanel15_Click);
			this.label15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel15_MouseDown);
			this.label15.MouseLeave += new System.EventHandler(this.pnlSelectionpanel15_MouseLeave);
			// 
			// pictureBox15
			// 
			this.pictureBox15.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox15.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox15.BackgroundImage")));
			this.pictureBox15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox15.Location = new System.Drawing.Point(8, 18);
			this.pictureBox15.Name = "pictureBox15";
			this.pictureBox15.Size = new System.Drawing.Size(78, 36);
			this.pictureBox15.TabIndex = 0;
			this.pictureBox15.TabStop = false;
			this.pictureBox15.Click += new System.EventHandler(this.pnlSelectionpanel15_Click);
			this.pictureBox15.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel15_MouseDown);
			this.pictureBox15.MouseLeave += new System.EventHandler(this.pnlSelectionpanel15_MouseLeave);
			// 
			// pnlSelectionpanel11
			// 
			this.pnlSelectionpanel11.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel11.BackgroundImage")));
			this.pnlSelectionpanel11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel11.Controls.Add(this.label11);
			this.pnlSelectionpanel11.Controls.Add(this.pictureBox11);
			this.pnlSelectionpanel11.Location = new System.Drawing.Point(983, 0);
			this.pnlSelectionpanel11.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel11.Name = "pnlSelectionpanel11";
			this.pnlSelectionpanel11.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel11.TabIndex = 32;
			// 
			// label11
			// 
			this.label11.BackColor = System.Drawing.Color.Transparent;
			this.label11.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label11.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label11.Location = new System.Drawing.Point(10, 67);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(80, 37);
			this.label11.TabIndex = 0;
			this.label11.Text = "Outstation 1 Display";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox11
			// 
			this.pictureBox11.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox11.BackgroundImage")));
			this.pictureBox11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox11.Location = new System.Drawing.Point(24, 13);
			this.pictureBox11.Name = "pictureBox11";
			this.pictureBox11.Size = new System.Drawing.Size(49, 42);
			this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox11.TabIndex = 2;
			this.pictureBox11.TabStop = false;
			// 
			// pnlSelectionpanel12
			// 
			this.pnlSelectionpanel12.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel12.BackgroundImage")));
			this.pnlSelectionpanel12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel12.Controls.Add(this.label12);
			this.pnlSelectionpanel12.Controls.Add(this.pictureBox12);
			this.pnlSelectionpanel12.Location = new System.Drawing.Point(1081, 0);
			this.pnlSelectionpanel12.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel12.Name = "pnlSelectionpanel12";
			this.pnlSelectionpanel12.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel12.TabIndex = 33;
			this.pnlSelectionpanel12.Click += new System.EventHandler(this.pnlSelectionpanel12_Click);
			this.pnlSelectionpanel12.MouseLeave += new System.EventHandler(this.pnlSelectionpanel12_MouseLeave);
			// 
			// label12
			// 
			this.label12.BackColor = System.Drawing.Color.Transparent;
			this.label12.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label12.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label12.Location = new System.Drawing.Point(13, 67);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(71, 37);
			this.label12.TabIndex = 0;
			this.label12.Text = "Outstation Menu";
			this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label12.Click += new System.EventHandler(this.pnlSelectionpanel12_Click);
			this.label12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel12_MouseDown);
			this.label12.MouseLeave += new System.EventHandler(this.pnlSelectionpanel12_MouseLeave);
			// 
			// pictureBox12
			// 
			this.pictureBox12.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox12.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox12.BackgroundImage")));
			this.pictureBox12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox12.Location = new System.Drawing.Point(24, 13);
			this.pictureBox12.Name = "pictureBox12";
			this.pictureBox12.Size = new System.Drawing.Size(49, 42);
			this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox12.TabIndex = 2;
			this.pictureBox12.TabStop = false;
			this.pictureBox12.Click += new System.EventHandler(this.pnlSelectionpanel12_Click);
			this.pictureBox12.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel12_MouseDown);
			this.pictureBox12.MouseLeave += new System.EventHandler(this.pnlSelectionpanel12_MouseLeave);
			// 
			// pnlselectionpanel13
			// 
			this.pnlselectionpanel13.BackColor = System.Drawing.Color.Turquoise;
			this.pnlselectionpanel13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlselectionpanel13.BackgroundImage")));
			this.pnlselectionpanel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlselectionpanel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlselectionpanel13.Controls.Add(this.label13);
			this.pnlselectionpanel13.Controls.Add(this.pictureBox13);
			this.pnlselectionpanel13.Location = new System.Drawing.Point(1180, 0);
			this.pnlselectionpanel13.Margin = new System.Windows.Forms.Padding(0);
			this.pnlselectionpanel13.Name = "pnlselectionpanel13";
			this.pnlselectionpanel13.Size = new System.Drawing.Size(98, 114);
			this.pnlselectionpanel13.TabIndex = 33;
			// 
			// label13
			// 
			this.label13.BackColor = System.Drawing.Color.Transparent;
			this.label13.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label13.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label13.Location = new System.Drawing.Point(10, 67);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(80, 37);
			this.label13.TabIndex = 0;
			this.label13.Text = "Outstation 1 Display";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox13
			// 
			this.pictureBox13.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox13.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox13.BackgroundImage")));
			this.pictureBox13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox13.Location = new System.Drawing.Point(24, 13);
			this.pictureBox13.Name = "pictureBox13";
			this.pictureBox13.Size = new System.Drawing.Size(49, 42);
			this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox13.TabIndex = 2;
			this.pictureBox13.TabStop = false;
			// 
			// pnlSelectionpanel16
			// 
			this.pnlSelectionpanel16.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel16.BackgroundImage")));
			this.pnlSelectionpanel16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel16.Controls.Add(this.pictureBox16);
			this.pnlSelectionpanel16.Controls.Add(this.label16);
			this.pnlSelectionpanel16.Location = new System.Drawing.Point(199, 115);
			this.pnlSelectionpanel16.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel16.Name = "pnlSelectionpanel16";
			this.pnlSelectionpanel16.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel16.TabIndex = 14;
			this.pnlSelectionpanel16.Click += new System.EventHandler(this.pnlSelectionpanel16_Click);
			this.pnlSelectionpanel16.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel16_MouseDown);
			this.pnlSelectionpanel16.MouseLeave += new System.EventHandler(this.pnlSelectionpanel16_MouseLeave);
			// 
			// pictureBox16
			// 
			this.pictureBox16.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox16.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox16.BackgroundImage")));
			this.pictureBox16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox16.Location = new System.Drawing.Point(8, 10);
			this.pictureBox16.Name = "pictureBox16";
			this.pictureBox16.Size = new System.Drawing.Size(78, 54);
			this.pictureBox16.TabIndex = 0;
			this.pictureBox16.TabStop = false;
			this.pictureBox16.Click += new System.EventHandler(this.pnlSelectionpanel16_Click);
			this.pictureBox16.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel16_MouseDown);
			this.pictureBox16.MouseLeave += new System.EventHandler(this.pnlSelectionpanel16_MouseLeave);
			// 
			// label16
			// 
			this.label16.BackColor = System.Drawing.Color.Transparent;
			this.label16.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label16.Location = new System.Drawing.Point(8, 57);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(78, 49);
			this.label16.TabIndex = 13;
			this.label16.Text = "Propulsion Malfunctions";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label16.Click += new System.EventHandler(this.pnlSelectionpanel16_Click);
			this.label16.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel16_MouseDown);
			this.label16.MouseLeave += new System.EventHandler(this.pnlSelectionpanel16_MouseLeave);
			// 
			// pnlSelectionpanel17
			// 
			this.pnlSelectionpanel17.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel17.BackgroundImage")));
			this.pnlSelectionpanel17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel17.Controls.Add(this.label17);
			this.pnlSelectionpanel17.Controls.Add(this.pictureBox17);
			this.pnlSelectionpanel17.Location = new System.Drawing.Point(297, 116);
			this.pnlSelectionpanel17.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel17.Name = "pnlSelectionpanel17";
			this.pnlSelectionpanel17.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel17.TabIndex = 14;
			this.pnlSelectionpanel17.Click += new System.EventHandler(this.pnlSelectionpanel17_Click);
			this.pnlSelectionpanel17.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel17_MouseDown);
			this.pnlSelectionpanel17.MouseLeave += new System.EventHandler(this.pnlSelectionpanel17_MouseLeave);
			// 
			// label17
			// 
			this.label17.BackColor = System.Drawing.Color.Transparent;
			this.label17.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label17.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label17.Location = new System.Drawing.Point(8, 57);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(78, 49);
			this.label17.TabIndex = 13;
			this.label17.Text = "Gearbox Malfunctions";
			this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label17.Click += new System.EventHandler(this.pnlSelectionpanel17_Click);
			this.label17.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel17_MouseDown);
			this.label17.MouseLeave += new System.EventHandler(this.pnlSelectionpanel17_MouseLeave);
			// 
			// pictureBox17
			// 
			this.pictureBox17.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox17.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox17.BackgroundImage")));
			this.pictureBox17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox17.Location = new System.Drawing.Point(8, 18);
			this.pictureBox17.Name = "pictureBox17";
			this.pictureBox17.Size = new System.Drawing.Size(78, 36);
			this.pictureBox17.TabIndex = 0;
			this.pictureBox17.TabStop = false;
			this.pictureBox17.Click += new System.EventHandler(this.pnlSelectionpanel17_Click);
			this.pictureBox17.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel17_MouseDown);
			this.pictureBox17.MouseLeave += new System.EventHandler(this.pnlSelectionpanel17_MouseLeave);
			// 
			// pnlSelectionpanel18
			// 
			this.pnlSelectionpanel18.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel18.BackgroundImage")));
			this.pnlSelectionpanel18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel18.Controls.Add(this.label18);
			this.pnlSelectionpanel18.Controls.Add(this.pictureBox18);
			this.pnlSelectionpanel18.Location = new System.Drawing.Point(395, 115);
			this.pnlSelectionpanel18.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel18.Name = "pnlSelectionpanel18";
			this.pnlSelectionpanel18.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel18.TabIndex = 15;
			this.pnlSelectionpanel18.Click += new System.EventHandler(this.pnlSelectionpanel18_Click);
			this.pnlSelectionpanel18.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel18_MouseDown);
			this.pnlSelectionpanel18.MouseLeave += new System.EventHandler(this.pnlSelectionpanel18_MouseLeave);
			// 
			// label18
			// 
			this.label18.BackColor = System.Drawing.Color.Transparent;
			this.label18.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label18.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label18.Location = new System.Drawing.Point(8, 57);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(78, 49);
			this.label18.TabIndex = 13;
			this.label18.Text = "Diesel Gen Malfunctions";
			this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label18.Click += new System.EventHandler(this.pnlSelectionpanel18_Click);
			this.label18.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel18_MouseDown);
			this.label18.MouseLeave += new System.EventHandler(this.pnlSelectionpanel18_MouseLeave);
			// 
			// pictureBox18
			// 
			this.pictureBox18.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox18.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox18.BackgroundImage")));
			this.pictureBox18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox18.Location = new System.Drawing.Point(8, 18);
			this.pictureBox18.Name = "pictureBox18";
			this.pictureBox18.Size = new System.Drawing.Size(78, 36);
			this.pictureBox18.TabIndex = 0;
			this.pictureBox18.TabStop = false;
			this.pictureBox18.Click += new System.EventHandler(this.pnlSelectionpanel18_Click);
			this.pictureBox18.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel18_MouseDown);
			this.pictureBox18.MouseLeave += new System.EventHandler(this.pnlSelectionpanel18_MouseLeave);
			// 
			// pnlSelectionpanel19
			// 
			this.pnlSelectionpanel19.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel19.BackgroundImage")));
			this.pnlSelectionpanel19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel19.Controls.Add(this.label19);
			this.pnlSelectionpanel19.Controls.Add(this.pictureBox19);
			this.pnlSelectionpanel19.Location = new System.Drawing.Point(493, 116);
			this.pnlSelectionpanel19.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel19.Name = "pnlSelectionpanel19";
			this.pnlSelectionpanel19.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel19.TabIndex = 16;
			this.pnlSelectionpanel19.Click += new System.EventHandler(this.pnlSelectionpanel19_Click);
			this.pnlSelectionpanel19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel19_MouseDown);
			this.pnlSelectionpanel19.MouseLeave += new System.EventHandler(this.pnlSelectionpanel19_MouseLeave);
			// 
			// label19
			// 
			this.label19.BackColor = System.Drawing.Color.Transparent;
			this.label19.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label19.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label19.Location = new System.Drawing.Point(8, 57);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(78, 49);
			this.label19.TabIndex = 13;
			this.label19.Text = "Elec/MEPS Malfunctions";
			this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label19.Click += new System.EventHandler(this.pnlSelectionpanel19_Click);
			this.label19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel19_MouseDown);
			this.label19.MouseLeave += new System.EventHandler(this.pnlSelectionpanel19_MouseLeave);
			// 
			// pictureBox19
			// 
			this.pictureBox19.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox19.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox19.BackgroundImage")));
			this.pictureBox19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox19.Location = new System.Drawing.Point(8, 18);
			this.pictureBox19.Name = "pictureBox19";
			this.pictureBox19.Size = new System.Drawing.Size(78, 36);
			this.pictureBox19.TabIndex = 0;
			this.pictureBox19.TabStop = false;
			this.pictureBox19.Click += new System.EventHandler(this.pnlSelectionpanel19_Click);
			this.pictureBox19.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel19_MouseDown);
			this.pictureBox19.MouseLeave += new System.EventHandler(this.pnlSelectionpanel19_MouseLeave);
			// 
			// pnlSelectionpanel20
			// 
			this.pnlSelectionpanel20.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel20.BackgroundImage")));
			this.pnlSelectionpanel20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel20.Controls.Add(this.label20);
			this.pnlSelectionpanel20.Controls.Add(this.pictureBox20);
			this.pnlSelectionpanel20.Location = new System.Drawing.Point(591, 116);
			this.pnlSelectionpanel20.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel20.Name = "pnlSelectionpanel20";
			this.pnlSelectionpanel20.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel20.TabIndex = 17;
			this.pnlSelectionpanel20.Click += new System.EventHandler(this.pnlSelectionpanel20_Click);
			this.pnlSelectionpanel20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel20_MouseDown);
			this.pnlSelectionpanel20.MouseLeave += new System.EventHandler(this.pnlSelectionpanel20_MouseLeave);
			// 
			// label20
			// 
			this.label20.BackColor = System.Drawing.Color.Transparent;
			this.label20.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label20.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label20.Location = new System.Drawing.Point(8, 57);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(78, 49);
			this.label20.TabIndex = 13;
			this.label20.Text = "Maint Malfunctions";
			this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label20.Click += new System.EventHandler(this.pnlSelectionpanel20_Click);
			this.label20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel20_MouseDown);
			this.label20.MouseLeave += new System.EventHandler(this.pnlSelectionpanel20_MouseLeave);
			// 
			// pictureBox20
			// 
			this.pictureBox20.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox20.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox20.BackgroundImage")));
			this.pictureBox20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox20.Location = new System.Drawing.Point(8, 18);
			this.pictureBox20.Name = "pictureBox20";
			this.pictureBox20.Size = new System.Drawing.Size(78, 36);
			this.pictureBox20.TabIndex = 0;
			this.pictureBox20.TabStop = false;
			this.pictureBox20.Click += new System.EventHandler(this.pnlSelectionpanel20_Click);
			this.pictureBox20.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel20_MouseDown);
			this.pictureBox20.MouseLeave += new System.EventHandler(this.pnlSelectionpanel20_MouseLeave);
			// 
			// pnlSelectionpanel21
			// 
			this.pnlSelectionpanel21.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel21.BackgroundImage")));
			this.pnlSelectionpanel21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel21.Controls.Add(this.label21);
			this.pnlSelectionpanel21.Controls.Add(this.pictureBox21);
			this.pnlSelectionpanel21.Location = new System.Drawing.Point(689, 115);
			this.pnlSelectionpanel21.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel21.Name = "pnlSelectionpanel21";
			this.pnlSelectionpanel21.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel21.TabIndex = 19;
			this.pnlSelectionpanel21.Click += new System.EventHandler(this.pnlSelectionpanel21_Click);
			this.pnlSelectionpanel21.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel21_MouseDown);
			this.pnlSelectionpanel21.MouseLeave += new System.EventHandler(this.pnlSelectionpanel21_MouseLeave);
			// 
			// label21
			// 
			this.label21.BackColor = System.Drawing.Color.Transparent;
			this.label21.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label21.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label21.Location = new System.Drawing.Point(8, 57);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(78, 49);
			this.label21.TabIndex = 13;
			this.label21.Text = "Misc Malfunctions";
			this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label21.Click += new System.EventHandler(this.pnlSelectionpanel21_Click);
			this.label21.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel21_MouseDown);
			this.label21.MouseLeave += new System.EventHandler(this.pnlSelectionpanel21_MouseLeave);
			// 
			// pictureBox21
			// 
			this.pictureBox21.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox21.BackgroundImage")));
			this.pictureBox21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox21.Location = new System.Drawing.Point(8, 18);
			this.pictureBox21.Name = "pictureBox21";
			this.pictureBox21.Size = new System.Drawing.Size(78, 36);
			this.pictureBox21.TabIndex = 0;
			this.pictureBox21.TabStop = false;
			this.pictureBox21.Click += new System.EventHandler(this.pnlSelectionpanel21_Click);
			this.pictureBox21.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel21_MouseDown);
			this.pictureBox21.MouseLeave += new System.EventHandler(this.pnlSelectionpanel21_MouseLeave);
			// 
			// pnlSelectionpanel22
			// 
			this.pnlSelectionpanel22.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel22.BackgroundImage")));
			this.pnlSelectionpanel22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel22.Controls.Add(this.label22);
			this.pnlSelectionpanel22.Controls.Add(this.pictureBox22);
			this.pnlSelectionpanel22.Location = new System.Drawing.Point(787, 116);
			this.pnlSelectionpanel22.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel22.Name = "pnlSelectionpanel22";
			this.pnlSelectionpanel22.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel22.TabIndex = 34;
			this.pnlSelectionpanel22.Click += new System.EventHandler(this.pnlSelectionpanel22_Click);
			this.pnlSelectionpanel22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel22_MouseDown);
			this.pnlSelectionpanel22.MouseLeave += new System.EventHandler(this.pnlSelectionpanel22_MouseLeave);
			// 
			// label22
			// 
			this.label22.BackColor = System.Drawing.Color.Transparent;
			this.label22.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label22.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label22.Location = new System.Drawing.Point(8, 57);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(78, 49);
			this.label22.TabIndex = 13;
			this.label22.Text = "Consquent Malfunctions";
			this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label22.Click += new System.EventHandler(this.pnlSelectionpanel22_Click);
			this.label22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel22_MouseDown);
			this.label22.MouseLeave += new System.EventHandler(this.pnlSelectionpanel22_MouseLeave);
			// 
			// pictureBox22
			// 
			this.pictureBox22.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox22.BackgroundImage")));
			this.pictureBox22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox22.Location = new System.Drawing.Point(8, 18);
			this.pictureBox22.Name = "pictureBox22";
			this.pictureBox22.Size = new System.Drawing.Size(78, 36);
			this.pictureBox22.TabIndex = 0;
			this.pictureBox22.TabStop = false;
			this.pictureBox22.Click += new System.EventHandler(this.pnlSelectionpanel22_Click);
			this.pictureBox22.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel22_MouseDown);
			this.pictureBox22.MouseLeave += new System.EventHandler(this.pnlSelectionpanel22_MouseLeave);
			// 
			// pnlSelectionpanel23
			// 
			this.pnlSelectionpanel23.BackColor = System.Drawing.Color.Red;
			this.pnlSelectionpanel23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel23.BackgroundImage")));
			this.pnlSelectionpanel23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel23.Controls.Add(this.label23);
			this.pnlSelectionpanel23.Controls.Add(this.pictureBox23);
			this.pnlSelectionpanel23.Location = new System.Drawing.Point(885, 116);
			this.pnlSelectionpanel23.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel23.Name = "pnlSelectionpanel23";
			this.pnlSelectionpanel23.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel23.TabIndex = 35;
			this.pnlSelectionpanel23.Click += new System.EventHandler(this.pnlSelectionpanel23_Click);
			this.pnlSelectionpanel23.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel23_MouseDown);
			this.pnlSelectionpanel23.MouseLeave += new System.EventHandler(this.pnlSelectionpanel23_MouseLeave);
			// 
			// label23
			// 
			this.label23.BackColor = System.Drawing.Color.Transparent;
			this.label23.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label23.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label23.Location = new System.Drawing.Point(8, 57);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(78, 49);
			this.label23.TabIndex = 13;
			this.label23.Text = "Active Malfunctions";
			this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label23.Click += new System.EventHandler(this.pnlSelectionpanel23_Click);
			this.label23.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel23_MouseDown);
			this.label23.MouseLeave += new System.EventHandler(this.pnlSelectionpanel23_MouseLeave);
			// 
			// pictureBox23
			// 
			this.pictureBox23.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox23.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox23.BackgroundImage")));
			this.pictureBox23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox23.Location = new System.Drawing.Point(8, 18);
			this.pictureBox23.Name = "pictureBox23";
			this.pictureBox23.Size = new System.Drawing.Size(78, 36);
			this.pictureBox23.TabIndex = 0;
			this.pictureBox23.TabStop = false;
			this.pictureBox23.Click += new System.EventHandler(this.pnlSelectionpanel23_Click);
			this.pictureBox23.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel23_MouseDown);
			this.pictureBox23.MouseLeave += new System.EventHandler(this.pnlSelectionpanel23_MouseLeave);
			// 
			// pnlSelectionpanel24
			// 
			this.pnlSelectionpanel24.BackColor = System.Drawing.Color.Green;
			this.pnlSelectionpanel24.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel24.BackgroundImage")));
			this.pnlSelectionpanel24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel24.Controls.Add(this.label24);
			this.pnlSelectionpanel24.Location = new System.Drawing.Point(983, 116);
			this.pnlSelectionpanel24.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel24.Name = "pnlSelectionpanel24";
			this.pnlSelectionpanel24.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel24.TabIndex = 36;
			// 
			// label24
			// 
			this.label24.BackColor = System.Drawing.Color.Transparent;
			this.label24.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label24.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label24.Location = new System.Drawing.Point(22, 57);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(53, 49);
			this.label24.TabIndex = 12;
			this.label24.Text = "Title Page";
			this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlSelectionpanel25
			// 
			this.pnlSelectionpanel25.BackColor = System.Drawing.Color.Green;
			this.pnlSelectionpanel25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel25.BackgroundImage")));
			this.pnlSelectionpanel25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel25.Controls.Add(this.label25);
			this.pnlSelectionpanel25.Controls.Add(this.pictureBox25);
			this.pnlSelectionpanel25.Location = new System.Drawing.Point(1081, 116);
			this.pnlSelectionpanel25.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel25.Name = "pnlSelectionpanel25";
			this.pnlSelectionpanel25.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel25.TabIndex = 37;
			this.pnlSelectionpanel25.Click += new System.EventHandler(this.pnlSelectionpanel25_Click);
			this.pnlSelectionpanel25.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel25_MouseDown);
			this.pnlSelectionpanel25.MouseLeave += new System.EventHandler(this.pnlSelectionpanel25_MouseLeave);
			// 
			// label25
			// 
			this.label25.BackColor = System.Drawing.Color.Transparent;
			this.label25.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label25.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label25.Location = new System.Drawing.Point(24, 57);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(46, 49);
			this.label25.TabIndex = 12;
			this.label25.Text = "Last Page";
			this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label25.Click += new System.EventHandler(this.pnlSelectionpanel25_Click);
			this.label25.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel25_MouseDown);
			this.label25.MouseLeave += new System.EventHandler(this.pnlSelectionpanel25_MouseLeave);
			// 
			// pictureBox25
			// 
			this.pictureBox25.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox25.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox25.BackgroundImage")));
			this.pictureBox25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox25.Location = new System.Drawing.Point(8, 18);
			this.pictureBox25.Name = "pictureBox25";
			this.pictureBox25.Size = new System.Drawing.Size(78, 36);
			this.pictureBox25.TabIndex = 0;
			this.pictureBox25.TabStop = false;
			this.pictureBox25.Click += new System.EventHandler(this.pnlSelectionpanel25_Click);
			this.pictureBox25.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel25_MouseDown);
			this.pictureBox25.MouseLeave += new System.EventHandler(this.pnlSelectionpanel25_MouseLeave);
			// 
			// pnlSelectionpanel26
			// 
			this.pnlSelectionpanel26.BackColor = System.Drawing.Color.Green;
			this.pnlSelectionpanel26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel26.BackgroundImage")));
			this.pnlSelectionpanel26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel26.Controls.Add(this.label26);
			this.pnlSelectionpanel26.Controls.Add(this.pictureBox26);
			this.pnlSelectionpanel26.Location = new System.Drawing.Point(1180, 116);
			this.pnlSelectionpanel26.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel26.Name = "pnlSelectionpanel26";
			this.pnlSelectionpanel26.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel26.TabIndex = 38;
			// 
			// label26
			// 
			this.label26.BackColor = System.Drawing.Color.Transparent;
			this.label26.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label26.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label26.Location = new System.Drawing.Point(24, 57);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(46, 49);
			this.label26.TabIndex = 12;
			this.label26.Text = "Hard Copy";
			this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox26
			// 
			this.pictureBox26.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox26.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox26.BackgroundImage")));
			this.pictureBox26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pictureBox26.Location = new System.Drawing.Point(8, 18);
			this.pictureBox26.Name = "pictureBox26";
			this.pictureBox26.Size = new System.Drawing.Size(78, 36);
			this.pictureBox26.TabIndex = 0;
			this.pictureBox26.TabStop = false;
			// 
			// pnlSelectionpanel1
			// 
			this.pnlSelectionpanel1.BackColor = System.Drawing.Color.Turquoise;
			this.pnlSelectionpanel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlSelectionpanel1.BackgroundImage")));
			this.pnlSelectionpanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlSelectionpanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlSelectionpanel1.Controls.Add(this.label1);
			this.pnlSelectionpanel1.Controls.Add(this.pictureBox1);
			this.pnlSelectionpanel1.Location = new System.Drawing.Point(3, 0);
			this.pnlSelectionpanel1.Margin = new System.Windows.Forms.Padding(0);
			this.pnlSelectionpanel1.Name = "pnlSelectionpanel1";
			this.pnlSelectionpanel1.Size = new System.Drawing.Size(98, 114);
			this.pnlSelectionpanel1.TabIndex = 39;
			this.pnlSelectionpanel1.Click += new System.EventHandler(this.pnlSelectionpanel1_Click);
			this.pnlSelectionpanel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel1_MouseDown);
			this.pnlSelectionpanel1.MouseLeave += new System.EventHandler(this.pnlSelectionpanel1_MouseLeave);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label1.Location = new System.Drawing.Point(15, 57);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(69, 49);
			this.label1.TabIndex = 10;
			this.label1.Text = "Internal Conditions";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.label1.Click += new System.EventHandler(this.pnlSelectionpanel1_Click);
			this.label1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel1_MouseDown);
			this.label1.MouseLeave += new System.EventHandler(this.pnlSelectionpanel1_MouseLeave);
			// 
			// pictureBox1
			// 
			this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
			this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.pictureBox1.Location = new System.Drawing.Point(22, 14);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(55, 40);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pnlSelectionpanel1_Click);
			this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlSelectionpanel1_MouseDown);
			this.pictureBox1.MouseLeave += new System.EventHandler(this.pnlSelectionpanel1_MouseLeave);
			// 
			// frmMasterPanel
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.ClientSize = new System.Drawing.Size(1280, 229);
			this.Controls.Add(this.pnlSelectionpanel1);
			this.Controls.Add(this.pnlSelectionpanel26);
			this.Controls.Add(this.pnlSelectionpanel25);
			this.Controls.Add(this.pnlSelectionpanel24);
			this.Controls.Add(this.pnlSelectionpanel23);
			this.Controls.Add(this.pnlSelectionpanel22);
			this.Controls.Add(this.pnlSelectionpanel21);
			this.Controls.Add(this.pnlSelectionpanel20);
			this.Controls.Add(this.pnlSelectionpanel19);
			this.Controls.Add(this.pnlSelectionpanel18);
			this.Controls.Add(this.pnlSelectionpanel17);
			this.Controls.Add(this.pnlSelectionpanel16);
			this.Controls.Add(this.pnlselectionpanel13);
			this.Controls.Add(this.pnlSelectionpanel12);
			this.Controls.Add(this.pnlSelectionpanel11);
			this.Controls.Add(this.pnlSelectionpanel15);
			this.Controls.Add(this.pnlSelectionpanel14);
			this.Controls.Add(this.pnlSelectionpanel7);
			this.Controls.Add(this.pnlSelectionpanel6);
			this.Controls.Add(this.pnlSelectionpanel5);
			this.Controls.Add(this.pnlSelectionpanel4);
			this.Controls.Add(this.pnlSelectionpanel3);
			this.Controls.Add(this.pnlSelectionpanel8);
			this.Controls.Add(this.pnlSelectionpanel2);
			this.Controls.Add(this.pnlSelectionpanel9);
			this.Controls.Add(this.pnlSelectionpanel10);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmMasterPanel";
			this.Text = "Master Panel";
			this.pnlSelectionpanel10.ResumeLayout(false);
			this.pnlSelectionpanel10.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
			this.pnlSelectionpanel8.ResumeLayout(false);
			this.pnlSelectionpanel8.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
			this.pnlSelectionpanel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			this.pnlSelectionpanel3.ResumeLayout(false);
			this.pnlSelectionpanel4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			this.pnlSelectionpanel5.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
			this.pnlSelectionpanel6.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
			this.pnlSelectionpanel7.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
			this.pnlSelectionpanel14.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
			this.pnlSelectionpanel15.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
			this.pnlSelectionpanel11.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
			this.pnlSelectionpanel12.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
			this.pnlselectionpanel13.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
			this.pnlSelectionpanel16.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
			this.pnlSelectionpanel17.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
			this.pnlSelectionpanel18.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
			this.pnlSelectionpanel19.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
			this.pnlSelectionpanel20.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
			this.pnlSelectionpanel21.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
			this.pnlSelectionpanel22.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
			this.pnlSelectionpanel23.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
			this.pnlSelectionpanel24.ResumeLayout(false);
			this.pnlSelectionpanel25.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
			this.pnlSelectionpanel26.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox26)).EndInit();
			this.pnlSelectionpanel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlSelectionpanel10;
		private System.Windows.Forms.Panel pnlSelectionpanel9;
		private System.Windows.Forms.Panel pnlSelectionpanel8;
		private System.Windows.Forms.Panel pnlSelectionpanel2;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.PictureBox pictureBox3;
		private System.Windows.Forms.Panel pnlSelectionpanel3;
		private System.Windows.Forms.Panel pnlSelectionpanel4;
		private System.Windows.Forms.PictureBox pictureBox4;
		private System.Windows.Forms.Panel pnlSelectionpanel5;
		private System.Windows.Forms.PictureBox pictureBox5;
		private System.Windows.Forms.Panel pnlSelectionpanel6;
		private System.Windows.Forms.PictureBox pictureBox6;
		private System.Windows.Forms.Panel pnlSelectionpanel7;
		private System.Windows.Forms.PictureBox pictureBox7;
		private System.Windows.Forms.Panel pnlSelectionpanel14;
		private System.Windows.Forms.PictureBox pictureBox14;
		private System.Windows.Forms.Panel pnlSelectionpanel15;
		private System.Windows.Forms.PictureBox pictureBox15;
		private System.Windows.Forms.Panel pnlSelectionpanel11;
		private System.Windows.Forms.PictureBox pictureBox11;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label10_1;
		private System.Windows.Forms.Label label10_2;
		private System.Windows.Forms.PictureBox pictureBox10;
		private System.Windows.Forms.Label label8_1;
		private System.Windows.Forms.Label label8_2;
		private System.Windows.Forms.PictureBox pictureBox8;
		private System.Windows.Forms.Panel pnlSelectionpanel12;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.PictureBox pictureBox12;
		private System.Windows.Forms.Panel pnlselectionpanel13;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.PictureBox pictureBox13;
		private System.Windows.Forms.Panel pnlSelectionpanel16;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.PictureBox pictureBox16;
		private System.Windows.Forms.Panel pnlSelectionpanel17;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.PictureBox pictureBox17;
		private System.Windows.Forms.Panel pnlSelectionpanel18;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.PictureBox pictureBox18;
		private System.Windows.Forms.Panel pnlSelectionpanel19;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.PictureBox pictureBox19;
		private System.Windows.Forms.Panel pnlSelectionpanel20;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.PictureBox pictureBox20;
		private System.Windows.Forms.Panel pnlSelectionpanel21;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.PictureBox pictureBox21;
		private System.Windows.Forms.Panel pnlSelectionpanel22;
		private System.Windows.Forms.Label label22;
		private System.Windows.Forms.PictureBox pictureBox22;
		private System.Windows.Forms.Panel pnlSelectionpanel23;
		private System.Windows.Forms.Label label23;
		private System.Windows.Forms.PictureBox pictureBox23;
		private System.Windows.Forms.Panel pnlSelectionpanel24;
		private System.Windows.Forms.Label label24;
		private System.Windows.Forms.Panel pnlSelectionpanel25;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.PictureBox pictureBox25;
		private System.Windows.Forms.Panel pnlSelectionpanel26;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.PictureBox pictureBox26;
		private System.Windows.Forms.Panel pnlSelectionpanel1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.PictureBox pictureBox1;
	}
}