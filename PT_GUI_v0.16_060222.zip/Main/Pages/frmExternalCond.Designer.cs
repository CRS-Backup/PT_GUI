﻿
namespace PtGui
{
    partial class frmExternalCond
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmExternalCond));
            this.pnlTop = new System.Windows.Forms.Panel();
            this.pnlTopInner = new System.Windows.Forms.Panel();
            this.lblPageName = new System.Windows.Forms.Label();
            this.PageBack = new System.Windows.Forms.PictureBox();
            this.PageFwd = new System.Windows.Forms.PictureBox();
            this.pnlExternalCond = new System.Windows.Forms.Panel();
            this.lblCrsScrollDisplay = new CRSControlsLib.CrsLabel();
            this.crsLabel1 = new CRSControlsLib.CrsLabel();
            this.cmdLoadHome = new System.Windows.Forms.Button();
            this.pnlPanel7 = new System.Windows.Forms.Panel();
            this.lblShoreSuppAft = new System.Windows.Forms.Label();
            this.lblPanel7 = new System.Windows.Forms.Label();
            this.pnlPanel4 = new System.Windows.Forms.Panel();
            this.lblCrsElecSetBlock = new CRSControlsLib.CrsLabel();
            this.lblPanel4 = new System.Windows.Forms.Label();
            this.pnlPanel6 = new System.Windows.Forms.Panel();
            this.lblGTIcing = new System.Windows.Forms.Label();
            this.lblPanel6 = new System.Windows.Forms.Label();
            this.pnlPanel3 = new System.Windows.Forms.Panel();
            this.lblShoreSuppFwd = new System.Windows.Forms.Label();
            this.lblPanel3 = new System.Windows.Forms.Label();
            this.pnlPanel5 = new System.Windows.Forms.Panel();
            this.lblCrsSeaState = new CRSControlsLib.CrsLabel();
            this.lblSeaState = new System.Windows.Forms.Label();
            this.lblPanel5 = new System.Windows.Forms.Label();
            this.pnlPanel2 = new System.Windows.Forms.Panel();
            this.lblTowedArray = new System.Windows.Forms.Label();
            this.lblPanel2 = new System.Windows.Forms.Label();
            this.pnlAirTemp = new System.Windows.Forms.Panel();
            this.lblCrsOutsideAirTemp = new CRSControlsLib.CrsLabel();
            this.lblAirTemp = new System.Windows.Forms.Label();
            this.lblPanel1 = new System.Windows.Forms.Label();
            this.pnlTop.SuspendLayout();
            this.pnlTopInner.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
            this.pnlExternalCond.SuspendLayout();
            this.pnlPanel7.SuspendLayout();
            this.pnlPanel4.SuspendLayout();
            this.pnlPanel6.SuspendLayout();
            this.pnlPanel3.SuspendLayout();
            this.pnlPanel5.SuspendLayout();
            this.pnlPanel2.SuspendLayout();
            this.pnlAirTemp.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.White;
            this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlTop.Controls.Add(this.pnlTopInner);
            this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.pnlTop.Location = new System.Drawing.Point(25, 5);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Size = new System.Drawing.Size(1229, 96);
            this.pnlTop.TabIndex = 1;
            // 
            // pnlTopInner
            // 
            this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
            this.pnlTopInner.Controls.Add(this.lblPageName);
            this.pnlTopInner.Controls.Add(this.PageBack);
            this.pnlTopInner.Controls.Add(this.PageFwd);
            this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
            this.pnlTopInner.Name = "pnlTopInner";
            this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
            this.pnlTopInner.TabIndex = 0;
            // 
            // lblPageName
            // 
            this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageName.ForeColor = System.Drawing.Color.White;
            this.lblPageName.Location = new System.Drawing.Point(175, 19);
            this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblPageName.Name = "lblPageName";
            this.lblPageName.Size = new System.Drawing.Size(868, 49);
            this.lblPageName.TabIndex = 2;
            this.lblPageName.Text = "External Conditions";
            this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PageBack
            // 
            this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
            this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PageBack.Location = new System.Drawing.Point(1103, 0);
            this.PageBack.Name = "PageBack";
            this.PageBack.Size = new System.Drawing.Size(116, 87);
            this.PageBack.TabIndex = 0;
            this.PageBack.TabStop = false;
            // 
            // PageFwd
            // 
            this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
            this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PageFwd.Location = new System.Drawing.Point(0, 0);
            this.PageFwd.Name = "PageFwd";
            this.PageFwd.Size = new System.Drawing.Size(116, 87);
            this.PageFwd.TabIndex = 1;
            this.PageFwd.TabStop = false;
            // 
            // pnlExternalCond
            // 
            this.pnlExternalCond.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.pnlExternalCond.Controls.Add(this.lblCrsScrollDisplay);
            this.pnlExternalCond.Controls.Add(this.crsLabel1);
            this.pnlExternalCond.Controls.Add(this.cmdLoadHome);
            this.pnlExternalCond.Controls.Add(this.pnlPanel7);
            this.pnlExternalCond.Controls.Add(this.pnlPanel4);
            this.pnlExternalCond.Controls.Add(this.pnlPanel6);
            this.pnlExternalCond.Controls.Add(this.pnlPanel3);
            this.pnlExternalCond.Controls.Add(this.pnlPanel5);
            this.pnlExternalCond.Controls.Add(this.pnlPanel2);
            this.pnlExternalCond.Controls.Add(this.pnlAirTemp);
            this.pnlExternalCond.Controls.Add(this.pnlTop);
            this.pnlExternalCond.Cursor = System.Windows.Forms.Cursors.Default;
            this.pnlExternalCond.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlExternalCond.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pnlExternalCond.Location = new System.Drawing.Point(0, 0);
            this.pnlExternalCond.Name = "pnlExternalCond";
            this.pnlExternalCond.Size = new System.Drawing.Size(1280, 791);
            this.pnlExternalCond.TabIndex = 0;
            // 
            // lblCrsScrollDisplay
            // 
            this.lblCrsScrollDisplay.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
            this.lblCrsScrollDisplay.CrsChanNumOrAlias = "2001";
            this.lblCrsScrollDisplay.CrsChanValue = null;
            this.lblCrsScrollDisplay.Location = new System.Drawing.Point(602, 323);
            this.lblCrsScrollDisplay.Name = "lblCrsScrollDisplay";
            this.lblCrsScrollDisplay.Size = new System.Drawing.Size(72, 35);
            this.lblCrsScrollDisplay.TabIndex = 49;
            this.lblCrsScrollDisplay.Text = "CRS Label Scroll";
            this.lblCrsScrollDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // crsLabel1
            // 
            this.crsLabel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.crsLabel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.crsLabel1.CrsChanNumOrAlias = "ecTest";
            this.crsLabel1.CrsChanValue = "\"<none>\"";
            this.crsLabel1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.crsLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.crsLabel1.Location = new System.Drawing.Point(576, 373);
            this.crsLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.crsLabel1.Name = "crsLabel1";
            this.crsLabel1.Size = new System.Drawing.Size(128, 44);
            this.crsLabel1.TabIndex = 48;
            this.crsLabel1.Text = "SS";
            this.crsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.crsLabel1.TextChanged += new System.EventHandler(this.crsLabel1_TextChanged);
            // 
            // cmdLoadHome
            // 
            this.cmdLoadHome.Location = new System.Drawing.Point(587, 149);
            this.cmdLoadHome.Name = "cmdLoadHome";
            this.cmdLoadHome.Size = new System.Drawing.Size(111, 32);
            this.cmdLoadHome.TabIndex = 47;
            this.cmdLoadHome.Text = "Home Page";
            this.cmdLoadHome.UseVisualStyleBackColor = true;
            this.cmdLoadHome.Click += new System.EventHandler(this.cmdLoadHome_Click);
            // 
            // pnlPanel7
            // 
            this.pnlPanel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPanel7.BackgroundImage")));
            this.pnlPanel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlPanel7.Controls.Add(this.lblShoreSuppAft);
            this.pnlPanel7.Controls.Add(this.lblPanel7);
            this.pnlPanel7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pnlPanel7.Location = new System.Drawing.Point(725, 467);
            this.pnlPanel7.Name = "pnlPanel7";
            this.pnlPanel7.Size = new System.Drawing.Size(514, 121);
            this.pnlPanel7.TabIndex = 46;
            // 
            // lblShoreSuppAft
            // 
            this.lblShoreSuppAft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblShoreSuppAft.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShoreSuppAft.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblShoreSuppAft.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShoreSuppAft.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblShoreSuppAft.Location = new System.Drawing.Point(314, 38);
            this.lblShoreSuppAft.Name = "lblShoreSuppAft";
            this.lblShoreSuppAft.Size = new System.Drawing.Size(152, 44);
            this.lblShoreSuppAft.TabIndex = 41;
            this.lblShoreSuppAft.Text = "No";
            this.lblShoreSuppAft.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPanel7
            // 
            this.lblPanel7.BackColor = System.Drawing.Color.Transparent;
            this.lblPanel7.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblPanel7.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPanel7.ForeColor = System.Drawing.Color.White;
            this.lblPanel7.Location = new System.Drawing.Point(30, 32);
            this.lblPanel7.Name = "lblPanel7";
            this.lblPanel7.Size = new System.Drawing.Size(271, 57);
            this.lblPanel7.TabIndex = 5;
            this.lblPanel7.Text = "Shore Supplies Available Aft";
            this.lblPanel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlPanel4
            // 
            this.pnlPanel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPanel4.BackgroundImage")));
            this.pnlPanel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlPanel4.Controls.Add(this.lblCrsElecSetBlock);
            this.pnlPanel4.Controls.Add(this.lblPanel4);
            this.pnlPanel4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pnlPanel4.Location = new System.Drawing.Point(306, 626);
            this.pnlPanel4.Name = "pnlPanel4";
            this.pnlPanel4.Size = new System.Drawing.Size(514, 121);
            this.pnlPanel4.TabIndex = 43;
            this.pnlPanel4.Click += new System.EventHandler(this.pnlElecBlock_Click);
            this.pnlPanel4.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlPanel4_Paint);
            // 
            // lblCrsElecSetBlock
            // 
            this.lblCrsElecSetBlock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblCrsElecSetBlock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCrsElecSetBlock.CrsChanNumOrAlias = "t_elec_load_change";
            this.lblCrsElecSetBlock.CrsChanValue = "\"<none>\"";
            this.lblCrsElecSetBlock.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.lblCrsElecSetBlock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCrsElecSetBlock.Location = new System.Drawing.Point(330, 37);
            this.lblCrsElecSetBlock.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCrsElecSetBlock.Name = "lblCrsElecSetBlock";
            this.lblCrsElecSetBlock.Size = new System.Drawing.Size(152, 44);
            this.lblCrsElecSetBlock.TabIndex = 42;
            this.lblCrsElecSetBlock.Text = "ele_block";
            this.lblCrsElecSetBlock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPanel4
            // 
            this.lblPanel4.BackColor = System.Drawing.Color.Transparent;
            this.lblPanel4.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblPanel4.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPanel4.ForeColor = System.Drawing.Color.White;
            this.lblPanel4.Location = new System.Drawing.Point(65, 31);
            this.lblPanel4.Name = "lblPanel4";
            this.lblPanel4.Size = new System.Drawing.Size(200, 59);
            this.lblPanel4.TabIndex = 5;
            this.lblPanel4.Text = "Electrical Block Load Changes";
            this.lblPanel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPanel4.Click += new System.EventHandler(this.pnlElecBlock_Click);
            // 
            // pnlPanel6
            // 
            this.pnlPanel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPanel6.BackgroundImage")));
            this.pnlPanel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlPanel6.Controls.Add(this.lblGTIcing);
            this.pnlPanel6.Controls.Add(this.lblPanel6);
            this.pnlPanel6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pnlPanel6.Location = new System.Drawing.Point(725, 308);
            this.pnlPanel6.Name = "pnlPanel6";
            this.pnlPanel6.Size = new System.Drawing.Size(514, 121);
            this.pnlPanel6.TabIndex = 45;
            // 
            // lblGTIcing
            // 
            this.lblGTIcing.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblGTIcing.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblGTIcing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblGTIcing.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGTIcing.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblGTIcing.Location = new System.Drawing.Point(314, 38);
            this.lblGTIcing.Name = "lblGTIcing";
            this.lblGTIcing.Size = new System.Drawing.Size(152, 44);
            this.lblGTIcing.TabIndex = 41;
            this.lblGTIcing.Text = "Off";
            this.lblGTIcing.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPanel6
            // 
            this.lblPanel6.AutoSize = true;
            this.lblPanel6.BackColor = System.Drawing.Color.Transparent;
            this.lblPanel6.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblPanel6.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPanel6.ForeColor = System.Drawing.Color.White;
            this.lblPanel6.Location = new System.Drawing.Point(28, 46);
            this.lblPanel6.Name = "lblPanel6";
            this.lblPanel6.Size = new System.Drawing.Size(274, 27);
            this.lblPanel6.TabIndex = 5;
            this.lblPanel6.Text = "Gas Turbine Intake Icing";
            this.lblPanel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlPanel3
            // 
            this.pnlPanel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPanel3.BackgroundImage")));
            this.pnlPanel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlPanel3.Controls.Add(this.lblShoreSuppFwd);
            this.pnlPanel3.Controls.Add(this.lblPanel3);
            this.pnlPanel3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pnlPanel3.Location = new System.Drawing.Point(41, 467);
            this.pnlPanel3.Name = "pnlPanel3";
            this.pnlPanel3.Size = new System.Drawing.Size(514, 121);
            this.pnlPanel3.TabIndex = 43;
            // 
            // lblShoreSuppFwd
            // 
            this.lblShoreSuppFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblShoreSuppFwd.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblShoreSuppFwd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblShoreSuppFwd.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblShoreSuppFwd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblShoreSuppFwd.Location = new System.Drawing.Point(314, 38);
            this.lblShoreSuppFwd.Name = "lblShoreSuppFwd";
            this.lblShoreSuppFwd.Size = new System.Drawing.Size(152, 44);
            this.lblShoreSuppFwd.TabIndex = 41;
            this.lblShoreSuppFwd.Text = "No";
            this.lblShoreSuppFwd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPanel3
            // 
            this.lblPanel3.BackColor = System.Drawing.Color.Transparent;
            this.lblPanel3.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblPanel3.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPanel3.ForeColor = System.Drawing.Color.White;
            this.lblPanel3.Location = new System.Drawing.Point(30, 32);
            this.lblPanel3.Name = "lblPanel3";
            this.lblPanel3.Size = new System.Drawing.Size(271, 57);
            this.lblPanel3.TabIndex = 5;
            this.lblPanel3.Text = "Shore Supplies Available Forward";
            this.lblPanel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlPanel5
            // 
            this.pnlPanel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPanel5.BackgroundImage")));
            this.pnlPanel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlPanel5.Controls.Add(this.lblCrsSeaState);
            this.pnlPanel5.Controls.Add(this.lblSeaState);
            this.pnlPanel5.Controls.Add(this.lblPanel5);
            this.pnlPanel5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pnlPanel5.Location = new System.Drawing.Point(725, 149);
            this.pnlPanel5.Name = "pnlPanel5";
            this.pnlPanel5.Size = new System.Drawing.Size(514, 121);
            this.pnlPanel5.TabIndex = 44;
            // 
            // lblCrsSeaState
            // 
            this.lblCrsSeaState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblCrsSeaState.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCrsSeaState.CrsChanNumOrAlias = "ecTest";
            this.lblCrsSeaState.CrsChanValue = "\"<none>\"";
            this.lblCrsSeaState.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.lblCrsSeaState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCrsSeaState.Location = new System.Drawing.Point(338, 62);
            this.lblCrsSeaState.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCrsSeaState.Name = "lblCrsSeaState";
            this.lblCrsSeaState.Size = new System.Drawing.Size(128, 44);
            this.lblCrsSeaState.TabIndex = 44;
            this.lblCrsSeaState.Text = "SS";
            this.lblCrsSeaState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCrsSeaState.TextChanged += new System.EventHandler(this.lblCrsSeaState_TextChanged);
            // 
            // lblSeaState
            // 
            this.lblSeaState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblSeaState.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblSeaState.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblSeaState.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeaState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblSeaState.Location = new System.Drawing.Point(338, 18);
            this.lblSeaState.Name = "lblSeaState";
            this.lblSeaState.Size = new System.Drawing.Size(128, 44);
            this.lblSeaState.TabIndex = 41;
            this.lblSeaState.Text = "Calm";
            this.lblSeaState.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPanel5
            // 
            this.lblPanel5.AutoSize = true;
            this.lblPanel5.BackColor = System.Drawing.Color.Transparent;
            this.lblPanel5.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblPanel5.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPanel5.ForeColor = System.Drawing.Color.White;
            this.lblPanel5.Location = new System.Drawing.Point(107, 46);
            this.lblPanel5.Name = "lblPanel5";
            this.lblPanel5.Size = new System.Drawing.Size(117, 27);
            this.lblPanel5.TabIndex = 5;
            this.lblPanel5.Text = "Sea State";
            this.lblPanel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlPanel2
            // 
            this.pnlPanel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPanel2.BackgroundImage")));
            this.pnlPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlPanel2.Controls.Add(this.lblTowedArray);
            this.pnlPanel2.Controls.Add(this.lblPanel2);
            this.pnlPanel2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pnlPanel2.Location = new System.Drawing.Point(41, 308);
            this.pnlPanel2.Name = "pnlPanel2";
            this.pnlPanel2.Size = new System.Drawing.Size(514, 121);
            this.pnlPanel2.TabIndex = 42;
            // 
            // lblTowedArray
            // 
            this.lblTowedArray.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblTowedArray.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTowedArray.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblTowedArray.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTowedArray.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblTowedArray.Location = new System.Drawing.Point(314, 38);
            this.lblTowedArray.Name = "lblTowedArray";
            this.lblTowedArray.Size = new System.Drawing.Size(152, 44);
            this.lblTowedArray.TabIndex = 41;
            this.lblTowedArray.Text = "Unattached";
            this.lblTowedArray.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPanel2
            // 
            this.lblPanel2.AutoSize = true;
            this.lblPanel2.BackColor = System.Drawing.Color.Transparent;
            this.lblPanel2.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblPanel2.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPanel2.ForeColor = System.Drawing.Color.White;
            this.lblPanel2.Location = new System.Drawing.Point(94, 46);
            this.lblPanel2.Name = "lblPanel2";
            this.lblPanel2.Size = new System.Drawing.Size(142, 27);
            this.lblPanel2.TabIndex = 5;
            this.lblPanel2.Text = "Towed Array";
            this.lblPanel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlAirTemp
            // 
            this.pnlAirTemp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlAirTemp.BackgroundImage")));
            this.pnlAirTemp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pnlAirTemp.Controls.Add(this.lblCrsOutsideAirTemp);
            this.pnlAirTemp.Controls.Add(this.lblAirTemp);
            this.pnlAirTemp.Controls.Add(this.lblPanel1);
            this.pnlAirTemp.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.pnlAirTemp.Location = new System.Drawing.Point(41, 149);
            this.pnlAirTemp.Name = "pnlAirTemp";
            this.pnlAirTemp.Size = new System.Drawing.Size(514, 121);
            this.pnlAirTemp.TabIndex = 14;
            this.pnlAirTemp.Click += new System.EventHandler(this.pnllAirTemp_Click);
            this.pnlAirTemp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAirTemp_MouseDown);
            this.pnlAirTemp.MouseLeave += new System.EventHandler(this.pnlAirTemp_MouseLeave);
            // 
            // lblCrsOutsideAirTemp
            // 
            this.lblCrsOutsideAirTemp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblCrsOutsideAirTemp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblCrsOutsideAirTemp.CrsChanNumOrAlias = "chan1000";
            this.lblCrsOutsideAirTemp.CrsChanValue = "\"<none>\"";
            this.lblCrsOutsideAirTemp.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold);
            this.lblCrsOutsideAirTemp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblCrsOutsideAirTemp.Location = new System.Drawing.Point(338, 62);
            this.lblCrsOutsideAirTemp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCrsOutsideAirTemp.Name = "lblCrsOutsideAirTemp";
            this.lblCrsOutsideAirTemp.Size = new System.Drawing.Size(128, 44);
            this.lblCrsOutsideAirTemp.TabIndex = 43;
            this.lblCrsOutsideAirTemp.Text = "oat";
            this.lblCrsOutsideAirTemp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCrsOutsideAirTemp.TextChanged += new System.EventHandler(this.lblCrsOutsideAirTemp_TextChanged);
            // 
            // lblAirTemp
            // 
            this.lblAirTemp.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
            this.lblAirTemp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblAirTemp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAirTemp.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAirTemp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblAirTemp.Location = new System.Drawing.Point(338, 18);
            this.lblAirTemp.Name = "lblAirTemp";
            this.lblAirTemp.Size = new System.Drawing.Size(128, 44);
            this.lblAirTemp.TabIndex = 41;
            this.lblAirTemp.Text = "15.0°";
            this.lblAirTemp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAirTemp.Click += new System.EventHandler(this.pnllAirTemp_Click);
            this.lblAirTemp.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAirTemp_MouseDown);
            this.lblAirTemp.MouseLeave += new System.EventHandler(this.pnlAirTemp_MouseLeave);
            // 
            // lblPanel1
            // 
            this.lblPanel1.AutoSize = true;
            this.lblPanel1.BackColor = System.Drawing.Color.Transparent;
            this.lblPanel1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblPanel1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPanel1.ForeColor = System.Drawing.Color.White;
            this.lblPanel1.Location = new System.Drawing.Point(30, 46);
            this.lblPanel1.Name = "lblPanel1";
            this.lblPanel1.Size = new System.Drawing.Size(271, 27);
            this.lblPanel1.TabIndex = 5;
            this.lblPanel1.Text = "Outside Air Temperature";
            this.lblPanel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPanel1.Click += new System.EventHandler(this.pnllAirTemp_Click);
            this.lblPanel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlAirTemp_MouseDown);
            this.lblPanel1.MouseLeave += new System.EventHandler(this.pnlAirTemp_MouseLeave);
            // 
            // frmExternalCond
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1280, 791);
            this.ControlBox = false;
            this.Controls.Add(this.pnlExternalCond);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmExternalCond";
            this.Text = "External Conditions";
            this.pnlTop.ResumeLayout(false);
            this.pnlTopInner.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
            this.pnlExternalCond.ResumeLayout(false);
            this.pnlPanel7.ResumeLayout(false);
            this.pnlPanel4.ResumeLayout(false);
            this.pnlPanel6.ResumeLayout(false);
            this.pnlPanel6.PerformLayout();
            this.pnlPanel3.ResumeLayout(false);
            this.pnlPanel5.ResumeLayout(false);
            this.pnlPanel5.PerformLayout();
            this.pnlPanel2.ResumeLayout(false);
            this.pnlPanel2.PerformLayout();
            this.pnlAirTemp.ResumeLayout(false);
            this.pnlAirTemp.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.PictureBox PageBack;
        private System.Windows.Forms.PictureBox PageFwd;
        private System.Windows.Forms.Panel pnlExternalCond;
        private System.Windows.Forms.Panel pnlTopInner;
        private System.Windows.Forms.Label lblPageName;
        private System.Windows.Forms.Panel pnlAirTemp;
        private System.Windows.Forms.Label lblPanel1;
        private System.Windows.Forms.Label lblAirTemp;
        private System.Windows.Forms.Panel pnlPanel4;
        private System.Windows.Forms.Label lblPanel4;
        private System.Windows.Forms.Panel pnlPanel3;
        private System.Windows.Forms.Label lblShoreSuppFwd;
        private System.Windows.Forms.Label lblPanel3;
        private System.Windows.Forms.Panel pnlPanel2;
        private System.Windows.Forms.Label lblTowedArray;
        private System.Windows.Forms.Label lblPanel2;
        private System.Windows.Forms.Panel pnlPanel7;
        private System.Windows.Forms.Label lblShoreSuppAft;
        private System.Windows.Forms.Label lblPanel7;
        private System.Windows.Forms.Panel pnlPanel6;
        private System.Windows.Forms.Label lblGTIcing;
        private System.Windows.Forms.Label lblPanel6;
        private System.Windows.Forms.Panel pnlPanel5;
        private System.Windows.Forms.Label lblSeaState;
        private System.Windows.Forms.Label lblPanel5;
        private CRSControlsLib.CrsLabel lblCrsElecSetBlock;
        private CRSControlsLib.CrsLabel lblCrsOutsideAirTemp;
        private CRSControlsLib.CrsLabel lblCrsSeaState;
        private System.Windows.Forms.Button cmdLoadHome;
        private CRSControlsLib.CrsLabel crsLabel1;
        private CRSControlsLib.CrsLabel lblCrsScrollDisplay;
    }
}