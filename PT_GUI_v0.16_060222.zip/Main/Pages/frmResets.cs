﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PtGui
{
	public partial class frmResets : Form

	{
		public frmResets()
		{
			InitializeComponent();
			this.StartPosition = FormStartPosition.Manual;
			this.Location = new Point(0, 0);
		}

		private void pnlChangeFuelTank_Click(object sender, EventArgs e)
		{
			//Get the value of the Storage Channel output channel
			double tank_level = GuiCore.get_chan_val_double("o_storageTankLevel");

			//Set the value of the temporary Num Key form internal channel to the Tank Level
			GuiCore.set_channel_value("t_frmNumKeyEditVal", tank_level);

			//Set up the Num Key labels
			GuiCore.set_channel_value("t_frmNumKeyTitle", "Storage Tank Level");
			GuiCore.set_channel_value("t_frmNumKeyMax", "100%");
			GuiCore.set_channel_value("t_frmNumKeyMin", "0%");

			//Set the initial value of the Value label
			GuiCore.set_channel_value("t_frmNumKeyVal", tank_level);

			GuiCore.show_form("frmNumberKeypad");
		}

		private void pnlChangeFuelTank_MouseDown(object sender, MouseEventArgs e)
		{
			Bitmap bitmap = new Bitmap(Constants.BMP_RESET_BUTTON_CYAN_DOWN);
			pnlChangeFuelTank.BackgroundImage = bitmap;
		}

		private void pnlChangeFuelTank_MouseLeave(object sender, EventArgs e)
		{
			Bitmap bitmap = new Bitmap(Constants.BMP_RESET_BUTTON_CYAN_UP);
			pnlChangeFuelTank.BackgroundImage = bitmap;
		}

		private void pnlChangeServiceTank_Click(object sender, EventArgs e)
		{

			GuiCore.set_channel_value("t_frmNumKeyTitle", "Service Tank Level");
			GuiCore.set_channel_value("t_frmNumKeyMax", "100%");
			GuiCore.set_channel_value("t_frmNumKeyMin", "0%");
			GuiCore.set_channel_value("t_frmNumKeyVal", "");

			GuiCore.show_form("frmNumberKeypad");
		}

		private void pnlChangeServiceTank_MouseDown(object sender, MouseEventArgs e)
		{
			Bitmap bitmap = new Bitmap(Constants.BMP_RESET_BUTTON_CYAN_DOWN);
			pnlChangeServiceTank.BackgroundImage = bitmap;
		}

		private void pnlChangeServiceTank_MouseLeave(object sender, EventArgs e)
		{
			Bitmap bitmap = new Bitmap(Constants.BMP_RESET_BUTTON_CYAN_UP);
			pnlChangeServiceTank.BackgroundImage = bitmap;
		}

		private void PageFwd_Click(object sender, EventArgs e)
		{
			GuiCore.show_form("frmExternalCond", this);
		}

		private void PageBack_Click(object sender, EventArgs e)
		{
			GuiCore.show_form("frmInitialCond", this);
		}
	}
}
