﻿
namespace PtGui
{
	partial class frmGTMalfunctions2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGTMalfunctions2));
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlTopInner = new System.Windows.Forms.Panel();
			this.lblPageName2 = new System.Windows.Forms.Label();
			this.lblPageName = new System.Windows.Forms.Label();
			this.PageFwd = new System.Windows.Forms.PictureBox();
			this.PageBack = new System.Windows.Forms.PictureBox();
			this.pnlPanelTest = new System.Windows.Forms.Panel();
			this.pnlStbd = new System.Windows.Forms.Panel();
			this.pnlstbd6 = new System.Windows.Forms.Panel();
			this.lblStbd6 = new System.Windows.Forms.Label();
			this.pnlstbd4 = new System.Windows.Forms.Panel();
			this.lblStbd4 = new System.Windows.Forms.Label();
			this.pnlstbd7 = new System.Windows.Forms.Panel();
			this.lblStbd7 = new System.Windows.Forms.Label();
			this.pnlstbd5 = new System.Windows.Forms.Panel();
			this.lblStbd5 = new System.Windows.Forms.Label();
			this.pnlstbd3 = new System.Windows.Forms.Panel();
			this.lblStbd3 = new System.Windows.Forms.Label();
			this.pnlstbd2 = new System.Windows.Forms.Panel();
			this.lblStbd2 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.pnlstbd1 = new System.Windows.Forms.Panel();
			this.lblStbd1 = new System.Windows.Forms.Label();
			this.pnlPort = new System.Windows.Forms.Panel();
			this.pnlport6 = new System.Windows.Forms.Panel();
			this.lblPort6 = new System.Windows.Forms.Label();
			this.pnlport4 = new System.Windows.Forms.Panel();
			this.lblPort4 = new System.Windows.Forms.Label();
			this.pnlport7 = new System.Windows.Forms.Panel();
			this.lblPort7 = new System.Windows.Forms.Label();
			this.pnlport5 = new System.Windows.Forms.Panel();
			this.lblPort5 = new System.Windows.Forms.Label();
			this.pnlport3 = new System.Windows.Forms.Panel();
			this.lblPort3 = new System.Windows.Forms.Label();
			this.pnlport2 = new System.Windows.Forms.Panel();
			this.lblPort2 = new System.Windows.Forms.Label();
			this.lblPort = new System.Windows.Forms.Label();
			this.pnlport1 = new System.Windows.Forms.Panel();
			this.lblPort1 = new System.Windows.Forms.Label();
			this.pnlTop.SuspendLayout();
			this.pnlTopInner.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
			this.pnlPanelTest.SuspendLayout();
			this.pnlStbd.SuspendLayout();
			this.pnlstbd6.SuspendLayout();
			this.pnlstbd4.SuspendLayout();
			this.pnlstbd7.SuspendLayout();
			this.pnlstbd5.SuspendLayout();
			this.pnlstbd3.SuspendLayout();
			this.pnlstbd2.SuspendLayout();
			this.pnlstbd1.SuspendLayout();
			this.pnlPort.SuspendLayout();
			this.pnlport6.SuspendLayout();
			this.pnlport4.SuspendLayout();
			this.pnlport7.SuspendLayout();
			this.pnlport5.SuspendLayout();
			this.pnlport3.SuspendLayout();
			this.pnlport2.SuspendLayout();
			this.pnlport1.SuspendLayout();
			this.SuspendLayout();
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.White;
			this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlTop.Controls.Add(this.pnlTopInner);
			this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.pnlTop.Location = new System.Drawing.Point(25, 5);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1229, 96);
			this.pnlTop.TabIndex = 1;
			// 
			// pnlTopInner
			// 
			this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
			this.pnlTopInner.Controls.Add(this.lblPageName2);
			this.pnlTopInner.Controls.Add(this.lblPageName);
			this.pnlTopInner.Controls.Add(this.PageFwd);
			this.pnlTopInner.Controls.Add(this.PageBack);
			this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
			this.pnlTopInner.Name = "pnlTopInner";
			this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
			this.pnlTopInner.TabIndex = 0;
			// 
			// lblPageName2
			// 
			this.lblPageName2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName2.ForeColor = System.Drawing.Color.White;
			this.lblPageName2.Location = new System.Drawing.Point(175, 42);
			this.lblPageName2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName2.Name = "lblPageName2";
			this.lblPageName2.Size = new System.Drawing.Size(868, 49);
			this.lblPageName2.TabIndex = 3;
			this.lblPageName2.Text = "Page 2 of 2";
			this.lblPageName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPageName
			// 
			this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName.ForeColor = System.Drawing.Color.White;
			this.lblPageName.Location = new System.Drawing.Point(175, 4);
			this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName.Name = "lblPageName";
			this.lblPageName.Size = new System.Drawing.Size(868, 49);
			this.lblPageName.TabIndex = 2;
			this.lblPageName.Text = "Gas Turbine Malfunctions";
			this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PageFwd
			// 
			this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
			this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageFwd.Location = new System.Drawing.Point(1103, 0);
			this.PageFwd.Name = "PageFwd";
			this.PageFwd.Size = new System.Drawing.Size(116, 87);
			this.PageFwd.TabIndex = 0;
			this.PageFwd.TabStop = false;
			this.PageFwd.Click += new System.EventHandler(this.PageFwd_Click);
			// 
			// PageBack
			// 
			this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
			this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageBack.Location = new System.Drawing.Point(0, 0);
			this.PageBack.Name = "PageBack";
			this.PageBack.Size = new System.Drawing.Size(116, 87);
			this.PageBack.TabIndex = 1;
			this.PageBack.TabStop = false;
			this.PageBack.Click += new System.EventHandler(this.PageBack_Click);
			// 
			// pnlPanelTest
			// 
			this.pnlPanelTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.pnlPanelTest.Controls.Add(this.pnlStbd);
			this.pnlPanelTest.Controls.Add(this.pnlPort);
			this.pnlPanelTest.Controls.Add(this.pnlTop);
			this.pnlPanelTest.Cursor = System.Windows.Forms.Cursors.Default;
			this.pnlPanelTest.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.pnlPanelTest.Location = new System.Drawing.Point(0, 0);
			this.pnlPanelTest.Name = "pnlPanelTest";
			this.pnlPanelTest.Size = new System.Drawing.Size(1280, 791);
			this.pnlPanelTest.TabIndex = 0;
			// 
			// pnlStbd
			// 
			this.pnlStbd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlStbd.BackgroundImage")));
			this.pnlStbd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlStbd.Controls.Add(this.pnlstbd6);
			this.pnlStbd.Controls.Add(this.pnlstbd4);
			this.pnlStbd.Controls.Add(this.pnlstbd7);
			this.pnlStbd.Controls.Add(this.pnlstbd5);
			this.pnlStbd.Controls.Add(this.pnlstbd3);
			this.pnlStbd.Controls.Add(this.pnlstbd2);
			this.pnlStbd.Controls.Add(this.label16);
			this.pnlStbd.Controls.Add(this.pnlstbd1);
			this.pnlStbd.Location = new System.Drawing.Point(689, 122);
			this.pnlStbd.Name = "pnlStbd";
			this.pnlStbd.Size = new System.Drawing.Size(560, 657);
			this.pnlStbd.TabIndex = 28;
			// 
			// pnlstbd6
			// 
			this.pnlstbd6.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd6.BackgroundImage")));
			this.pnlstbd6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd6.Controls.Add(this.lblStbd6);
			this.pnlstbd6.Location = new System.Drawing.Point(281, 366);
			this.pnlstbd6.Name = "pnlstbd6";
			this.pnlstbd6.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd6.TabIndex = 27;
			// 
			// lblStbd6
			// 
			this.lblStbd6.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd6.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd6.Location = new System.Drawing.Point(20, 30);
			this.lblStbd6.Name = "lblStbd6";
			this.lblStbd6.Size = new System.Drawing.Size(210, 72);
			this.lblStbd6.TabIndex = 0;
			this.lblStbd6.Text = "STARBOARD PT REAR JOURNAL BEARING TEMPERATURE HIGH";
			this.lblStbd6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlstbd4
			// 
			this.pnlstbd4.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd4.BackgroundImage")));
			this.pnlstbd4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd4.Controls.Add(this.lblStbd4);
			this.pnlstbd4.Location = new System.Drawing.Point(281, 226);
			this.pnlstbd4.Name = "pnlstbd4";
			this.pnlstbd4.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd4.TabIndex = 26;
			// 
			// lblStbd4
			// 
			this.lblStbd4.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd4.Location = new System.Drawing.Point(37, 30);
			this.lblStbd4.Name = "lblStbd4";
			this.lblStbd4.Size = new System.Drawing.Size(176, 72);
			this.lblStbd4.TabIndex = 0;
			this.lblStbd4.Text = "AIR INTAKE DEPRESSION HIGH STARBOARD";
			this.lblStbd4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlstbd7
			// 
			this.pnlstbd7.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd7.BackgroundImage")));
			this.pnlstbd7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd7.Controls.Add(this.lblStbd7);
			this.pnlstbd7.Location = new System.Drawing.Point(23, 506);
			this.pnlstbd7.Name = "pnlstbd7";
			this.pnlstbd7.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd7.TabIndex = 25;
			// 
			// lblStbd7
			// 
			this.lblStbd7.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd7.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd7.Location = new System.Drawing.Point(28, 26);
			this.lblStbd7.Name = "lblStbd7";
			this.lblStbd7.Size = new System.Drawing.Size(198, 72);
			this.lblStbd7.TabIndex = 0;
			this.lblStbd7.Text = "STARBOARD PT VIBRATION HIGH";
			this.lblStbd7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlstbd5
			// 
			this.pnlstbd5.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd5.BackgroundImage")));
			this.pnlstbd5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd5.Controls.Add(this.lblStbd5);
			this.pnlstbd5.Location = new System.Drawing.Point(23, 366);
			this.pnlstbd5.Name = "pnlstbd5";
			this.pnlstbd5.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd5.TabIndex = 25;
			// 
			// lblStbd5
			// 
			this.lblStbd5.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd5.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd5.Location = new System.Drawing.Point(39, 30);
			this.lblStbd5.Name = "lblStbd5";
			this.lblStbd5.Size = new System.Drawing.Size(176, 72);
			this.lblStbd5.TabIndex = 0;
			this.lblStbd5.Text = "STARBOARD GGLO TEMPERATURE HIGH";
			this.lblStbd5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlstbd3
			// 
			this.pnlstbd3.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd3.BackgroundImage")));
			this.pnlstbd3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd3.Controls.Add(this.lblStbd3);
			this.pnlstbd3.Location = new System.Drawing.Point(23, 226);
			this.pnlstbd3.Name = "pnlstbd3";
			this.pnlstbd3.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd3.TabIndex = 25;
			// 
			// lblStbd3
			// 
			this.lblStbd3.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd3.Location = new System.Drawing.Point(21, 30);
			this.lblStbd3.Name = "lblStbd3";
			this.lblStbd3.Size = new System.Drawing.Size(212, 72);
			this.lblStbd3.TabIndex = 0;
			this.lblStbd3.Text = "FSC GOES TO MAXIMUM STARBOARD";
			this.lblStbd3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlstbd2
			// 
			this.pnlstbd2.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd2.BackgroundImage")));
			this.pnlstbd2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd2.Controls.Add(this.lblStbd2);
			this.pnlstbd2.Location = new System.Drawing.Point(281, 86);
			this.pnlstbd2.Name = "pnlstbd2";
			this.pnlstbd2.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd2.TabIndex = 25;
			// 
			// lblStbd2
			// 
			this.lblStbd2.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd2.Location = new System.Drawing.Point(21, 30);
			this.lblStbd2.Name = "lblStbd2";
			this.lblStbd2.Size = new System.Drawing.Size(209, 72);
			this.lblStbd2.TabIndex = 0;
			this.lblStbd2.Text = "GGLO DELAY/SCAVENGE DIFF PRESSURE LOW STARBOARD";
			this.lblStbd2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.BackColor = System.Drawing.Color.Transparent;
			this.label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label16.ForeColor = System.Drawing.Color.White;
			this.label16.Location = new System.Drawing.Point(248, 20);
			this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(70, 31);
			this.label16.TabIndex = 4;
			this.label16.Text = "Stbd";
			this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlstbd1
			// 
			this.pnlstbd1.BackColor = System.Drawing.Color.Silver;
			this.pnlstbd1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlstbd1.BackgroundImage")));
			this.pnlstbd1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlstbd1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlstbd1.Controls.Add(this.lblStbd1);
			this.pnlstbd1.Location = new System.Drawing.Point(23, 86);
			this.pnlstbd1.Name = "pnlstbd1";
			this.pnlstbd1.Size = new System.Drawing.Size(252, 131);
			this.pnlstbd1.TabIndex = 24;
			// 
			// lblStbd1
			// 
			this.lblStbd1.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd1.Location = new System.Drawing.Point(39, 30);
			this.lblStbd1.Name = "lblStbd1";
			this.lblStbd1.Size = new System.Drawing.Size(176, 72);
			this.lblStbd1.TabIndex = 0;
			this.lblStbd1.Text = "PT LO PRESSURE LOW (TRANSDUCER) STARBOARD";
			this.lblStbd1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPort
			// 
			this.pnlPort.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPort.BackgroundImage")));
			this.pnlPort.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlPort.Controls.Add(this.pnlport6);
			this.pnlPort.Controls.Add(this.pnlport4);
			this.pnlPort.Controls.Add(this.pnlport7);
			this.pnlPort.Controls.Add(this.pnlport5);
			this.pnlPort.Controls.Add(this.pnlport3);
			this.pnlPort.Controls.Add(this.pnlport2);
			this.pnlPort.Controls.Add(this.lblPort);
			this.pnlPort.Controls.Add(this.pnlport1);
			this.pnlPort.Location = new System.Drawing.Point(31, 122);
			this.pnlPort.Name = "pnlPort";
			this.pnlPort.Size = new System.Drawing.Size(560, 657);
			this.pnlPort.TabIndex = 25;
			// 
			// pnlport6
			// 
			this.pnlport6.BackColor = System.Drawing.Color.Silver;
			this.pnlport6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport6.BackgroundImage")));
			this.pnlport6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport6.Controls.Add(this.lblPort6);
			this.pnlport6.Location = new System.Drawing.Point(281, 366);
			this.pnlport6.Name = "pnlport6";
			this.pnlport6.Size = new System.Drawing.Size(252, 131);
			this.pnlport6.TabIndex = 27;
			// 
			// lblPort6
			// 
			this.lblPort6.BackColor = System.Drawing.Color.Transparent;
			this.lblPort6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort6.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort6.Location = new System.Drawing.Point(37, 30);
			this.lblPort6.Name = "lblPort6";
			this.lblPort6.Size = new System.Drawing.Size(176, 72);
			this.lblPort6.TabIndex = 0;
			this.lblPort6.Text = "PORT PT MAIN THRUST BEARING TEMPERATURE HIGH";
			this.lblPort6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlport4
			// 
			this.pnlport4.BackColor = System.Drawing.Color.Silver;
			this.pnlport4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport4.BackgroundImage")));
			this.pnlport4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport4.Controls.Add(this.lblPort4);
			this.pnlport4.Location = new System.Drawing.Point(281, 226);
			this.pnlport4.Name = "pnlport4";
			this.pnlport4.Size = new System.Drawing.Size(252, 131);
			this.pnlport4.TabIndex = 26;
			// 
			// lblPort4
			// 
			this.lblPort4.BackColor = System.Drawing.Color.Transparent;
			this.lblPort4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort4.Location = new System.Drawing.Point(37, 30);
			this.lblPort4.Name = "lblPort4";
			this.lblPort4.Size = new System.Drawing.Size(176, 72);
			this.lblPort4.TabIndex = 0;
			this.lblPort4.Text = "AIR INTAKE DEPRESSION HIGH PORT";
			this.lblPort4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlport7
			// 
			this.pnlport7.BackColor = System.Drawing.Color.Silver;
			this.pnlport7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport7.BackgroundImage")));
			this.pnlport7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport7.Controls.Add(this.lblPort7);
			this.pnlport7.Location = new System.Drawing.Point(23, 506);
			this.pnlport7.Name = "pnlport7";
			this.pnlport7.Size = new System.Drawing.Size(252, 131);
			this.pnlport7.TabIndex = 25;
			// 
			// lblPort7
			// 
			this.lblPort7.BackColor = System.Drawing.Color.Transparent;
			this.lblPort7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort7.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort7.Location = new System.Drawing.Point(28, 26);
			this.lblPort7.Name = "lblPort7";
			this.lblPort7.Size = new System.Drawing.Size(198, 72);
			this.lblPort7.TabIndex = 0;
			this.lblPort7.Text = "PORT GAS GENERATOR FRONT VIBRATION HIGH";
			this.lblPort7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlport5
			// 
			this.pnlport5.BackColor = System.Drawing.Color.Silver;
			this.pnlport5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport5.BackgroundImage")));
			this.pnlport5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport5.Controls.Add(this.lblPort5);
			this.pnlport5.Location = new System.Drawing.Point(23, 366);
			this.pnlport5.Name = "pnlport5";
			this.pnlport5.Size = new System.Drawing.Size(252, 131);
			this.pnlport5.TabIndex = 25;
			// 
			// lblPort5
			// 
			this.lblPort5.BackColor = System.Drawing.Color.Transparent;
			this.lblPort5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort5.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort5.Location = new System.Drawing.Point(39, 30);
			this.lblPort5.Name = "lblPort5";
			this.lblPort5.Size = new System.Drawing.Size(176, 72);
			this.lblPort5.TabIndex = 0;
			this.lblPort5.Text = "PORT GGLO TANK LEVEL LOW";
			this.lblPort5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlport3
			// 
			this.pnlport3.BackColor = System.Drawing.Color.Silver;
			this.pnlport3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport3.BackgroundImage")));
			this.pnlport3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport3.Controls.Add(this.lblPort3);
			this.pnlport3.Location = new System.Drawing.Point(23, 226);
			this.pnlport3.Name = "pnlport3";
			this.pnlport3.Size = new System.Drawing.Size(252, 131);
			this.pnlport3.TabIndex = 25;
			// 
			// lblPort3
			// 
			this.lblPort3.BackColor = System.Drawing.Color.Transparent;
			this.lblPort3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort3.Location = new System.Drawing.Point(23, 30);
			this.lblPort3.Name = "lblPort3";
			this.lblPort3.Size = new System.Drawing.Size(208, 72);
			this.lblPort3.TabIndex = 0;
			this.lblPort3.Text = "FSC GOES TO MAXIMUM PORT";
			this.lblPort3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlport2
			// 
			this.pnlport2.BackColor = System.Drawing.Color.Silver;
			this.pnlport2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport2.BackgroundImage")));
			this.pnlport2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport2.Controls.Add(this.lblPort2);
			this.pnlport2.Location = new System.Drawing.Point(281, 86);
			this.pnlport2.Name = "pnlport2";
			this.pnlport2.Size = new System.Drawing.Size(252, 131);
			this.pnlport2.TabIndex = 25;
			// 
			// lblPort2
			// 
			this.lblPort2.BackColor = System.Drawing.Color.Transparent;
			this.lblPort2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort2.Location = new System.Drawing.Point(21, 30);
			this.lblPort2.Name = "lblPort2";
			this.lblPort2.Size = new System.Drawing.Size(209, 72);
			this.lblPort2.TabIndex = 0;
			this.lblPort2.Text = "GGLO DELAY/SCAVENGE DIFF PRESSURE LOW PORT";
			this.lblPort2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPort
			// 
			this.lblPort.AutoSize = true;
			this.lblPort.BackColor = System.Drawing.Color.Transparent;
			this.lblPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort.ForeColor = System.Drawing.Color.White;
			this.lblPort.Location = new System.Drawing.Point(248, 20);
			this.lblPort.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPort.Name = "lblPort";
			this.lblPort.Size = new System.Drawing.Size(64, 31);
			this.lblPort.TabIndex = 4;
			this.lblPort.Text = "Port";
			this.lblPort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlport1
			// 
			this.pnlport1.BackColor = System.Drawing.Color.Silver;
			this.pnlport1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlport1.BackgroundImage")));
			this.pnlport1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlport1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlport1.Controls.Add(this.lblPort1);
			this.pnlport1.Location = new System.Drawing.Point(23, 86);
			this.pnlport1.Name = "pnlport1";
			this.pnlport1.Size = new System.Drawing.Size(252, 131);
			this.pnlport1.TabIndex = 24;
			// 
			// lblPort1
			// 
			this.lblPort1.BackColor = System.Drawing.Color.Transparent;
			this.lblPort1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort1.Location = new System.Drawing.Point(39, 30);
			this.lblPort1.Name = "lblPort1";
			this.lblPort1.Size = new System.Drawing.Size(176, 72);
			this.lblPort1.TabIndex = 0;
			this.lblPort1.Text = "PT LO PRESSURE LOW (TRANSDUCER) PORT";
			this.lblPort1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frmGTMalfunctions2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1280, 791);
			this.ControlBox = false;
			this.Controls.Add(this.pnlPanelTest);
			this.Cursor = System.Windows.Forms.Cursors.Cross;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmGTMalfunctions2";
			this.Text = "GT Malfunctions 2";
			this.pnlTop.ResumeLayout(false);
			this.pnlTopInner.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
			this.pnlPanelTest.ResumeLayout(false);
			this.pnlStbd.ResumeLayout(false);
			this.pnlStbd.PerformLayout();
			this.pnlstbd6.ResumeLayout(false);
			this.pnlstbd4.ResumeLayout(false);
			this.pnlstbd7.ResumeLayout(false);
			this.pnlstbd5.ResumeLayout(false);
			this.pnlstbd3.ResumeLayout(false);
			this.pnlstbd2.ResumeLayout(false);
			this.pnlstbd1.ResumeLayout(false);
			this.pnlPort.ResumeLayout(false);
			this.pnlPort.PerformLayout();
			this.pnlport6.ResumeLayout(false);
			this.pnlport4.ResumeLayout(false);
			this.pnlport7.ResumeLayout(false);
			this.pnlport5.ResumeLayout(false);
			this.pnlport3.ResumeLayout(false);
			this.pnlport2.ResumeLayout(false);
			this.pnlport1.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.PictureBox PageFwd;
		private System.Windows.Forms.PictureBox PageBack;
		private System.Windows.Forms.Panel pnlPanelTest;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.Panel pnlport1;
		private System.Windows.Forms.Label lblPort1;
		private System.Windows.Forms.Label lblPageName2;
		private System.Windows.Forms.Panel pnlPort;
		private System.Windows.Forms.Panel pnlport7;
		private System.Windows.Forms.Label lblPort7;
		private System.Windows.Forms.Panel pnlport5;
		private System.Windows.Forms.Label lblPort5;
		private System.Windows.Forms.Panel pnlport3;
		private System.Windows.Forms.Label lblPort3;
		private System.Windows.Forms.Panel pnlport2;
		private System.Windows.Forms.Label lblPort2;
		private System.Windows.Forms.Label lblPort;
		private System.Windows.Forms.Panel pnlStbd;
		private System.Windows.Forms.Panel pnlstbd6;
		private System.Windows.Forms.Label lblStbd6;
		private System.Windows.Forms.Panel pnlstbd4;
		private System.Windows.Forms.Label lblStbd4;
		private System.Windows.Forms.Panel pnlstbd7;
		private System.Windows.Forms.Label lblStbd7;
		private System.Windows.Forms.Panel pnlstbd5;
		private System.Windows.Forms.Label lblStbd5;
		private System.Windows.Forms.Panel pnlstbd3;
		private System.Windows.Forms.Label lblStbd3;
		private System.Windows.Forms.Panel pnlstbd2;
		private System.Windows.Forms.Label lblStbd2;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Panel pnlstbd1;
		private System.Windows.Forms.Label lblStbd1;
		private System.Windows.Forms.Panel pnlport6;
		private System.Windows.Forms.Label lblPort6;
		private System.Windows.Forms.Panel pnlport4;
		private System.Windows.Forms.Label lblPort4;
	}
}