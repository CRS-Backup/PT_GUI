﻿
namespace PtGui
{
	partial class frm3wayPopUp
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frm3wayPopUp));
			this.lblLABEL1 = new System.Windows.Forms.Label();
			this.pnlVLV1 = new System.Windows.Forms.Panel();
			this.lbl1 = new System.Windows.Forms.Label();
			this.pnlVLV2 = new System.Windows.Forms.Panel();
			this.lbl2 = new System.Windows.Forms.Label();
			this.pnlCANCEL = new System.Windows.Forms.Panel();
			this.lblCANCEL = new System.Windows.Forms.Label();
			this.pnlVLV3 = new System.Windows.Forms.Panel();
			this.lbl3 = new System.Windows.Forms.Label();
			this.pnlVLV1.SuspendLayout();
			this.pnlVLV2.SuspendLayout();
			this.pnlCANCEL.SuspendLayout();
			this.pnlVLV3.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblLABEL1
			// 
			this.lblLABEL1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblLABEL1.ForeColor = System.Drawing.Color.White;
			this.lblLABEL1.Location = new System.Drawing.Point(37, 83);
			this.lblLABEL1.Name = "lblLABEL1";
			this.lblLABEL1.Size = new System.Drawing.Size(123, 57);
			this.lblLABEL1.TabIndex = 0;
			this.lblLABEL1.Text = "No2 Boost Pp Discharge";
			this.lblLABEL1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlVLV1
			// 
			this.pnlVLV1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV1.BackgroundImage")));
			this.pnlVLV1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV1.Controls.Add(this.lbl1);
			this.pnlVLV1.Location = new System.Drawing.Point(256, 19);
			this.pnlVLV1.Name = "pnlVLV1";
			this.pnlVLV1.Size = new System.Drawing.Size(136, 185);
			this.pnlVLV1.TabIndex = 1;
			// 
			// lbl1
			// 
			this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl1.ForeColor = System.Drawing.Color.White;
			this.lbl1.Location = new System.Drawing.Point(13, 74);
			this.lbl1.Name = "lbl1";
			this.lbl1.Size = new System.Drawing.Size(25, 37);
			this.lbl1.TabIndex = 3;
			this.lbl1.Text = "1";
			this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlVLV2
			// 
			this.pnlVLV2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV2.BackgroundImage")));
			this.pnlVLV2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV2.Controls.Add(this.lbl2);
			this.pnlVLV2.Location = new System.Drawing.Point(512, 19);
			this.pnlVLV2.Name = "pnlVLV2";
			this.pnlVLV2.Size = new System.Drawing.Size(136, 185);
			this.pnlVLV2.TabIndex = 2;
			// 
			// lbl2
			// 
			this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl2.ForeColor = System.Drawing.Color.White;
			this.lbl2.Location = new System.Drawing.Point(12, 74);
			this.lbl2.Name = "lbl2";
			this.lbl2.Size = new System.Drawing.Size(25, 37);
			this.lbl2.TabIndex = 4;
			this.lbl2.Text = "2";
			this.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlCANCEL
			// 
			this.pnlCANCEL.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlCANCEL.BackgroundImage")));
			this.pnlCANCEL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlCANCEL.Controls.Add(this.lblCANCEL);
			this.pnlCANCEL.Location = new System.Drawing.Point(1058, 19);
			this.pnlCANCEL.Name = "pnlCANCEL";
			this.pnlCANCEL.Size = new System.Drawing.Size(102, 185);
			this.pnlCANCEL.TabIndex = 3;
			this.pnlCANCEL.Click += new System.EventHandler(this.pnlCANCEL_Click);
			// 
			// lblCANCEL
			// 
			this.lblCANCEL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(147)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.lblCANCEL.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblCANCEL.ForeColor = System.Drawing.Color.White;
			this.lblCANCEL.Location = new System.Drawing.Point(12, 74);
			this.lblCANCEL.Name = "lblCANCEL";
			this.lblCANCEL.Size = new System.Drawing.Size(78, 37);
			this.lblCANCEL.TabIndex = 4;
			this.lblCANCEL.Text = "Cancel";
			this.lblCANCEL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.lblCANCEL.Click += new System.EventHandler(this.lblCANCEL_Click);
			// 
			// pnlVLV3
			// 
			this.pnlVLV3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVLV3.BackgroundImage")));
			this.pnlVLV3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlVLV3.Controls.Add(this.lbl3);
			this.pnlVLV3.Location = new System.Drawing.Point(768, 19);
			this.pnlVLV3.Name = "pnlVLV3";
			this.pnlVLV3.Size = new System.Drawing.Size(136, 185);
			this.pnlVLV3.TabIndex = 5;
			// 
			// lbl3
			// 
			this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbl3.ForeColor = System.Drawing.Color.White;
			this.lbl3.Location = new System.Drawing.Point(12, 74);
			this.lbl3.Name = "lbl3";
			this.lbl3.Size = new System.Drawing.Size(25, 37);
			this.lbl3.TabIndex = 4;
			this.lbl3.Text = "3";
			this.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// frm3wayPopUp
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.ClientSize = new System.Drawing.Size(1280, 229);
			this.Controls.Add(this.pnlVLV3);
			this.Controls.Add(this.pnlCANCEL);
			this.Controls.Add(this.pnlVLV2);
			this.Controls.Add(this.pnlVLV1);
			this.Controls.Add(this.lblLABEL1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frm3wayPopUp";
			this.Text = "3 way PopUp";
			this.pnlVLV1.ResumeLayout(false);
			this.pnlVLV2.ResumeLayout(false);
			this.pnlCANCEL.ResumeLayout(false);
			this.pnlVLV3.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Label lblLABEL1;
		private System.Windows.Forms.Panel pnlVLV1;
		private System.Windows.Forms.Panel pnlVLV2;
		private System.Windows.Forms.Label lbl1;
		private System.Windows.Forms.Label lbl2;
		private System.Windows.Forms.Panel pnlCANCEL;
		private System.Windows.Forms.Label lblCANCEL;
		private System.Windows.Forms.Panel pnlVLV3;
		private System.Windows.Forms.Label lbl3;
	}
}