﻿
namespace PtGui
{
	partial class frmMaintMalfunctions1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMaintMalfunctions1));
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlTopInner = new System.Windows.Forms.Panel();
			this.lblPageName2 = new System.Windows.Forms.Label();
			this.lblPageName = new System.Windows.Forms.Label();
			this.PageFwd = new System.Windows.Forms.PictureBox();
			this.PageBack = new System.Windows.Forms.PictureBox();
			this.pnlPanelTest = new System.Windows.Forms.Panel();
			this.panel8 = new System.Windows.Forms.Panel();
			this.panel6 = new System.Windows.Forms.Panel();
			this.label6 = new System.Windows.Forms.Label();
			this.panel7 = new System.Windows.Forms.Panel();
			this.label7 = new System.Windows.Forms.Label();
			this.panel5 = new System.Windows.Forms.Panel();
			this.label5 = new System.Windows.Forms.Label();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.label3 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.pnlStbd = new System.Windows.Forms.Panel();
			this.pnlStbd4 = new System.Windows.Forms.Panel();
			this.lblStbd4 = new System.Windows.Forms.Label();
			this.pnlStbd3 = new System.Windows.Forms.Panel();
			this.lblStbd3 = new System.Windows.Forms.Label();
			this.pnlStbd2 = new System.Windows.Forms.Panel();
			this.lblStbd2 = new System.Windows.Forms.Label();
			this.lblStbd = new System.Windows.Forms.Label();
			this.pnlStbd1 = new System.Windows.Forms.Panel();
			this.lblStbd1 = new System.Windows.Forms.Label();
			this.pnlPort = new System.Windows.Forms.Panel();
			this.pnlPort4 = new System.Windows.Forms.Panel();
			this.lblPort4 = new System.Windows.Forms.Label();
			this.pnlPort3 = new System.Windows.Forms.Panel();
			this.lblPort3 = new System.Windows.Forms.Label();
			this.pnlPort2 = new System.Windows.Forms.Panel();
			this.lblPort2 = new System.Windows.Forms.Label();
			this.lblPort = new System.Windows.Forms.Label();
			this.pnlPort1 = new System.Windows.Forms.Panel();
			this.lblPort1 = new System.Windows.Forms.Label();
			this.pBoxLine = new System.Windows.Forms.PictureBox();
			this.pnlTop.SuspendLayout();
			this.pnlTopInner.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
			this.pnlPanelTest.SuspendLayout();
			this.panel8.SuspendLayout();
			this.panel6.SuspendLayout();
			this.panel7.SuspendLayout();
			this.panel5.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel2.SuspendLayout();
			this.pnlStbd.SuspendLayout();
			this.pnlStbd4.SuspendLayout();
			this.pnlStbd3.SuspendLayout();
			this.pnlStbd2.SuspendLayout();
			this.pnlStbd1.SuspendLayout();
			this.pnlPort.SuspendLayout();
			this.pnlPort4.SuspendLayout();
			this.pnlPort3.SuspendLayout();
			this.pnlPort2.SuspendLayout();
			this.pnlPort1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pBoxLine)).BeginInit();
			this.SuspendLayout();
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.White;
			this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlTop.Controls.Add(this.pnlTopInner);
			this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.pnlTop.Location = new System.Drawing.Point(25, 5);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1229, 96);
			this.pnlTop.TabIndex = 1;
			// 
			// pnlTopInner
			// 
			this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
			this.pnlTopInner.Controls.Add(this.lblPageName2);
			this.pnlTopInner.Controls.Add(this.lblPageName);
			this.pnlTopInner.Controls.Add(this.PageFwd);
			this.pnlTopInner.Controls.Add(this.PageBack);
			this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
			this.pnlTopInner.Name = "pnlTopInner";
			this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
			this.pnlTopInner.TabIndex = 0;
			// 
			// lblPageName2
			// 
			this.lblPageName2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName2.ForeColor = System.Drawing.Color.White;
			this.lblPageName2.Location = new System.Drawing.Point(175, 42);
			this.lblPageName2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName2.Name = "lblPageName2";
			this.lblPageName2.Size = new System.Drawing.Size(868, 49);
			this.lblPageName2.TabIndex = 3;
			this.lblPageName2.Text = "Page 1 of 2";
			this.lblPageName2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPageName
			// 
			this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName.ForeColor = System.Drawing.Color.White;
			this.lblPageName.Location = new System.Drawing.Point(175, 4);
			this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName.Name = "lblPageName";
			this.lblPageName.Size = new System.Drawing.Size(868, 49);
			this.lblPageName.TabIndex = 2;
			this.lblPageName.Text = "Maintenance Malfunctions";
			this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PageFwd
			// 
			this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
			this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageFwd.Location = new System.Drawing.Point(1103, 0);
			this.PageFwd.Name = "PageFwd";
			this.PageFwd.Size = new System.Drawing.Size(116, 87);
			this.PageFwd.TabIndex = 0;
			this.PageFwd.TabStop = false;
			this.PageFwd.Click += new System.EventHandler(this.PageFwd_Click);
			// 
			// PageBack
			// 
			this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
			this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageBack.Location = new System.Drawing.Point(0, 0);
			this.PageBack.Name = "PageBack";
			this.PageBack.Size = new System.Drawing.Size(116, 87);
			this.PageBack.TabIndex = 1;
			this.PageBack.TabStop = false;
			this.PageBack.Click += new System.EventHandler(this.PageBack_Click);
			// 
			// pnlPanelTest
			// 
			this.pnlPanelTest.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.pnlPanelTest.Controls.Add(this.panel8);
			this.pnlPanelTest.Controls.Add(this.panel5);
			this.pnlPanelTest.Controls.Add(this.panel1);
			this.pnlPanelTest.Controls.Add(this.pnlStbd);
			this.pnlPanelTest.Controls.Add(this.pnlPort);
			this.pnlPanelTest.Controls.Add(this.pnlTop);
			this.pnlPanelTest.Cursor = System.Windows.Forms.Cursors.Default;
			this.pnlPanelTest.ImeMode = System.Windows.Forms.ImeMode.NoControl;
			this.pnlPanelTest.Location = new System.Drawing.Point(0, 0);
			this.pnlPanelTest.Name = "pnlPanelTest";
			this.pnlPanelTest.Size = new System.Drawing.Size(1280, 791);
			this.pnlPanelTest.TabIndex = 0;
			// 
			// panel8
			// 
			this.panel8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel8.BackgroundImage")));
			this.panel8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel8.Controls.Add(this.panel6);
			this.panel8.Controls.Add(this.panel7);
			this.panel8.Location = new System.Drawing.Point(21, 604);
			this.panel8.Name = "panel8";
			this.panel8.Size = new System.Drawing.Size(481, 175);
			this.panel8.TabIndex = 29;
			// 
			// panel6
			// 
			this.panel6.BackColor = System.Drawing.Color.Silver;
			this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
			this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel6.Controls.Add(this.label6);
			this.panel6.Location = new System.Drawing.Point(23, 18);
			this.panel6.Name = "panel6";
			this.panel6.Size = new System.Drawing.Size(210, 131);
			this.panel6.TabIndex = 27;
			// 
			// label6
			// 
			this.label6.BackColor = System.Drawing.Color.Transparent;
			this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label6.Location = new System.Drawing.Point(31, 30);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(150, 72);
			this.label6.TabIndex = 0;
			this.label6.Text = "FAMR DCU FAILURE";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel7
			// 
			this.panel7.BackColor = System.Drawing.Color.Silver;
			this.panel7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel7.BackgroundImage")));
			this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel7.Controls.Add(this.label7);
			this.panel7.Location = new System.Drawing.Point(246, 18);
			this.panel7.Name = "panel7";
			this.panel7.Size = new System.Drawing.Size(210, 131);
			this.panel7.TabIndex = 28;
			// 
			// label7
			// 
			this.label7.BackColor = System.Drawing.Color.Transparent;
			this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label7.Location = new System.Drawing.Point(31, 30);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(150, 72);
			this.label7.TabIndex = 0;
			this.label7.Text = "SCC CDCU FAILURE";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.Silver;
			this.panel5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel5.BackgroundImage")));
			this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel5.Controls.Add(this.label5);
			this.panel5.Location = new System.Drawing.Point(534, 624);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(210, 131);
			this.panel5.TabIndex = 26;
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.Color.Transparent;
			this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label5.Location = new System.Drawing.Point(31, 30);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(150, 72);
			this.label5.TabIndex = 0;
			this.label5.Text = "FAILED CHANNEL ALARM";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel1
			// 
			this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
			this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel1.Controls.Add(this.pBoxLine);
			this.panel1.Controls.Add(this.label4);
			this.panel1.Controls.Add(this.panel3);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Location = new System.Drawing.Point(773, 541);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(481, 238);
			this.panel1.TabIndex = 28;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.BackColor = System.Drawing.Color.Transparent;
			this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.White;
			this.label4.Location = new System.Drawing.Point(325, 20);
			this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(48, 31);
			this.label4.TabIndex = 26;
			this.label4.Text = "Aft";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.Silver;
			this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
			this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel3.Controls.Add(this.label3);
			this.panel3.Location = new System.Drawing.Point(248, 83);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(210, 131);
			this.panel3.TabIndex = 25;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.Color.Transparent;
			this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label3.Location = new System.Drawing.Point(36, 18);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(129, 96);
			this.label3.TabIndex = 0;
			this.label3.Text = "AFT SECP SUB SYSTEM CONTROLLER FAULT";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BackColor = System.Drawing.Color.Transparent;
			this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(96, 20);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(66, 31);
			this.label1.TabIndex = 4;
			this.label1.Text = "Fwd";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.Silver;
			this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
			this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.label2);
			this.panel2.Location = new System.Drawing.Point(23, 83);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(210, 131);
			this.panel2.TabIndex = 24;
			// 
			// label2
			// 
			this.label2.BackColor = System.Drawing.Color.Transparent;
			this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.label2.Location = new System.Drawing.Point(34, 18);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(138, 96);
			this.label2.TabIndex = 0;
			this.label2.Text = "FWD SECP SUB SYSTEM CONTROLLER FAULT";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlStbd
			// 
			this.pnlStbd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlStbd.BackgroundImage")));
			this.pnlStbd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlStbd.Controls.Add(this.pnlStbd4);
			this.pnlStbd.Controls.Add(this.pnlStbd3);
			this.pnlStbd.Controls.Add(this.pnlStbd2);
			this.pnlStbd.Controls.Add(this.lblStbd);
			this.pnlStbd.Controls.Add(this.pnlStbd1);
			this.pnlStbd.Location = new System.Drawing.Point(773, 122);
			this.pnlStbd.Name = "pnlStbd";
			this.pnlStbd.Size = new System.Drawing.Size(481, 393);
			this.pnlStbd.TabIndex = 27;
			// 
			// pnlStbd4
			// 
			this.pnlStbd4.BackColor = System.Drawing.Color.Silver;
			this.pnlStbd4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlStbd4.BackgroundImage")));
			this.pnlStbd4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlStbd4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlStbd4.Controls.Add(this.lblStbd4);
			this.pnlStbd4.Location = new System.Drawing.Point(248, 230);
			this.pnlStbd4.Name = "pnlStbd4";
			this.pnlStbd4.Size = new System.Drawing.Size(210, 131);
			this.pnlStbd4.TabIndex = 26;
			// 
			// lblStbd4
			// 
			this.lblStbd4.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd4.Location = new System.Drawing.Point(28, 27);
			this.lblStbd4.Name = "lblStbd4";
			this.lblStbd4.Size = new System.Drawing.Size(152, 72);
			this.lblStbd4.TabIndex = 0;
			this.lblStbd4.Text = "GTR CDCU FAILSET STARBOARD";
			this.lblStbd4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlStbd3
			// 
			this.pnlStbd3.BackColor = System.Drawing.Color.Silver;
			this.pnlStbd3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlStbd3.BackgroundImage")));
			this.pnlStbd3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlStbd3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlStbd3.Controls.Add(this.lblStbd3);
			this.pnlStbd3.Location = new System.Drawing.Point(23, 230);
			this.pnlStbd3.Name = "pnlStbd3";
			this.pnlStbd3.Size = new System.Drawing.Size(210, 131);
			this.pnlStbd3.TabIndex = 25;
			// 
			// lblStbd3
			// 
			this.lblStbd3.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd3.Location = new System.Drawing.Point(44, 27);
			this.lblStbd3.Name = "lblStbd3";
			this.lblStbd3.Size = new System.Drawing.Size(118, 72);
			this.lblStbd3.TabIndex = 0;
			this.lblStbd3.Text = "GTR CDCU FAULT STARBOARD";
			this.lblStbd3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlStbd2
			// 
			this.pnlStbd2.BackColor = System.Drawing.Color.Silver;
			this.pnlStbd2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlStbd2.BackgroundImage")));
			this.pnlStbd2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlStbd2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlStbd2.Controls.Add(this.lblStbd2);
			this.pnlStbd2.Location = new System.Drawing.Point(248, 90);
			this.pnlStbd2.Name = "pnlStbd2";
			this.pnlStbd2.Size = new System.Drawing.Size(210, 131);
			this.pnlStbd2.TabIndex = 25;
			// 
			// lblStbd2
			// 
			this.lblStbd2.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd2.Location = new System.Drawing.Point(21, 28);
			this.lblStbd2.Name = "lblStbd2";
			this.lblStbd2.Size = new System.Drawing.Size(158, 72);
			this.lblStbd2.TabIndex = 0;
			this.lblStbd2.Text = "MGR CDCU FAILSET STARBOARD";
			this.lblStbd2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblStbd
			// 
			this.lblStbd.AutoSize = true;
			this.lblStbd.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblStbd.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd.ForeColor = System.Drawing.Color.White;
			this.lblStbd.Location = new System.Drawing.Point(175, 16);
			this.lblStbd.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblStbd.Name = "lblStbd";
			this.lblStbd.Size = new System.Drawing.Size(133, 31);
			this.lblStbd.TabIndex = 4;
			this.lblStbd.Text = "Starboard";
			this.lblStbd.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlStbd1
			// 
			this.pnlStbd1.BackColor = System.Drawing.Color.Silver;
			this.pnlStbd1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlStbd1.BackgroundImage")));
			this.pnlStbd1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlStbd1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlStbd1.Controls.Add(this.lblStbd1);
			this.pnlStbd1.Location = new System.Drawing.Point(23, 90);
			this.pnlStbd1.Name = "pnlStbd1";
			this.pnlStbd1.Size = new System.Drawing.Size(210, 131);
			this.pnlStbd1.TabIndex = 24;
			// 
			// lblStbd1
			// 
			this.lblStbd1.BackColor = System.Drawing.Color.Transparent;
			this.lblStbd1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStbd1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblStbd1.Location = new System.Drawing.Point(34, 28);
			this.lblStbd1.Name = "lblStbd1";
			this.lblStbd1.Size = new System.Drawing.Size(138, 72);
			this.lblStbd1.TabIndex = 0;
			this.lblStbd1.Text = "MGR CDCU FAILURE STARBOARD";
			this.lblStbd1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPort
			// 
			this.pnlPort.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPort.BackgroundImage")));
			this.pnlPort.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlPort.Controls.Add(this.pnlPort4);
			this.pnlPort.Controls.Add(this.pnlPort3);
			this.pnlPort.Controls.Add(this.pnlPort2);
			this.pnlPort.Controls.Add(this.lblPort);
			this.pnlPort.Controls.Add(this.pnlPort1);
			this.pnlPort.Location = new System.Drawing.Point(21, 122);
			this.pnlPort.Name = "pnlPort";
			this.pnlPort.Size = new System.Drawing.Size(481, 393);
			this.pnlPort.TabIndex = 25;
			// 
			// pnlPort4
			// 
			this.pnlPort4.BackColor = System.Drawing.Color.Silver;
			this.pnlPort4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPort4.BackgroundImage")));
			this.pnlPort4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlPort4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPort4.Controls.Add(this.lblPort4);
			this.pnlPort4.Location = new System.Drawing.Point(246, 230);
			this.pnlPort4.Name = "pnlPort4";
			this.pnlPort4.Size = new System.Drawing.Size(210, 131);
			this.pnlPort4.TabIndex = 26;
			// 
			// lblPort4
			// 
			this.lblPort4.BackColor = System.Drawing.Color.Transparent;
			this.lblPort4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort4.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort4.Location = new System.Drawing.Point(42, 30);
			this.lblPort4.Name = "lblPort4";
			this.lblPort4.Size = new System.Drawing.Size(123, 72);
			this.lblPort4.TabIndex = 0;
			this.lblPort4.Text = "GTR CDCU FAILURE PORT";
			this.lblPort4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPort3
			// 
			this.pnlPort3.BackColor = System.Drawing.Color.Silver;
			this.pnlPort3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPort3.BackgroundImage")));
			this.pnlPort3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlPort3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPort3.Controls.Add(this.lblPort3);
			this.pnlPort3.Location = new System.Drawing.Point(23, 230);
			this.pnlPort3.Name = "pnlPort3";
			this.pnlPort3.Size = new System.Drawing.Size(210, 131);
			this.pnlPort3.TabIndex = 25;
			// 
			// lblPort3
			// 
			this.lblPort3.BackColor = System.Drawing.Color.Transparent;
			this.lblPort3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort3.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort3.Location = new System.Drawing.Point(59, 17);
			this.lblPort3.Name = "lblPort3";
			this.lblPort3.Size = new System.Drawing.Size(100, 99);
			this.lblPort3.TabIndex = 0;
			this.lblPort3.Text = "GTR CDCU FAULT PORT";
			this.lblPort3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPort2
			// 
			this.pnlPort2.BackColor = System.Drawing.Color.Silver;
			this.pnlPort2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPort2.BackgroundImage")));
			this.pnlPort2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlPort2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPort2.Controls.Add(this.lblPort2);
			this.pnlPort2.Location = new System.Drawing.Point(246, 90);
			this.pnlPort2.Name = "pnlPort2";
			this.pnlPort2.Size = new System.Drawing.Size(210, 131);
			this.pnlPort2.TabIndex = 25;
			// 
			// lblPort2
			// 
			this.lblPort2.BackColor = System.Drawing.Color.Transparent;
			this.lblPort2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort2.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort2.Location = new System.Drawing.Point(46, 17);
			this.lblPort2.Name = "lblPort2";
			this.lblPort2.Size = new System.Drawing.Size(114, 99);
			this.lblPort2.TabIndex = 0;
			this.lblPort2.Text = "MGR CDCU FAILSET PORT";
			this.lblPort2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lblPort
			// 
			this.lblPort.AutoSize = true;
			this.lblPort.BackColor = System.Drawing.Color.Transparent;
			this.lblPort.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPort.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort.ForeColor = System.Drawing.Color.White;
			this.lblPort.Location = new System.Drawing.Point(207, 15);
			this.lblPort.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPort.Name = "lblPort";
			this.lblPort.Size = new System.Drawing.Size(64, 31);
			this.lblPort.TabIndex = 4;
			this.lblPort.Text = "Port";
			this.lblPort.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlPort1
			// 
			this.pnlPort1.BackColor = System.Drawing.Color.Silver;
			this.pnlPort1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlPort1.BackgroundImage")));
			this.pnlPort1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.pnlPort1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPort1.Controls.Add(this.lblPort1);
			this.pnlPort1.Location = new System.Drawing.Point(23, 90);
			this.pnlPort1.Name = "pnlPort1";
			this.pnlPort1.Size = new System.Drawing.Size(210, 131);
			this.pnlPort1.TabIndex = 24;
			// 
			// lblPort1
			// 
			this.lblPort1.BackColor = System.Drawing.Color.Transparent;
			this.lblPort1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPort1.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblPort1.Location = new System.Drawing.Point(45, 17);
			this.lblPort1.Name = "lblPort1";
			this.lblPort1.Size = new System.Drawing.Size(114, 99);
			this.lblPort1.TabIndex = 0;
			this.lblPort1.Text = "MGR CDCU FAILURE PORT";
			this.lblPort1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pBoxLine
			// 
			this.pBoxLine.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(107)))), ((int)(((byte)(107)))));
			this.pBoxLine.Location = new System.Drawing.Point(238, 70);
			this.pBoxLine.Name = "pBoxLine";
			this.pBoxLine.Size = new System.Drawing.Size(6, 160);
			this.pBoxLine.TabIndex = 30;
			this.pBoxLine.TabStop = false;
			// 
			// frmMaintMalfunctions1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1280, 791);
			this.ControlBox = false;
			this.Controls.Add(this.pnlPanelTest);
			this.Cursor = System.Windows.Forms.Cursors.Cross;
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmMaintMalfunctions1";
			this.Text = "Maint Malfunctions 1";
			this.pnlTop.ResumeLayout(false);
			this.pnlTopInner.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
			this.pnlPanelTest.ResumeLayout(false);
			this.panel8.ResumeLayout(false);
			this.panel6.ResumeLayout(false);
			this.panel7.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.pnlStbd.ResumeLayout(false);
			this.pnlStbd.PerformLayout();
			this.pnlStbd4.ResumeLayout(false);
			this.pnlStbd3.ResumeLayout(false);
			this.pnlStbd2.ResumeLayout(false);
			this.pnlStbd1.ResumeLayout(false);
			this.pnlPort.ResumeLayout(false);
			this.pnlPort.PerformLayout();
			this.pnlPort4.ResumeLayout(false);
			this.pnlPort3.ResumeLayout(false);
			this.pnlPort2.ResumeLayout(false);
			this.pnlPort1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pBoxLine)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.PictureBox PageFwd;
		private System.Windows.Forms.PictureBox PageBack;
		private System.Windows.Forms.Panel pnlPanelTest;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.Panel pnlPort1;
		private System.Windows.Forms.Label lblPort1;
		private System.Windows.Forms.Label lblPageName2;
		private System.Windows.Forms.Panel pnlPort;
		private System.Windows.Forms.Panel pnlPort2;
		private System.Windows.Forms.Label lblPort2;
		private System.Windows.Forms.Label lblPort;
		private System.Windows.Forms.Panel pnlPort4;
		private System.Windows.Forms.Label lblPort4;
		private System.Windows.Forms.Panel pnlPort3;
		private System.Windows.Forms.Label lblPort3;
		private System.Windows.Forms.Panel pnlStbd;
		private System.Windows.Forms.Panel pnlStbd4;
		private System.Windows.Forms.Label lblStbd4;
		private System.Windows.Forms.Panel pnlStbd3;
		private System.Windows.Forms.Label lblStbd3;
		private System.Windows.Forms.Panel pnlStbd2;
		private System.Windows.Forms.Label lblStbd2;
		private System.Windows.Forms.Label lblStbd;
		private System.Windows.Forms.Panel pnlStbd1;
		private System.Windows.Forms.Label lblStbd1;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Panel panel7;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Panel panel6;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Panel panel8;
		private System.Windows.Forms.PictureBox pBoxLine;
	}
}