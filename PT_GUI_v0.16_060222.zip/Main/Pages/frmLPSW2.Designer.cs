﻿
namespace PtGui
{
	partial class frmLPSW2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLPSW2));
			this.staticText3 = new System.Windows.Forms.Label();
			this.staticText1 = new System.Windows.Forms.Label();
			this.staticText2 = new System.Windows.Forms.Label();
			this.pnl3WAY2 = new System.Windows.Forms.Panel();
			this.pnl3WAY1 = new System.Windows.Forms.Panel();
			this.staticText4 = new System.Windows.Forms.Label();
			this.staticText5 = new System.Windows.Forms.Label();
			this.staticText6 = new System.Windows.Forms.Label();
			this.staticText7 = new System.Windows.Forms.Label();
			this.staticText8 = new System.Windows.Forms.Label();
			this.staticText9 = new System.Windows.Forms.Label();
			this.staticText10 = new System.Windows.Forms.Label();
			this.staticText11 = new System.Windows.Forms.Label();
			this.staticText12 = new System.Windows.Forms.Label();
			this.pnlH2ValveOpn = new System.Windows.Forms.Panel();
			this.pnlH1ValveOpn = new System.Windows.Forms.Panel();
			this.pnlVlvOverflow1Opn = new System.Windows.Forms.Panel();
			this.staticText14 = new System.Windows.Forms.Label();
			this.pnlTop = new System.Windows.Forms.Panel();
			this.pnlTopInner = new System.Windows.Forms.Panel();
			this.lblPageName = new System.Windows.Forms.Label();
			this.PageBack = new System.Windows.Forms.PictureBox();
			this.PageFwd = new System.Windows.Forms.PictureBox();
			this.pnlTop.SuspendLayout();
			this.pnlTopInner.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).BeginInit();
			this.SuspendLayout();
			// 
			// staticText3
			// 
			this.staticText3.AutoSize = true;
			this.staticText3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText3.ForeColor = System.Drawing.Color.White;
			this.staticText3.Location = new System.Drawing.Point(1092, 132);
			this.staticText3.Name = "staticText3";
			this.staticText3.Size = new System.Drawing.Size(109, 19);
			this.staticText3.TabIndex = 17;
			this.staticText3.Text = "FROM HPSW";
			this.staticText3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText1
			// 
			this.staticText1.AutoSize = true;
			this.staticText1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText1.ForeColor = System.Drawing.Color.White;
			this.staticText1.Location = new System.Drawing.Point(64, 132);
			this.staticText1.Name = "staticText1";
			this.staticText1.Size = new System.Drawing.Size(109, 19);
			this.staticText1.TabIndex = 63;
			this.staticText1.Text = "FROM HPSW";
			this.staticText1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText2
			// 
			this.staticText2.AutoSize = true;
			this.staticText2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText2.ForeColor = System.Drawing.Color.White;
			this.staticText2.Location = new System.Drawing.Point(580, 132);
			this.staticText2.Name = "staticText2";
			this.staticText2.Size = new System.Drawing.Size(109, 19);
			this.staticText2.TabIndex = 64;
			this.staticText2.Text = "FROM HPSW";
			this.staticText2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnl3WAY2
			// 
			this.pnl3WAY2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl3WAY2.BackgroundImage")));
			this.pnl3WAY2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnl3WAY2.Location = new System.Drawing.Point(739, 358);
			this.pnl3WAY2.Name = "pnl3WAY2";
			this.pnl3WAY2.Size = new System.Drawing.Size(44, 62);
			this.pnl3WAY2.TabIndex = 65;
			// 
			// pnl3WAY1
			// 
			this.pnl3WAY1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnl3WAY1.BackgroundImage")));
			this.pnl3WAY1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnl3WAY1.Location = new System.Drawing.Point(409, 353);
			this.pnl3WAY1.Name = "pnl3WAY1";
			this.pnl3WAY1.Size = new System.Drawing.Size(44, 62);
			this.pnl3WAY1.TabIndex = 66;
			// 
			// staticText4
			// 
			this.staticText4.AutoSize = true;
			this.staticText4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText4.ForeColor = System.Drawing.Color.White;
			this.staticText4.Location = new System.Drawing.Point(423, 442);
			this.staticText4.Name = "staticText4";
			this.staticText4.Size = new System.Drawing.Size(30, 19);
			this.staticText4.TabIndex = 67;
			this.staticText4.Text = "H2";
			this.staticText4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText5
			// 
			this.staticText5.AutoSize = true;
			this.staticText5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText5.ForeColor = System.Drawing.Color.White;
			this.staticText5.Location = new System.Drawing.Point(732, 442);
			this.staticText5.Name = "staticText5";
			this.staticText5.Size = new System.Drawing.Size(30, 19);
			this.staticText5.TabIndex = 68;
			this.staticText5.Text = "H1";
			this.staticText5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText6
			// 
			this.staticText6.AutoSize = true;
			this.staticText6.BackColor = System.Drawing.Color.Transparent;
			this.staticText6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText6.ForeColor = System.Drawing.Color.White;
			this.staticText6.Location = new System.Drawing.Point(1121, 520);
			this.staticText6.Name = "staticText6";
			this.staticText6.Size = new System.Drawing.Size(54, 19);
			this.staticText6.TabIndex = 69;
			this.staticText6.Text = "HPAC";
			this.staticText6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText7
			// 
			this.staticText7.AutoSize = true;
			this.staticText7.BackColor = System.Drawing.Color.Transparent;
			this.staticText7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText7.ForeColor = System.Drawing.Color.White;
			this.staticText7.Location = new System.Drawing.Point(696, 616);
			this.staticText7.Name = "staticText7";
			this.staticText7.Size = new System.Drawing.Size(93, 19);
			this.staticText7.TabIndex = 70;
			this.staticText7.Text = "DG FW H/E";
			this.staticText7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText8
			// 
			this.staticText8.AutoSize = true;
			this.staticText8.BackColor = System.Drawing.Color.Transparent;
			this.staticText8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText8.ForeColor = System.Drawing.Color.White;
			this.staticText8.Location = new System.Drawing.Point(386, 616);
			this.staticText8.Name = "staticText8";
			this.staticText8.Size = new System.Drawing.Size(93, 19);
			this.staticText8.TabIndex = 71;
			this.staticText8.Text = "DG FW H/E";
			this.staticText8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText9
			// 
			this.staticText9.BackColor = System.Drawing.Color.Transparent;
			this.staticText9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText9.ForeColor = System.Drawing.Color.White;
			this.staticText9.Location = new System.Drawing.Point(55, 519);
			this.staticText9.Name = "staticText9";
			this.staticText9.Size = new System.Drawing.Size(124, 54);
			this.staticText9.TabIndex = 72;
			this.staticText9.Text = "    MASKER    AIR COMPRS";
			this.staticText9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText10
			// 
			this.staticText10.BackColor = System.Drawing.Color.Transparent;
			this.staticText10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText10.ForeColor = System.Drawing.Color.White;
			this.staticText10.Location = new System.Drawing.Point(321, 731);
			this.staticText10.Name = "staticText10";
			this.staticText10.Size = new System.Drawing.Size(181, 44);
			this.staticText10.TabIndex = 73;
			this.staticText10.Text = "DISCHARGE O\'B\'D VALVE IN MGR";
			this.staticText10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText11
			// 
			this.staticText11.BackColor = System.Drawing.Color.Transparent;
			this.staticText11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText11.ForeColor = System.Drawing.Color.White;
			this.staticText11.Location = new System.Drawing.Point(781, 731);
			this.staticText11.Name = "staticText11";
			this.staticText11.Size = new System.Drawing.Size(181, 44);
			this.staticText11.TabIndex = 74;
			this.staticText11.Text = "DISCHARGE O\'B\'D VALVE IN MGR";
			this.staticText11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// staticText12
			// 
			this.staticText12.BackColor = System.Drawing.Color.Transparent;
			this.staticText12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText12.ForeColor = System.Drawing.Color.White;
			this.staticText12.Location = new System.Drawing.Point(1073, 731);
			this.staticText12.Name = "staticText12";
			this.staticText12.Size = new System.Drawing.Size(181, 44);
			this.staticText12.TabIndex = 75;
			this.staticText12.Text = "DISCHARGE O\'B\'D VALVE IN MGR";
			this.staticText12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlH2ValveOpn
			// 
			this.pnlH2ValveOpn.BackColor = System.Drawing.Color.Transparent;
			this.pnlH2ValveOpn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlH2ValveOpn.BackgroundImage")));
			this.pnlH2ValveOpn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlH2ValveOpn.Location = new System.Drawing.Point(398, 664);
			this.pnlH2ValveOpn.Name = "pnlH2ValveOpn";
			this.pnlH2ValveOpn.Size = new System.Drawing.Size(33, 33);
			this.pnlH2ValveOpn.TabIndex = 76;
			// 
			// pnlH1ValveOpn
			// 
			this.pnlH1ValveOpn.BackColor = System.Drawing.Color.Transparent;
			this.pnlH1ValveOpn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlH1ValveOpn.BackgroundImage")));
			this.pnlH1ValveOpn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
			this.pnlH1ValveOpn.Location = new System.Drawing.Point(756, 664);
			this.pnlH1ValveOpn.Name = "pnlH1ValveOpn";
			this.pnlH1ValveOpn.Size = new System.Drawing.Size(33, 33);
			this.pnlH1ValveOpn.TabIndex = 77;
			// 
			// pnlVlvOverflow1Opn
			// 
			this.pnlVlvOverflow1Opn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pnlVlvOverflow1Opn.BackgroundImage")));
			this.pnlVlvOverflow1Opn.Location = new System.Drawing.Point(945, 406);
			this.pnlVlvOverflow1Opn.Name = "pnlVlvOverflow1Opn";
			this.pnlVlvOverflow1Opn.Size = new System.Drawing.Size(58, 33);
			this.pnlVlvOverflow1Opn.TabIndex = 43;
			// 
			// staticText14
			// 
			this.staticText14.AutoSize = true;
			this.staticText14.BackColor = System.Drawing.Color.Transparent;
			this.staticText14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.staticText14.ForeColor = System.Drawing.Color.White;
			this.staticText14.Location = new System.Drawing.Point(943, 520);
			this.staticText14.Name = "staticText14";
			this.staticText14.Size = new System.Drawing.Size(36, 19);
			this.staticText14.TabIndex = 78;
			this.staticText14.Text = "A/C";
			this.staticText14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pnlTop
			// 
			this.pnlTop.BackColor = System.Drawing.Color.White;
			this.pnlTop.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlTop.Controls.Add(this.pnlTopInner);
			this.pnlTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.pnlTop.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.pnlTop.Location = new System.Drawing.Point(25, 5);
			this.pnlTop.Name = "pnlTop";
			this.pnlTop.Size = new System.Drawing.Size(1229, 96);
			this.pnlTop.TabIndex = 98;
			// 
			// pnlTopInner
			// 
			this.pnlTopInner.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.pnlTopInner.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(147)))));
			this.pnlTopInner.Controls.Add(this.lblPageName);
			this.pnlTopInner.Controls.Add(this.PageBack);
			this.pnlTopInner.Controls.Add(this.PageFwd);
			this.pnlTopInner.Location = new System.Drawing.Point(5, 3);
			this.pnlTopInner.Name = "pnlTopInner";
			this.pnlTopInner.Size = new System.Drawing.Size(1219, 87);
			this.pnlTopInner.TabIndex = 0;
			// 
			// lblPageName
			// 
			this.lblPageName.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.lblPageName.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPageName.ForeColor = System.Drawing.Color.White;
			this.lblPageName.Location = new System.Drawing.Point(335, 5);
			this.lblPageName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.lblPageName.Name = "lblPageName";
			this.lblPageName.Size = new System.Drawing.Size(521, 73);
			this.lblPageName.TabIndex = 2;
			this.lblPageName.Text = "                    LPSW2 System                   (Upper Auxiliary Machinery Roo" +
    "m Only)";
			this.lblPageName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// PageBack
			// 
			this.PageBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageBack.BackgroundImage")));
			this.PageBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageBack.Location = new System.Drawing.Point(1103, 0);
			this.PageBack.Name = "PageBack";
			this.PageBack.Size = new System.Drawing.Size(116, 87);
			this.PageBack.TabIndex = 0;
			this.PageBack.TabStop = false;
			this.PageBack.Click += new System.EventHandler(this.PageFwd_Click);
			// 
			// PageFwd
			// 
			this.PageFwd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(147)))), ((int)(((byte)(0)))));
			this.PageFwd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PageFwd.BackgroundImage")));
			this.PageFwd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.PageFwd.Location = new System.Drawing.Point(0, 0);
			this.PageFwd.Name = "PageFwd";
			this.PageFwd.Size = new System.Drawing.Size(116, 87);
			this.PageFwd.TabIndex = 1;
			this.PageFwd.TabStop = false;
			this.PageFwd.Click += new System.EventHandler(this.PageBack_Click);
			// 
			// frmLPSW2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(51)))), ((int)(((byte)(51)))));
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.ClientSize = new System.Drawing.Size(1280, 791);
			this.Controls.Add(this.pnlTop);
			this.Controls.Add(this.staticText14);
			this.Controls.Add(this.pnlVlvOverflow1Opn);
			this.Controls.Add(this.pnlH1ValveOpn);
			this.Controls.Add(this.pnlH2ValveOpn);
			this.Controls.Add(this.staticText12);
			this.Controls.Add(this.staticText11);
			this.Controls.Add(this.staticText10);
			this.Controls.Add(this.staticText9);
			this.Controls.Add(this.staticText8);
			this.Controls.Add(this.staticText7);
			this.Controls.Add(this.staticText6);
			this.Controls.Add(this.staticText5);
			this.Controls.Add(this.staticText4);
			this.Controls.Add(this.pnl3WAY1);
			this.Controls.Add(this.pnl3WAY2);
			this.Controls.Add(this.staticText2);
			this.Controls.Add(this.staticText1);
			this.Controls.Add(this.staticText3);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "frmLPSW2";
			this.Text = "LPSW 2";
			this.pnlTop.ResumeLayout(false);
			this.pnlTopInner.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.PageBack)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PageFwd)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Label staticText3;
		private System.Windows.Forms.Label staticText1;
		private System.Windows.Forms.Label staticText2;
		private System.Windows.Forms.Panel pnl3WAY2;
		private System.Windows.Forms.Panel pnl3WAY1;
		private System.Windows.Forms.Label staticText4;
		private System.Windows.Forms.Label staticText5;
		private System.Windows.Forms.Label staticText6;
		private System.Windows.Forms.Label staticText7;
		private System.Windows.Forms.Label staticText8;
		private System.Windows.Forms.Label staticText9;
		private System.Windows.Forms.Label staticText10;
		private System.Windows.Forms.Label staticText11;
		private System.Windows.Forms.Label staticText12;
		private System.Windows.Forms.Panel pnlH2ValveOpn;
		private System.Windows.Forms.Panel pnlH1ValveOpn;
		private System.Windows.Forms.Panel pnlVlvOverflow1Opn;
		private System.Windows.Forms.Label staticText14;
		private System.Windows.Forms.Panel pnlTop;
		private System.Windows.Forms.Panel pnlTopInner;
		private System.Windows.Forms.Label lblPageName;
		private System.Windows.Forms.PictureBox PageBack;
		private System.Windows.Forms.PictureBox PageFwd;
	}
}