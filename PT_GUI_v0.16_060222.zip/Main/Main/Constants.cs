﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PtGui
{
    class Constants
    {
        public const int tabPageMain = 0;
        public const int tabPagePropulsion = 1;

        public static System.Drawing.Color BACKGROUND_OFF = Color.Red;
        public static System.Drawing.Color BACKGROUND_ON = Color.Blue;

        public const string DIGITAL_OFF = "0";
        public const string DIGITAL_ON = "1";

        public const string ROOT_FOLDER = "c:/temp/PT_GUI_data/";
        //data types
        public const int DATA_TYPE_INPUTS = 0;
        public const int DATA_TYPE_INTERNALS = 1;
        public const int DATA_TYPE_OUTPUTS = 2;

        public const bool DO_NOT_ADD_TO_BACKLIST = false;
        public const bool ADD_TO_BACKLIST = true;


        //Bitmaps
        public const string BMP_FOLDER = ROOT_FOLDER + "resources/Bitmaps/";
        
		//GKD Test
		public const string BMP_BUTTON_RED_DOWN = BMP_FOLDER + "rect_button_red_pressed.bmp";
        public const string BMP_BUTTON_RED_UP = BMP_FOLDER + "rect_button_red.bmp";
        public const string BMP_BUTTON_GREEN_DOWN = BMP_FOLDER + "green_button_l_pressed.bmp";
        public const string BMP_BUTTON_GREEN_UP = BMP_FOLDER + "green_button_l.bmp";


        //Rectangle Buttons (650 x 500 pixels)
        public const string BMP_RECT_BUTTON_RED_DOWN = BMP_FOLDER + "rect_button_red_pressed.bmp";
        public const string BMP_RECT_BUTTON_RED_UP = BMP_FOLDER + "rect_button_red.bmp";

        public const string BMP_RECT_BUTTON_GREEN_DOWN = BMP_FOLDER + "rect_button_green_pressed.bmp";
        public const string BMP_RECT_BUTTON_GREEN_UP = BMP_FOLDER + "rect_button_green.bmp";

        public const string BMP_RECT_BUTTON_CYAN_DOWN = BMP_FOLDER + "rect_button_cyan_pressed.bmp";
        public const string BMP_RECT_BUTTON_CYAN_UP = BMP_FOLDER + "rect_button_cyan.bmp";

        public const string BMP_RECT_BUTTON_YELLOW_DOWN = BMP_FOLDER + "rect_button_yellow_pressed.bmp";
        public const string BMP_RECT_BUTTON_YELLOW_UP = BMP_FOLDER + "rect_button_yellow.bmp";

        public const string BMP_RECT_BUTTON_BLUE_DOWN = BMP_FOLDER + "rect_button_blue_pressed.bmp";
        public const string BMP_RECT_BUTTON_BLUE_UP = BMP_FOLDER + "rect_button_blue.bmp";

        public const string BMP_RECT_BUTTON_MAGENTA_DOWN = BMP_FOLDER + "rect_button_magenta_pressed.bmp";
        public const string BMP_RECT_BUTTON_MAGENTA_UP = BMP_FOLDER + "rect_button_magenta.bmp";

        public const string BMP_RECT_BUTTON_GREY_DOWN = BMP_FOLDER + "rect_button_grey_pressed.bmp";
        public const string BMP_RECT_BUTTON_GREY_UP = BMP_FOLDER + "rect_button_grey.bmp";


        //Long Buttons (2000 x 500 pixels)
        public const string BMP_LONG_BUTTON_GREEN_DOWN = BMP_FOLDER + "long_button_green_pressed.bmp";
        public const string BMP_LONG_BUTTON_GREEN_UP = BMP_FOLDER + "long_button_green.bmp";

        public const string BMP_LONG_BUTTON_RED_DOWN = BMP_FOLDER + "long_button_red_pressed.bmp";
        public const string BMP_LONG_BUTTON_RED_UP = BMP_FOLDER + "long_button_red.bmp";

        //Square Buttons (410 x 500 pixels)
        public const string BMP_SQUARE_BUTTON_RED_DOWN = BMP_FOLDER + "square_button_red_pressed.bmp";
        public const string BMP_SQUARE_BUTTON_RED_UP = BMP_FOLDER + "square_button_red.bmp";

        public const string BMP_SQUARE_BUTTON_GREEN_DOWN = BMP_FOLDER + "square_button_green_pressed.bmp";
        public const string BMP_SQUARE_BUTTON_GREEN_UP = BMP_FOLDER + "square_button_green.bmp";

        public const string BMP_SQUARE_BUTTON_CYAN_DOWN = BMP_FOLDER + "square_button_cyan_pressed.bmp";
        public const string BMP_SQUARE_BUTTON_CYAN_UP = BMP_FOLDER + "square_button_cyan.bmp";

        public const string BMP_SQUARE_BUTTON_YELLOW_DOWN = BMP_FOLDER + "square_button_yellow_pressed.bmp";
        public const string BMP_SQUARE_BUTTON_YELLOW_UP = BMP_FOLDER + "square_button_yellow.bmp";

        public const string BMP_SQUARE_BUTTON_BLUE_DOWN = BMP_FOLDER + "square_button_blue_pressed.bmp";
        public const string BMP_SQUARE_BUTTON_BLUE_UP = BMP_FOLDER + "square_button_blue.bmp";

        public const string BMP_SQUARE_BUTTON_GREY_DOWN = BMP_FOLDER + "square_button_grey_pressed.bmp";
        public const string BMP_SQUARE_BUTTON_GREY_UP = BMP_FOLDER + "square_button_grey.bmp";

        //Reset Buttons (650 x 500 pixels)
        public const string BMP_RESET_BUTTON_CYAN_DOWN = BMP_FOLDER + "reset_button_cyan_pressed.bmp";
        public const string BMP_RESET_BUTTON_CYAN_UP = BMP_FOLDER + "reset_button_cyan.bmp";

        //Hexagonal buttons
        public const string BMP_HEX_BUTTON_GREEN_DOWN = BMP_FOLDER + "hex_button_green_pressed.bmp";
        public const string BMP_HEX_BUTTON_GREEN_UP = BMP_FOLDER + "hex_button_green.bmp";

        // Run / Slow pointer
        public const string BMP_RUN = BMP_FOLDER + "run.bmp";
        public const string BMP_SLOW = BMP_FOLDER + "slow.bmp";

    }
}
